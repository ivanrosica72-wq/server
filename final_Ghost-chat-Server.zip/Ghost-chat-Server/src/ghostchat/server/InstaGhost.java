package ghostchat.server;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.RandomAccessFile;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.zip.CRC32;

/**
 * Final: InstaGhost, la parte "social" di Ghost-chat (post con foto e video
 * "Ghost-tube" in stile reel, like/non mi piace, preferiti, condivisioni,
 * commenti con testo, sticker e GIF, profili con biografia e seguaci).
 * <p>
 * A differenza delle chat, i post restano salvati sul server (cartella
 * {@code ghostchat-data/instaghost}) finche' l'autore non li elimina.
 * Tutti i metodi pubblici sono synchronized.
 */
public final class InstaGhost {

    private static final InstaGhost INSTANCE = new InstaGhost();
    static final int MAX_CAPTION = 2200;
    static final int MAX_COMMENT = 1000;
    static final int MAX_STICKER_CHARS = 140 * 1024;
    static final int MAX_PREVIEW_CHARS = 200 * 1024;
    static final int MAX_BIO = 300;

    /** Un post (foto "P" o Ghost-tube "V"). */
    static final class Post {

        String id;
        String author;
        char kind;
        long time;
        long size;
        int w;
        int h;
        long dur;
        String caption = "";
        final Set<String> likes = new LinkedHashSet<>();
        final Set<String> dislikes = new LinkedHashSet<>();
        final Set<String> favs = new LinkedHashSet<>();
        int shares;
        final List<Comment> comments = new ArrayList<>();
    }

    static final class Comment {

        String id;
        String author;
        char kind; // T testo, S sticker (immagine base64), G GIF (url)
        long time;
        String content;
    }

    /** Caricamento in corso. */
    private static final class Upload {

        final Post post;
        final File tmp;
        final OutputStream out;
        long received;
        String preview = "";

        Upload(Post post, File tmp) throws IOException {
            this.post = post;
            this.tmp = tmp;
            this.out = new FileOutputStream(tmp);
        }
    }

    private final Map<String, Post> posts = new LinkedHashMap<>();
    private final Map<String, String> bios = new HashMap<>();
    private final Map<String, Set<String>> following = new HashMap<>();
    private final Map<String, Upload> uploads = new HashMap<>();
    private File dir;
    private File media;
    private volatile boolean dirty;

    private InstaGhost() {
    }

    public static InstaGhost getInstance() {
        return INSTANCE;
    }

    // ================================================================ persistenza

    synchronized void load() {
        dir = new File(ServerConfig.dataDir(), "instaghost");
        media = new File(dir, "media");
        if (!media.isDirectory() && !media.mkdirs()) {
            ServerLog.warn("Impossibile creare " + media);
        }
        File idx = new File(dir, "index.db");
        if (idx.isFile()) {
            try (BufferedReader r = new BufferedReader(new InputStreamReader(new FileInputStream(idx), StandardCharsets.UTF_8))) {
                String line;
                while ((line = r.readLine()) != null) {
                    String[] f = line.split("\\|", -1);
                    try {
                        switch (f[0]) {
                            case "P": {
                                Post p = new Post();
                                p.id = f[1];
                                p.author = f[2];
                                p.kind = f[3].charAt(0);
                                p.time = Long.parseLong(f[4]);
                                p.size = Long.parseLong(f[5]);
                                p.w = Integer.parseInt(f[6]);
                                p.h = Integer.parseInt(f[7]);
                                p.dur = Long.parseLong(f[8]);
                                p.caption = unesc(f[9]);
                                split(f[10], p.likes);
                                split(f[11], p.dislikes);
                                split(f[12], p.favs);
                                p.shares = Integer.parseInt(f[13]);
                                if (new File(media, p.id + ".bin").isFile()) {
                                    posts.put(p.id, p);
                                }
                                break;
                            }
                            case "C": {
                                Post p = posts.get(f[1]);
                                if (p != null) {
                                    Comment c = new Comment();
                                    c.id = f[2];
                                    c.author = f[3];
                                    c.kind = f[4].charAt(0);
                                    c.time = Long.parseLong(f[5]);
                                    c.content = unesc(f[6]);
                                    p.comments.add(c);
                                }
                                break;
                            }
                            case "B":
                                bios.put(key(f[1]), unesc(f[2]));
                                break;
                            case "F": {
                                Set<String> s = new LinkedHashSet<>();
                                split(f[2], s);
                                following.put(key(f[1]), s);
                                break;
                            }
                            default:
                                break;
                        }
                    } catch (RuntimeException e) {
                        // riga danneggiata: si salta
                    }
                }
            } catch (Throwable t) {
                ServerLog.error("Lettura di InstaGhost non riuscita", t);
            }
        }
        ServerLog.info("InstaGhost: " + posts.size() + " post caricati");
        Thread saver = new Thread(() -> {
            while (true) {
                try {
                    Thread.sleep(2000);
                    if (dirty) {
                        save();
                    }
                } catch (InterruptedException e) {
                    return;
                } catch (Throwable t) {
                    ServerLog.error("Salvataggio di InstaGhost non riuscito", t);
                }
            }
        }, "instaghost-saver");
        saver.setDaemon(true);
        saver.start();
    }

    synchronized void save() {
        dirty = false;
        File idx = new File(dir, "index.db");
        File tmp = new File(dir, "index.db.tmp");
        try (Writer w = new OutputStreamWriter(new FileOutputStream(tmp), StandardCharsets.UTF_8)) {
            for (Post p : posts.values()) {
                w.write("P|" + p.id + "|" + p.author + "|" + p.kind + "|" + p.time + "|" + p.size + "|" + p.w + "|" + p.h
                        + "|" + p.dur + "|" + esc(p.caption) + "|" + String.join(",", p.likes) + "|"
                        + String.join(",", p.dislikes) + "|" + String.join(",", p.favs) + "|" + p.shares + "\n");
                for (Comment c : p.comments) {
                    w.write("C|" + p.id + "|" + c.id + "|" + c.author + "|" + c.kind + "|" + c.time + "|" + esc(c.content) + "\n");
                }
            }
            for (Map.Entry<String, String> e : bios.entrySet()) {
                w.write("B|" + e.getKey() + "|" + esc(e.getValue()) + "\n");
            }
            for (Map.Entry<String, Set<String>> e : following.entrySet()) {
                w.write("F|" + e.getKey() + "|" + String.join(",", e.getValue()) + "\n");
            }
        } catch (Throwable t) {
            ServerLog.error("Scrittura di InstaGhost non riuscita", t);
            dirty = true;
            return;
        }
        if (idx.exists() && !idx.delete()) {
            ServerLog.warn("Impossibile sostituire " + idx);
        }
        if (!tmp.renameTo(idx)) {
            ServerLog.warn("Impossibile rinominare " + tmp);
        }
    }

    // ================================================================ caricamento

    /** @return null se si puo' iniziare, altrimenti il motivo */
    public synchronized String begin(String author, String id, char kind, long size, int w, int h, long dur, String caption) {
        if (id == null || !id.matches("[A-Za-z0-9]{6,40}") || posts.containsKey(id) || uploads.containsKey(id)) {
            return "Identificativo del post non valido";
        }
        if (kind != 'P' && kind != 'V') {
            return "Tipo di post non valido";
        }
        long max = (kind == 'P' ? ServerConfig.integer("instaghost.maxPhotoMB", 12)
                : ServerConfig.integer("instaghost.maxVideoMB", 80)) * 1024L * 1024L;
        if (size <= 0 || size > max) {
            return (kind == 'P' ? "Foto" : "Video") + " troppo grande (massimo " + (max / (1024 * 1024)) + " MB)";
        }
        int pending = 0;
        for (Upload u : uploads.values()) {
            if (u.post.author.equalsIgnoreCase(author)) {
                pending++;
            }
        }
        if (pending >= 3) {
            return "Hai già troppi caricamenti in corso";
        }
        Post p = new Post();
        p.id = id;
        p.author = author;
        p.kind = kind;
        p.size = size;
        p.w = Math.max(0, w);
        p.h = Math.max(0, h);
        p.dur = Math.max(0, dur);
        String c = caption == null ? "" : caption;
        p.caption = c.length() > MAX_CAPTION ? c.substring(0, MAX_CAPTION) : c;
        try {
            uploads.put(id, new Upload(p, new File(media, id + ".part")));
        } catch (IOException e) {
            return "Il server non riesce a salvare il file";
        }
        return null;
    }

    public synchronized boolean preview(String author, String id, String b64) {
        Upload u = uploads.get(id);
        if (u == null || !u.post.author.equalsIgnoreCase(author) || b64.length() > MAX_PREVIEW_CHARS
                || !b64.matches("[A-Za-z0-9+/=]*")) {
            return false;
        }
        u.preview = b64;
        return true;
    }

    public synchronized boolean chunk(String author, String id, byte[] data) {
        Upload u = uploads.get(id);
        if (u == null || !u.post.author.equalsIgnoreCase(author)) {
            return false;
        }
        if (u.received + data.length > u.post.size) {
            abort(author, id);
            return false;
        }
        try {
            u.out.write(data);
            u.received += data.length;
            return true;
        } catch (IOException e) {
            abort(author, id);
            return false;
        }
    }

    /** @return il post pubblicato oppure null se i dati sono danneggiati */
    public synchronized Post finish(String author, String id, String crcHex) {
        Upload u = uploads.remove(id);
        if (u == null || !u.post.author.equalsIgnoreCase(author)) {
            return null;
        }
        try {
            u.out.close();
        } catch (IOException ignored) {
            // si controlla sotto
        }
        try {
            if (u.received != u.post.size) {
                throw new IOException("dimensione");
            }
            CRC32 crc = new CRC32();
            byte[] buf = new byte[65536];
            try (FileInputStream in = new FileInputStream(u.tmp)) {
                int n;
                while ((n = in.read(buf)) > 0) {
                    crc.update(buf, 0, n);
                }
            }
            if (!Long.toHexString(crc.getValue()).equalsIgnoreCase(crcHex == null ? "" : crcHex.trim())) {
                throw new IOException("crc");
            }
            File bin = new File(media, id + ".bin");
            Files.move(u.tmp.toPath(), bin.toPath());
            if (!u.preview.isEmpty()) {
                Files.write(new File(media, id + ".prev").toPath(), u.preview.getBytes(StandardCharsets.US_ASCII));
            }
        } catch (IOException e) {
            if (!u.tmp.delete()) {
                u.tmp.deleteOnExit();
            }
            return null;
        }
        u.post.time = System.currentTimeMillis();
        // i post piu' recenti in cima: si reinserisce l'ordine
        Map<String, Post> copy = new LinkedHashMap<>();
        copy.put(id, u.post);
        copy.putAll(posts);
        posts.clear();
        posts.putAll(copy);
        dirty = true;
        return u.post;
    }

    public synchronized void abort(String author, String id) {
        Upload u = uploads.get(id);
        if (u != null && u.post.author.equalsIgnoreCase(author)) {
            uploads.remove(id);
            try {
                u.out.close();
            } catch (IOException ignored) {
                // niente
            }
            if (!u.tmp.delete()) {
                u.tmp.deleteOnExit();
            }
        }
    }

    public synchronized void abortAll(String author) {
        for (String id : new ArrayList<>(uploads.keySet())) {
            abort(author, id);
        }
    }

    // ================================================================ lettura

    /**
     * Post da mostrare. mode: "all", "P", "V", "user:&lt;nick&gt;", "favs", "following".
     */
    public synchronized List<Post> feed(String me, String mode, long before, int limit, boolean[] more) {
        List<Post> out = new ArrayList<>();
        limit = Math.max(1, Math.min(30, limit));
        Set<String> fol = following.getOrDefault(key(me), new LinkedHashSet<>());
        more[0] = false;
        for (Post p : posts.values()) {
            if (before > 0 && p.time >= before) {
                continue;
            }
            boolean ok;
            if (mode.startsWith("user:")) {
                ok = p.author.equalsIgnoreCase(mode.substring(5));
            } else {
                switch (mode) {
                    case "P":
                        ok = p.kind == 'P';
                        break;
                    case "V":
                        ok = p.kind == 'V';
                        break;
                    case "favs":
                        ok = containsIgnoreCase(p.favs, me);
                        break;
                    case "following":
                        ok = containsIgnoreCase(fol, p.author) || p.author.equalsIgnoreCase(me);
                        break;
                    default:
                        ok = true;
                }
            }
            if (!ok) {
                continue;
            }
            if (out.size() >= limit) {
                more[0] = true;
                break;
            }
            out.add(p);
        }
        return out;
    }

    public synchronized Post get(String id) {
        return posts.get(id);
    }

    /** IGITEM|req|id|autore|tipo|ora|byte|w|h|durata|like|dislike|commenti|mioVoto|mioPreferito|condivisioni|didascalia|anteprima */
    public synchronized String describe(Post p, String me, String req) {
        int vote = containsIgnoreCase(p.likes, me) ? 1 : containsIgnoreCase(p.dislikes, me) ? -1 : 0;
        String prev = "";
        try {
            File f = new File(media, p.id + ".prev");
            if (f.isFile()) {
                prev = new String(Files.readAllBytes(f.toPath()), StandardCharsets.US_ASCII);
            }
        } catch (IOException ignored) {
            // senza anteprima
        }
        return "IGITEM|" + req + "|" + p.id + "|" + p.author + "|" + p.kind + "|" + p.time + "|" + p.size + "|" + p.w + "|"
                + p.h + "|" + p.dur + "|" + p.likes.size() + "|" + p.dislikes.size() + "|" + p.comments.size() + "|" + vote
                + "|" + (containsIgnoreCase(p.favs, me) ? 1 : 0) + "|" + p.shares + "|" + esc(p.caption) + "|" + prev;
    }

    public synchronized String counts(Post p) {
        return "IGCOUNT|" + p.id + "|" + p.likes.size() + "|" + p.dislikes.size() + "|" + p.comments.size() + "|" + p.shares;
    }

    public synchronized List<Comment> comments(String id) {
        Post p = posts.get(id);
        return p == null ? new ArrayList<>() : new ArrayList<>(p.comments);
    }

    public static String describe(String postId, Comment c) {
        return "IGCMT|" + postId + "|" + c.id + "|" + c.author + "|" + c.kind + "|" + c.time + "|" + esc(c.content);
    }

    /** Legge un pezzo del file del post (null se finito o inesistente). */
    public synchronized byte[] read(String id, long offset, int max) {
        Post p = posts.get(id);
        if (p == null) {
            return null;
        }
        try (RandomAccessFile f = new RandomAccessFile(new File(media, id + ".bin"), "r")) {
            if (offset >= f.length()) {
                return new byte[0];
            }
            int n = (int) Math.min(max, f.length() - offset);
            byte[] b = new byte[n];
            f.seek(offset);
            f.readFully(b);
            return b;
        } catch (IOException e) {
            return null;
        }
    }

    public synchronized long crc(String id) {
        CRC32 crc = new CRC32();
        byte[] buf = new byte[65536];
        try (FileInputStream in = new FileInputStream(new File(media, id + ".bin"))) {
            int n;
            while ((n = in.read(buf)) > 0) {
                crc.update(buf, 0, n);
            }
        } catch (IOException e) {
            return -1;
        }
        return crc.getValue();
    }

    // ================================================================ interazioni

    /** v = 1 mi piace, -1 non mi piace, 0 niente. */
    public synchronized Post vote(String id, String me, int v) {
        Post p = posts.get(id);
        if (p == null) {
            return null;
        }
        removeIgnoreCase(p.likes, me);
        removeIgnoreCase(p.dislikes, me);
        if (v > 0) {
            p.likes.add(me);
        } else if (v < 0) {
            p.dislikes.add(me);
        }
        dirty = true;
        return p;
    }

    public synchronized Post fav(String id, String me, boolean on) {
        Post p = posts.get(id);
        if (p == null) {
            return null;
        }
        removeIgnoreCase(p.favs, me);
        if (on) {
            p.favs.add(me);
        }
        dirty = true;
        return p;
    }

    public synchronized Post share(String id) {
        Post p = posts.get(id);
        if (p != null) {
            p.shares++;
            dirty = true;
        }
        return p;
    }

    /** @return il commento aggiunto, oppure null */
    public synchronized Comment comment(String id, String me, String cid, char kind, String content) {
        Post p = posts.get(id);
        if (p == null || cid == null || !cid.matches("[A-Za-z0-9]{4,40}") || content == null || content.trim().isEmpty()) {
            return null;
        }
        if (kind == 'T' && content.length() > MAX_COMMENT) {
            return null;
        }
        if (kind == 'S' && (content.length() > MAX_STICKER_CHARS || !content.matches("[A-Za-z0-9+/=]*"))) {
            return null;
        }
        if (kind == 'G' && (content.length() > 600 || !content.toLowerCase(Locale.ROOT).startsWith("https://"))) {
            return null;
        }
        if (kind != 'T' && kind != 'S' && kind != 'G') {
            return null;
        }
        for (Comment c : p.comments) {
            if (c.id.equals(cid)) {
                return null;
            }
        }
        if (p.comments.size() >= 2000) {
            return null;
        }
        Comment c = new Comment();
        c.id = cid;
        c.author = me;
        c.kind = kind;
        c.time = System.currentTimeMillis();
        c.content = content;
        p.comments.add(c);
        dirty = true;
        return c;
    }

    /** L'autore del commento o del post puo' eliminarlo. */
    public synchronized boolean uncomment(String id, String me, String cid) {
        Post p = posts.get(id);
        if (p == null) {
            return false;
        }
        boolean owner = p.author.equalsIgnoreCase(me);
        boolean removed = p.comments.removeIf(c -> c.id.equals(cid) && (owner || c.author.equalsIgnoreCase(me)));
        if (removed) {
            dirty = true;
        }
        return removed;
    }

    public synchronized boolean delete(String id, String me) {
        Post p = posts.get(id);
        if (p == null || !p.author.equalsIgnoreCase(me)) {
            return false;
        }
        posts.remove(id);
        for (String ext : new String[]{".bin", ".prev"}) {
            File f = new File(media, id + ext);
            if (f.exists() && !f.delete()) {
                f.deleteOnExit();
            }
        }
        dirty = true;
        return true;
    }

    public synchronized void setBio(String me, String bio) {
        String b = bio == null ? "" : bio.trim();
        bios.put(key(me), b.length() > MAX_BIO ? b.substring(0, MAX_BIO) : b);
        dirty = true;
    }

    public synchronized void follow(String me, String who, boolean on) {
        if (who == null || who.trim().isEmpty() || who.equalsIgnoreCase(me)) {
            return;
        }
        Set<String> s = following.computeIfAbsent(key(me), k -> new LinkedHashSet<>());
        removeIgnoreCase(s, who);
        if (on) {
            s.add(who.trim());
        }
        dirty = true;
    }

    /** IGPROF|utente|bio|post|seguaci|seguiti|loSeguo|foto|video */
    public synchronized String profile(String me, String who) {
        int n = 0;
        int photos = 0;
        int videos = 0;
        for (Post p : posts.values()) {
            if (p.author.equalsIgnoreCase(who)) {
                n++;
                if (p.kind == 'P') {
                    photos++;
                } else {
                    videos++;
                }
            }
        }
        int followers = 0;
        for (Set<String> s : following.values()) {
            if (containsIgnoreCase(s, who)) {
                followers++;
            }
        }
        Set<String> mine = following.getOrDefault(key(me), new LinkedHashSet<>());
        int fol = following.getOrDefault(key(who), new LinkedHashSet<>()).size();
        String canon = Accounts.getInstance().canonical(who);
        return "IGPROF|" + (canon == null ? who : canon) + "|" + esc(bios.getOrDefault(key(who), "")) + "|" + n + "|"
                + followers + "|" + fol + "|" + (containsIgnoreCase(mine, who) ? 1 : 0) + "|" + photos + "|" + videos;
    }

    /** Utenti che corrispondono alla ricerca (account registrati). */
    public synchronized List<String> search(String q) {
        List<String> out = new ArrayList<>();
        String s = q == null ? "" : q.trim().toLowerCase(Locale.ROOT);
        for (String u : Accounts.getInstance().users()) {
            if (s.isEmpty() || u.toLowerCase(Locale.ROOT).contains(s)) {
                out.add(u);
                if (out.size() >= 30) {
                    break;
                }
            }
        }
        return out;
    }

    public synchronized int size() {
        return posts.size();
    }

    // ================================================================ utilita'

    private static boolean containsIgnoreCase(Set<String> s, String v) {
        for (String x : s) {
            if (x.equalsIgnoreCase(v)) {
                return true;
            }
        }
        return false;
    }

    private static void removeIgnoreCase(Set<String> s, String v) {
        s.removeIf(x -> x.equalsIgnoreCase(v));
    }

    private static void split(String s, Set<String> into) {
        for (String x : s.split(",")) {
            if (!x.trim().isEmpty()) {
                into.add(x.trim());
            }
        }
    }

    private static String key(String s) {
        return s == null ? "" : s.trim().toLowerCase(Locale.ROOT);
    }

    static String esc(String s) {
        return s == null ? "" : s.replace("\\", "\\\\").replace("|", "\\p").replace("\n", "\\n").replace("\r", "");
    }

    static String unesc(String s) {
        StringBuilder sb = new StringBuilder(s.length());
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '\\' && i + 1 < s.length()) {
                char n = s.charAt(++i);
                sb.append(n == 'p' ? '|' : n == 'n' ? '\n' : n);
            } else {
                sb.append(c);
            }
        }
        return sb.toString();
    }
}
