package ghostchat.server;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * Final (server online): <b>rubrica dei contatti</b>. Gli utenti si trovano per
 * nome utente (univoco) e per scriversi serve una <b>richiesta di contatto
 * accettata</b>: finche' l'altro non accetta, messaggi, file, chiamate e giochi
 * non vengono consegnati. Contatti e richieste restano salvati sul server
 * ({@code contacts.txt} nella cartella dei dati).
 */
final class Contacts {

    private static final Contacts INSTANCE = new Contacts();

    static Contacts getInstance() {
        return INSTANCE;
    }

    /** utente -> contatti (chiavi in minuscolo). */
    private final Map<String, Set<String>> contacts = new HashMap<>();
    /** destinatario -> chi gli ha chiesto il contatto. */
    private final Map<String, Set<String>> incoming = new HashMap<>();
    private File file;

    private Contacts() {
    }

    static String key(String u) {
        return u == null ? "" : u.trim().toLowerCase(Locale.ROOT);
    }

    private static String display(String k) {
        String c = Accounts.getInstance().canonical(k);
        return c == null ? k : c;
    }

    // ================================================================ salvataggio

    synchronized void load() {
        file = new File(ServerConfig.dataDir(), "contacts.txt");
        if (!file.isFile()) {
            return;
        }
        try {
            for (String line : Files.readAllLines(file.toPath(), StandardCharsets.UTF_8)) {
                String[] f = line.split("\\|");
                if (f.length < 3) {
                    continue;
                }
                if (f[0].equals("C")) {
                    link(f[1], f[2]);
                } else if (f[0].equals("R")) {
                    incoming.computeIfAbsent(key(f[2]), k -> new LinkedHashSet<>()).add(key(f[1]));
                }
            }
            ServerLog.info("Contatti: " + pairs() + " coppie, " + requestsCount() + " richieste in attesa");
        } catch (Exception e) {
            ServerLog.error("Lettura dei contatti non riuscita", e);
        }
    }

    private int pairs() {
        int n = 0;
        for (Set<String> s : contacts.values()) {
            n += s.size();
        }
        return n / 2;
    }

    private int requestsCount() {
        int n = 0;
        for (Set<String> s : incoming.values()) {
            n += s.size();
        }
        return n;
    }

    private void save() {
        if (file == null) {
            return;
        }
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, Set<String>> e : contacts.entrySet()) {
            for (String b : e.getValue()) {
                if (e.getKey().compareTo(b) < 0) {
                    sb.append("C|").append(e.getKey()).append('|').append(b).append('\n');
                }
            }
        }
        for (Map.Entry<String, Set<String>> e : incoming.entrySet()) {
            for (String from : e.getValue()) {
                sb.append("R|").append(from).append('|').append(e.getKey()).append('\n');
            }
        }
        try {
            File tmp = new File(file.getPath() + ".tmp");
            Files.write(tmp.toPath(), sb.toString().getBytes(StandardCharsets.UTF_8));
            Files.move(tmp.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING);
        } catch (Exception e) {
            ServerLog.error("Salvataggio dei contatti non riuscito", e);
        }
    }

    private void link(String a, String b) {
        contacts.computeIfAbsent(key(a), k -> new LinkedHashSet<>()).add(key(b));
        contacts.computeIfAbsent(key(b), k -> new LinkedHashSet<>()).add(key(a));
    }

    // ================================================================ domande

    synchronized boolean areContacts(String a, String b) {
        Set<String> s = contacts.get(key(a));
        return s != null && s.contains(key(b));
    }

    /** Contatti di {@code u} con il nome utente scritto come alla registrazione. */
    synchronized List<String> contactsOf(String u) {
        List<String> out = new ArrayList<>();
        Set<String> s = contacts.get(key(u));
        if (s != null) {
            for (String k : s) {
                out.add(display(k));
            }
        }
        Collections.sort(out, String.CASE_INSENSITIVE_ORDER);
        return out;
    }

    /** Chi ha chiesto il contatto a {@code u}. */
    synchronized List<String> incomingOf(String u) {
        List<String> out = new ArrayList<>();
        Set<String> s = incoming.get(key(u));
        if (s != null) {
            for (String k : s) {
                out.add(display(k));
            }
        }
        return out;
    }

    /** A chi {@code u} ha chiesto il contatto (ancora senza risposta). */
    synchronized List<String> outgoingOf(String u) {
        List<String> out = new ArrayList<>();
        String me = key(u);
        for (Map.Entry<String, Set<String>> e : incoming.entrySet()) {
            if (e.getValue().contains(me)) {
                out.add(display(e.getKey()));
            }
        }
        return out;
    }

    /** Stato visto da {@code me}: c = contatto, o = richiesta inviata, i = richiesta ricevuta, n = nessuno. */
    synchronized char state(String me, String other) {
        if (areContacts(me, other)) {
            return 'c';
        }
        Set<String> in = incoming.get(key(other));
        if (in != null && in.contains(key(me))) {
            return 'o';
        }
        Set<String> mine = incoming.get(key(me));
        if (mine != null && mine.contains(key(other))) {
            return 'i';
        }
        return 'n';
    }

    // ================================================================ azioni

    /**
     * Richiesta di contatto. @return "sent", "accepted" (l'altro l'aveva gia' chiesta
     * a te: diventate subito contatti), "already" oppure un messaggio d'errore.
     */
    synchronized String request(String from, String to) {
        String a = key(from);
        String b = key(to);
        if (a.equals(b)) {
            return "Non puoi aggiungere te stesso";
        }
        if (!Accounts.getInstance().exists(b)) {
            return "Il nome utente \"" + Protocol.clean(to) + "\" non esiste";
        }
        if (areContacts(a, b)) {
            return "already";
        }
        Set<String> mine = incoming.get(a);
        if (mine != null && mine.remove(b)) {
            link(a, b);
            save();
            return "accepted";
        }
        Set<String> theirs = incoming.computeIfAbsent(b, k -> new LinkedHashSet<>());
        if (theirs.size() >= 200) {
            return "Questo utente ha troppe richieste in attesa: riprova più tardi";
        }
        theirs.add(a);
        save();
        return "sent";
    }

    /** {@code me} risponde alla richiesta di {@code from}. @return true se c'era una richiesta. */
    synchronized boolean answer(String me, String from, boolean accept) {
        Set<String> mine = incoming.get(key(me));
        if (mine == null || !mine.remove(key(from))) {
            return false;
        }
        if (accept) {
            link(me, from);
        }
        save();
        return true;
    }

    /** Ritira una richiesta inviata. */
    synchronized boolean cancel(String from, String to) {
        Set<String> theirs = incoming.get(key(to));
        boolean ok = theirs != null && theirs.remove(key(from));
        if (ok) {
            save();
        }
        return ok;
    }

    synchronized boolean remove(String a, String b) {
        Set<String> sa = contacts.get(key(a));
        Set<String> sb = contacts.get(key(b));
        boolean ok = sa != null && sa.remove(key(b));
        if (sb != null) {
            sb.remove(key(a));
        }
        if (ok) {
            save();
        }
        return ok;
    }

    /** Quando un account viene eliminato. */
    synchronized void forget(String u) {
        String k = key(u);
        Set<String> s = contacts.remove(k);
        if (s != null) {
            for (String o : s) {
                Set<String> x = contacts.get(o);
                if (x != null) {
                    x.remove(k);
                }
            }
        }
        incoming.remove(k);
        for (Set<String> in : incoming.values()) {
            in.remove(k);
        }
        save();
    }

    /** Ricerca per nome utente: prima chi inizia con la ricerca, poi chi la contiene. */
    static List<String> search(String query, String me, int max) {
        String q = key(query).replace("@", "");
        List<String> starts = new ArrayList<>();
        List<String> contains = new ArrayList<>();
        if (q.isEmpty()) {
            return starts;
        }
        for (String u : Accounts.getInstance().users()) {
            String k = key(u);
            if (k.equals(key(me))) {
                continue;
            }
            if (k.startsWith(q)) {
                starts.add(u);
            } else if (q.length() >= 2 && k.contains(q)) {
                contains.add(u);
            }
        }
        starts.sort((x, y) -> x.length() != y.length() ? x.length() - y.length() : x.compareToIgnoreCase(y));
        contains.sort(String.CASE_INSENSITIVE_ORDER);
        starts.addAll(contains);
        return starts.size() > max ? new ArrayList<>(starts.subList(0, max)) : starts;
    }
}
