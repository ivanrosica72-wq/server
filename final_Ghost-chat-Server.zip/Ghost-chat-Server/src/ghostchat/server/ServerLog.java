package ghostchat.server;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Log del server: stampa SOLO a console (RT-02), con data e ora.
 * I metodi sono synchronized perche' vengono chiamati da piu' thread.
 */
public final class ServerLog {

    private static final SimpleDateFormat FORMAT = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");

    private ServerLog() {
    }

    public static synchronized void info(String message) {
        print("INFO ", message, false);
    }

    public static synchronized void warn(String message) {
        print("AVVISO", message, false);
    }

    public static synchronized void error(String message, Throwable t) {
        String detail = t == null ? "" : " -> " + t.getClass().getSimpleName()
                + (t.getMessage() != null ? ": " + t.getMessage() : "");
        print("ERRORE", message + detail, true);
    }

    /** Stampa una riga "nuda", senza data (per banner e comandi da console). */
    public static synchronized void plain(String message) {
        try {
            System.out.println(message);
            System.out.flush();
        } catch (Throwable ignored) {
            // la console non e' disponibile: non c'e' altro da fare
        }
    }

    private static void print(String level, String message, boolean err) {
        try {
            String line = "[" + FORMAT.format(new Date()) + "] " + level + " | " + message;
            if (err) {
                System.err.println(line);
                System.err.flush();
            } else {
                System.out.println(line);
                System.out.flush();
            }
        } catch (Throwable ignored) {
            // la console non e' disponibile: non c'e' altro da fare
        }
    }
}
