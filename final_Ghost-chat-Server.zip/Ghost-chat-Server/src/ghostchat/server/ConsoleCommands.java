package ghostchat.server;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.List;

/**
 * Comandi digitabili nella console del server (anche nella finestra Output di NetBeans).
 * Se la console non accetta input il thread termina senza disturbare il server.
 */
public class ConsoleCommands implements Runnable {

    @Override
    public void run() {
        try {
            BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
            String line;
            while ((line = in.readLine()) != null) {
                try {
                    execute(line.trim().toLowerCase());
                } catch (Throwable t) {
                    ServerLog.error("Comando non eseguito", t);
                }
            }
        } catch (Throwable t) {
            // nessuna console disponibile: il server funziona lo stesso
        }
    }

    private void execute(String cmd) {
        switch (cmd) {
            case "":
                return;
            case "aiuto":
            case "help":
            case "?":
                ServerLog.plain("Comandi disponibili:");
                ServerLog.plain("  utenti   elenco degli utenti online");
                ServerLog.plain("  stato    numero di connessioni e utenti");
                ServerLog.plain("  esci     arresta il server");
                return;
            case "utenti":
            case "lista":
            case "users": {
                List<ClientHandler> list = ClientRegistry.getInstance().snapshot();
                if (list.isEmpty()) {
                    ServerLog.plain("Nessun utente online.");
                } else {
                    ServerLog.plain("Utenti online (" + list.size() + "):");
                    for (ClientHandler h : list) {
                        ServerLog.plain("  - " + h.getNickname() + " @ " + h.getIp() + (h.isHidden() ? " (stato nascosto)" : ""));
                    }
                }
                return;
            }
            case "stato":
            case "status":
                ServerLog.plain("Connessioni attive: " + ClientHandler.getActiveConnections()
                        + " | utenti registrati: " + ClientRegistry.getInstance().size()
                        + " | gruppi: " + Groups.getInstance().size()
                        + " | stati attivi: " + StatusStore.getInstance().size()
                        + " | account: " + Accounts.getInstance().size() + " | post InstaGhost: " + InstaGhost.getInstance().size());
                return;
            case "esci":
            case "stop":
            case "exit":
            case "quit":
                GhostChatServer.shutdownNow();
                System.exit(0);
                return;
            default:
                ServerLog.plain("Comando sconosciuto: \"" + cmd + "\". Scrivi \"aiuto\".");
        }
    }
}
