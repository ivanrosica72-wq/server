package ghostchat.server;

/**
 * Protocollo testuale di Ghost-chat (una riga per messaggio, codifica UTF-8).
 *
 * <pre>
 *  Client -> Server
 *    NICK|&lt;nickname&gt;                    registrazione del nickname alla connessione
 *    MSG|&lt;destinatario&gt;|&lt;id&gt;|&lt;testo&gt;     messaggio da inoltrare al destinatario
 *    EDIT|&lt;dest&gt;|&lt;id&gt;|&lt;nuovo testo&gt;      messaggio modificato
 *    DEL|&lt;dest&gt;|&lt;id&gt;                    messaggio eliminato per tutti
 *    ACK|&lt;dest&gt;|&lt;id,id..&gt;|D o R|&lt;ora&gt;    conferma di consegna (D) o di lettura (R)
 *    POLL|&lt;dest&gt;|&lt;id&gt;|&lt;multi&gt;|&lt;domanda&gt;|&lt;opzione&gt;|...  sondaggio
 *    VOTE|&lt;dest&gt;|&lt;idSondaggio&gt;|&lt;indici&gt;  voto (tutte le scelte di chi vota)
 *    VIDEO|&lt;dest&gt;|&lt;idChiamata&gt;|&lt;jpeg base64&gt;  fotogramma della videochiamata
 *    VIDSTATE|&lt;dest&gt;|&lt;idChiamata&gt;|cam/screen/off  stato del video
 *    FILE|&lt;dest&gt;|&lt;id&gt;|&lt;tipo&gt;|&lt;byte&gt;|&lt;nome&gt;|&lt;extra&gt;   inizio invio di un file (foto, video, file, vocale)
 *    CHUNK|&lt;dest&gt;|&lt;id&gt;|&lt;dati base64&gt;      un pezzo del file
 *    FILEEND|&lt;dest&gt;|&lt;id&gt;|&lt;crc32&gt;         fine del file (con controllo di integrita')
 *    FILECANCEL|&lt;dest&gt;|&lt;id&gt;              invio annullato
 *    FILEPOS|&lt;dest&gt;|&lt;id&gt;|&lt;byte&gt;         (v7) da dove riprendere un invio interrotto
 *    CALL|&lt;dest&gt;|&lt;idChiamata&gt;             chiamata vocale in arrivo
 *    CALLACCEPT|&lt;dest&gt;|&lt;idChiamata&gt;       chiamata accettata
 *    CALLREJECT|&lt;dest&gt;|&lt;idChiamata&gt;|&lt;motivo&gt;  chiamata rifiutata / occupato
 *    CALLEND|&lt;dest&gt;|&lt;idChiamata&gt;          fine chiamata
 *    AUDIO|&lt;dest&gt;|&lt;idChiamata&gt;|&lt;base64&gt;  audio della chiamata (circa 40 ms)
 *    --- v4 ---
 *    MSG|&lt;dest&gt;|&lt;id&gt;|&lt;meta&gt;|&lt;testo&gt;  meta = r=idRisposta;f=1 (inoltrato) ...
 *    REACT|&lt;dest&gt;|&lt;idMsg&gt;|&lt;emoji&gt;      reazione (vuota = tolta)
 *    PIN|&lt;dest&gt;|&lt;idMsg&gt;|1 o 0          messaggio fissato / non piu' fissato
 *    LOC|&lt;dest&gt;|&lt;id&gt;|...  LOCUPD  LOCSTOP  posizione (anche in tempo reale)
 *    LINK|&lt;dest&gt;|&lt;idMsg&gt;|...            anteprima di un link
 *    GAME|&lt;dest&gt;|&lt;idPartita&gt;|...         mossa di un minigioco
 *    CALLREACT|&lt;dest&gt;|&lt;idChiamata&gt;|&lt;emoji&gt;  reazione durante la chiamata
 *    PRESENCE|0 o 1                      1 = stato nascosto
 *    AVATAR|&lt;jpeg base64&gt;                foto profilo (vuota = tolta)
 *    GCREATE|&lt;idGruppo&gt;|&lt;nome&gt;|&lt;m1,m2&gt;   crea un gruppo
 *    GADD|&lt;id&gt;|&lt;m1,m2&gt;  GKICK|&lt;id&gt;|&lt;nick&gt;  GLEAVE|&lt;id&gt;  GNAME|&lt;id&gt;|&lt;nome&gt;  GPHOTO|&lt;id&gt;|&lt;b64&gt;
 *    #&lt;idGruppo&gt; come destinatario      il comando va a tutti i membri del gruppo
 *    SPOST|&lt;id&gt;|T/I/G/V|&lt;byte&gt;|&lt;meta&gt;|&lt;testo&gt;  SCHUNK|&lt;id&gt;|&lt;b64&gt;  SEND|&lt;id&gt;|&lt;crc&gt;  pubblica uno stato
 *    SGET|&lt;autore&gt;|&lt;id&gt;  SSEEN|&lt;autore&gt;|&lt;id&gt;  SDEL|&lt;id&gt;   contenuto / visto / elimina
 *    PING                                controllo che la connessione sia viva
 *    QUIT                                disconnessione volontaria
 *
 *  Server -> Client
 *    WELCOME|&lt;nickname&gt;|&lt;ip&gt;            registrazione accettata (IP visto dal server)
 *    NICKERR|&lt;descrizione&gt;                nickname rifiutato (gia' in uso / non valido)
 *    LIST|&lt;nick&gt;@&lt;ip&gt;;&lt;nick&gt;@&lt;ip&gt;...    elenco aggiornato degli utenti online
 *    MSG|&lt;mittente&gt;|&lt;id&gt;|&lt;testo&gt;         messaggio inoltrato al destinatario
 *    EDIT / DEL / ACK / POLL / VOTE / FILE / CHUNK / FILEEND / FILECANCEL / CALL... / AUDIO / VIDEO
 *                                        inoltrati identici, con il MITTENTE al posto del destinatario
 *    ERR|&lt;descrizione&gt;[|&lt;destinatario&gt;[|&lt;id&gt;]]  errore (es. destinatario offline)
 *    --- v4 ---
 *    LIST|&lt;nick&gt;@&lt;ip&gt;@&lt;0/1&gt;;...          elenco con lo stato nascosto (IP vuoto se nascosto)
 *    AVATAR|&lt;nick&gt;|&lt;b64&gt;                 foto profilo di un utente
 *    GROUP|&lt;id&gt;|&lt;nome&gt;|&lt;admin&gt;|&lt;membri&gt;  GPHOTO|&lt;id&gt;|&lt;b64&gt;  GROUPGONE|&lt;id&gt;
 *    GEVENT|&lt;id&gt;|&lt;chi&gt;|create/add/kick/leave/name/photo|&lt;su chi&gt;
 *    GCALL|&lt;id&gt;|&lt;idChiamata&gt;|A/V|&lt;partecipanti&gt;   chiamata del gruppo
 *    CMD|#&lt;idGruppo&gt;/&lt;mittente&gt;|...       comando inoltrato da un gruppo
 *    STATUS|&lt;autore&gt;|&lt;id&gt;|&lt;tipo&gt;|&lt;ora&gt;|&lt;byte&gt;|&lt;meta&gt;|&lt;testo&gt;   SGONE|&lt;autore&gt;|&lt;id&gt;
 *    SDATA|&lt;autore&gt;|&lt;id&gt;|&lt;b64&gt;  SDATAEND|&lt;autore&gt;|&lt;id&gt;|&lt;crc&gt;   SSEEN|&lt;chi&gt;|&lt;id&gt;|&lt;ora&gt;
 *    PONG                                risposta a PING
 *    BYE|&lt;motivo&gt;                         il server sta chiudendo la connessione
 * </pre>
 *
 * Il testo dei messaggi viaggia "escapato" (\\ e \n) cosi' i messaggi su piu'
 * righe restano comunque su UNA riga del protocollo. Il server non ha bisogno
 * di decodificarlo: lo inoltra cosi' com'e'.
 */
public final class Protocol {

    public static final int DEFAULT_PORT = 11112;

    /** Separatore dei campi. */
    public static final String SEP = "|";
    public static final String SEP_REGEX = "\\|";

    public static final String NICK = "NICK";
    public static final String MSG = "MSG";
    public static final String PING = "PING";
    public static final String QUIT = "QUIT";

    public static final String FILE = "FILE";
    public static final String CHUNK = "CHUNK";
    public static final String FILEEND = "FILEEND";
    public static final String FILECANCEL = "FILECANCEL";
    /** v7: FILEPOS|dest|id|byte : chi riceve dice da dove riprendere un invio interrotto */
    public static final String FILEPOS = "FILEPOS";
    public static final String CALL = "CALL";
    public static final String CALLACCEPT = "CALLACCEPT";
    public static final String CALLREJECT = "CALLREJECT";
    public static final String CALLEND = "CALLEND";
    public static final String AUDIO = "AUDIO";
    public static final String EDIT = "EDIT";
    public static final String DEL = "DEL";
    public static final String ACK = "ACK";
    public static final String POLL = "POLL";
    public static final String VOTE = "VOTE";
    public static final String VIDEO = "VIDEO";
    public static final String VIDSTATE = "VIDSTATE";
    // v4
    public static final String REACT = "REACT";
    public static final String PIN = "PIN";
    public static final String LOC = "LOC";
    public static final String LOCUPD = "LOCUPD";
    public static final String LOCSTOP = "LOCSTOP";
    public static final String LINK = "LINK";
    public static final String GAME = "GAME";
    public static final String CALLREACT = "CALLREACT";
    public static final String PRESENCE = "PRESENCE";
    public static final String AVATAR = "AVATAR";
    public static final String GCREATE = "GCREATE";
    public static final String GADD = "GADD";
    public static final String GKICK = "GKICK";
    public static final String GLEAVE = "GLEAVE";
    public static final String GNAME = "GNAME";
    public static final String GPHOTO = "GPHOTO";
    public static final String GROUP = "GROUP";
    public static final String GROUPGONE = "GROUPGONE";
    public static final String GEVENT = "GEVENT";
    // v5
    /** TYPING|dest|t/r/0 : sta scrivendo / sta registrando / ha smesso */
    public static final String TYPING = "TYPING";
    /** WB|dest|idLavagna|azione|dati : lavagna condivisa */
    public static final String WB = "WB";
    /** GADMIN|gid|nick|1/0 */
    public static final String GADMIN = "GADMIN";
    /** GDESC|gid|testo */
    public static final String GDESC = "GDESC";
    /** GPERM|gid|1/0 : solo gli amministratori possono scrivere */
    public static final String GPERM = "GPERM";
    /** GINVITE|gid|new/get/revoke  ->  GINVITE|gid|codice */
    public static final String GINVITE = "GINVITE";
    /** GJOIN|codice */
    public static final String GJOIN = "GJOIN";
    public static final String GCALL = "GCALL";
    public static final String SPOST = "SPOST";
    public static final String SCHUNK = "SCHUNK";
    public static final String SEND = "SEND";
    public static final String SGET = "SGET";
    public static final String SSEEN = "SSEEN";
    public static final String SDEL = "SDEL";
    public static final String STATUS = "STATUS";
    public static final String SGONE = "SGONE";
    public static final String SDATA = "SDATA";
    public static final String SDATAEND = "SDATAEND";

    /** Foto profilo massima (jpeg in base64). */
    public static final int MAX_AVATAR_CHARS = 96 * 1024;

    public static final String WELCOME = "WELCOME";
    public static final String NICKERR = "NICKERR";
    public static final String LIST = "LIST";
    public static final String ERR = "ERR";
    public static final String PONG = "PONG";
    public static final String BYE = "BYE";

    /** Lunghezza massima di una riga del protocollo (caratteri): i pezzi di file sono di 64 KB. */
    public static final int MAX_LINE_LENGTH = 256 * 1024;
    /** Dimensione massima di un file inviabile. */
    public static final long MAX_FILE_SIZE = 100L * 1024 * 1024;
    /** Lunghezza massima dei dati audio di una riga AUDIO. */
    public static final int MAX_AUDIO_CHARS = 32 * 1024;
    /** Lunghezza massima di un fotogramma video (jpeg in base64). */
    public static final int MAX_VIDEO_CHARS = 200 * 1024;
    /** Lunghezza massima del testo (escapato) di un messaggio. */
    public static final int MAX_TEXT_LENGTH = 8000;
    public static final int MAX_NICK_LENGTH = 20;

    /** Se un client non invia nulla per questo tempo viene considerato disconnesso. */
    public static final int READ_TIMEOUT_MS = 75_000;

    private Protocol() {
    }

    /**
     * Valida un nickname.
     *
     * @return null se valido, altrimenti la descrizione dell'errore
     */
    public static String validateNickname(String nick) {
        if (nick == null || nick.trim().isEmpty()) {
            return "Il nickname non può essere vuoto";
        }
        String n = nick.trim();
        if (n.length() > MAX_NICK_LENGTH) {
            return "Il nickname può avere al massimo " + MAX_NICK_LENGTH + " caratteri";
        }
        for (int i = 0; i < n.length(); i++) {
            char c = n.charAt(i);
            if (c == '|' || c == ';' || c == '@' || c == '\\' || c == '#' || c == '/' || c == ','
                    || Character.isISOControl(c)) {
                return "Il nickname non può contenere i caratteri | ; @ \\ # / ,";
            }
        }
        return null;
    }

    /** Rimuove dal testo eventuali caratteri che romperebbero il protocollo. */
    public static String clean(String s) {
        if (s == null) {
            return "";
        }
        StringBuilder sb = new StringBuilder(s.length());
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '\r' || c == '\n') {
                sb.append(' ');
            } else {
                sb.append(c);
            }
        }
        return sb.toString();
    }
}
