package ghostchat.server;

import java.util.Base64;
import java.util.List;
import java.util.Locale;

/**
 * Final: comandi della versione final (account, consenso ai gruppi, giochi di
 * carte, InstaGhost). Separati da {@link ClientHandler} per tenerlo leggibile.
 *
 * <pre>
 * ACCOUNT|info · ACCOUNT|email|indirizzo · ACCOUNT|verify|codice · ACCOUNT|noemail
 * ACCOUNT|passwd|vecchiaB64|nuovaB64 · ACCOUNT|logout|gettone
 * GCONSENT|gid|1|0 (accetta / rifiuta l'invito) · GINVCANCEL|gid|nick (admin)
 * CARD|gid|idPartita|new|tipo|giocatori · accept · decline · play|carta · hit · stand · quit · state
 *   → CARDS|gid|{json} a tutti i membri del gruppo (ognuno vede solo le sue carte)
 * IGPOST|id|P/V|byte|w|h|durata|didascalia · IGPREV|id|b64 · IGCHUNK|id|b64 · IGUPEND|id|crc · IGABORT|id
 * IGFEED|req|modo|prima|quanti → IGITEM|req|… · IGEND|req|n|altri
 * IGONE|req|id → IGITEM|req|… · IGGET|id|offset → IGDATA|id|offset|b64 · IGDATAEND|id|crc|byte
 * IGVOTE|id|1/-1/0 · IGFAV|id|1/0 · IGSHARE|id · IGDEL|id → IGCOUNT|… / IGGONE|id
 * IGCOMMENT|id|cid|T/S/G|contenuto · IGUNCOMMENT|id|cid · IGCOMMENTS|id → IGCMT|… IGCMTEND|id
 * IGBIO|testo · IGFOLLOW|utente|1/0 · IGPROFILE|utente → IGPROF|… · IGSEARCH|testo → IGUSER|… IGUSEREND
 * </pre>
 */
final class FinalFeatures {

    private static final int CHUNK = 48 * 1024;

    private FinalFeatures() {
    }

    static void handle(ClientHandler h, String cmd, String rest) throws InterruptedException {
        String me = h.getNickname();
        String[] f = rest.split("\\|", -1);
        switch (cmd) {
            case "ACCOUNT":
                account(h, me, f);
                break;
            case "GCONSENT": {
                String gid = f[0].trim();
                boolean yes = f.length > 1 && f[1].trim().equals("1");
                Groups g = Groups.getInstance();
                String r = g.answer(gid, me, yes);
                if (r.startsWith("!")) {
                    h.send(Protocol.ERR + Protocol.SEP + r.substring(1));
                    return;
                }
                if (yes) {
                    ServerLog.info(me + " ha accettato l'invito a un gruppo");
                    h.notifyGroupPublic(gid, Protocol.GEVENT + Protocol.SEP + gid + Protocol.SEP + me + Protocol.SEP + "accept"
                            + Protocol.SEP + me);
                    h.sendGroupExtrasPublic(gid, java.util.Collections.singletonList(me));
                } else {
                    ServerLog.info(me + " ha rifiutato l'invito a un gruppo");
                    String state = g.describe(gid);
                    if (state != null) {
                        ClientRegistry.getInstance().sendTo(g.members(gid), state, null);
                    }
                    ClientRegistry.getInstance().sendTo(g.members(gid), Protocol.GEVENT + Protocol.SEP + gid + Protocol.SEP
                            + me + Protocol.SEP + "decline" + Protocol.SEP + me, null);
                }
                break;
            }
            case "GINVCANCEL": {
                String gid = f[0].trim();
                String who = f.length > 1 ? f[1].trim() : "";
                Groups g = Groups.getInstance();
                if (!g.isAdmin(gid, me) || !g.cancelInvite(gid, who)) {
                    h.send(Protocol.ERR + Protocol.SEP + "Invito non annullato");
                    return;
                }
                ClientHandler t = ClientRegistry.getInstance().find(who);
                if (t != null) {
                    t.send("GINVGONE" + Protocol.SEP + gid);
                }
                String state = g.describe(gid);
                if (state != null) {
                    ClientRegistry.getInstance().sendTo(g.members(gid), state, null);
                }
                break;
            }
            case "CARD":
                card(h, me, f);
                break;
            default:
                insta(h, me, cmd, rest, f);
        }
    }

    /** Manda l'invito (con richiesta di consenso) a chi e' online. */
    static void sendInvites(String gid) {
        Groups g = Groups.getInstance();
        for (ClientHandler c : ClientRegistry.getInstance().snapshot()) {
            String line = g.inviteLine(gid, c.getNickname());
            if (line != null) {
                c.send(line);
            }
        }
    }

    // ================================================================ account

    private static void account(ClientHandler h, String me, String[] f) {
        Accounts a = Accounts.getInstance();
        String action = f[0].trim().toLowerCase(Locale.ROOT);
        switch (action) {
            case "info":
                h.send("ACCOUNT|info|" + a.email(me) + "|" + (a.emailVerified(me) ? "1" : "0"));
                break;
            case "email": {
                String email = f.length > 1 ? f[1].trim() : "";
                String[] c = a.startEmailChange(me, email);
                if (c[0] == null) {
                    h.send("ACCOUNT|err|" + c[1]);
                    return;
                }
                h.mailCode(email, "Conferma la tua email", "Ciao " + me + ",\n\nil codice per confermare la tua email su"
                        + " Ghost-chat è:\n\n    " + c[0] + "\n\nScade tra 10 minuti.", "ACCOUNT|codesent|" + email);
                break;
            }
            case "verify": {
                String err = a.verifyEmail(me, f.length > 1 ? f[1] : "");
                h.send(err == null ? "ACCOUNT|verified|" + a.email(me) : "ACCOUNT|err|" + err);
                break;
            }
            case "noemail":
                a.removeEmail(me);
                h.send("ACCOUNT|info||0");
                break;
            case "passwd": {
                String err = a.changePassword(me, f.length > 1 ? ClientHandler.b64(f[1]) : "",
                        f.length > 2 ? ClientHandler.b64(f[2]) : "", h.getIp());
                if (err != null) {
                    h.send("ACCOUNT|err|" + err);
                } else {
                    h.send("ACCOUNT|passwdok|" + a.newToken(me));
                }
                break;
            }
            case "logout":
                a.revokeToken(me, f.length > 1 ? f[1] : "");
                break;
            default:
                h.send("ACCOUNT|err|Comando non valido");
        }
    }

    // ================================================================ carte

    private static void card(ClientHandler h, String me, String[] f) {
        if (f.length < 3) {
            return;
        }
        String gid = f[0].trim();
        String gameId = f[1].trim();
        String action = f[2].trim().toLowerCase(Locale.ROOT);
        Groups groups = Groups.getInstance();
        if (!groups.isMember(gid, me)) {
            h.sendErrorPublic("I giochi di carte sono per i membri del gruppo", "#" + gid, gameId);
            return;
        }
        String[] args = new String[Math.max(0, f.length - 3)];
        System.arraycopy(f, 3, args, 0, args.length);
        String[] err = new String[1];
        CardGames cg = CardGames.getInstance();
        CardGames.Game g = cg.act(gid, gameId, me, action, args, err);
        if (err[0] != null) {
            h.sendErrorPublic(err[0], "#" + gid, gameId);
            return;
        }
        if (g == null) {
            return;
        }
        if (action.equals("state")) {
            h.send("CARDS" + Protocol.SEP + gid + Protocol.SEP + cg.view(g, me));
            return;
        }
        if (action.equals("new")) {
            ServerLog.info(me + " propone una partita a " + g.type + " in un gruppo");
        }
        for (String m : cg.recipients(g)) {
            ClientHandler c = ClientRegistry.getInstance().find(m);
            if (c != null) {
                c.send("CARDS" + Protocol.SEP + gid + Protocol.SEP + cg.view(g, m));
            }
        }
    }

    // ================================================================ InstaGhost

    private static void insta(ClientHandler h, String me, String cmd, String rest, String[] f) throws InterruptedException {
        InstaGhost ig = InstaGhost.getInstance();
        ClientRegistry reg = ClientRegistry.getInstance();
        switch (cmd) {
            case "IGPOST": {
                // IGPOST|id|tipo|byte|w|h|durata|didascalia
                String[] p = rest.split("\\|", 7);
                if (p.length < 7 || p[1].trim().isEmpty()) {
                    h.send("IGERR|" + (p.length > 0 ? p[0] : "") + "|Post non valido");
                    return;
                }
                String err = ig.begin(me, p[0].trim(), p[1].trim().charAt(0), num(p[2]), (int) num(p[3]), (int) num(p[4]),
                        num(p[5]), InstaGhost.unesc(p[6]));
                if (err != null) {
                    h.send("IGERR|" + p[0].trim() + "|" + err);
                }
                break;
            }
            case "IGPREV":
                if (f.length < 2 || !ig.preview(me, f[0].trim(), f[1].trim())) {
                    h.send("IGERR|" + f[0].trim() + "|Anteprima non valida");
                }
                break;
            case "IGCHUNK": {
                byte[] data;
                try {
                    data = Base64.getDecoder().decode(f.length > 1 ? f[1].trim() : "");
                } catch (IllegalArgumentException e) {
                    data = null;
                }
                if (data == null || !ig.chunk(me, f[0].trim(), data)) {
                    h.send("IGERR|" + f[0].trim() + "|Caricamento interrotto");
                }
                break;
            }
            case "IGUPEND": {
                InstaGhost.Post p = ig.finish(me, f[0].trim(), f.length > 1 ? f[1] : "");
                if (p == null) {
                    h.send("IGERR|" + f[0].trim() + "|Post non pubblicato: dati danneggiati");
                    return;
                }
                ServerLog.info(me + " ha pubblicato su InstaGhost (" + (p.kind == 'P' ? "foto" : "Ghost-tube") + ")");
                h.send("IGDONE|" + p.id);
                for (ClientHandler c : reg.snapshot()) {
                    c.send(ig.describe(p, c.getNickname(), "new"));
                }
                break;
            }
            case "IGABORT":
                ig.abort(me, f[0].trim());
                break;
            case "IGFEED": {
                String req = f[0].trim();
                String mode = f.length > 1 ? f[1].trim() : "all";
                long before = f.length > 2 ? num(f[2]) : 0;
                int limit = f.length > 3 ? (int) num(f[3]) : 12;
                boolean[] more = new boolean[1];
                List<InstaGhost.Post> list = ig.feed(me, mode, before, limit, more);
                for (InstaGhost.Post p : list) {
                    h.enqueue(ig.describe(p, me, req), Outbox.Priority.HIGH, 5000);
                }
                h.send("IGEND|" + req + "|" + list.size() + "|" + (more[0] ? 1 : 0) + "|"
                        + (list.isEmpty() ? 0 : list.get(list.size() - 1).time));
                break;
            }
            case "IGONE": {
                InstaGhost.Post p = ig.get(f.length > 1 ? f[1].trim() : "");
                if (p == null) {
                    h.send("IGGONE|" + (f.length > 1 ? f[1].trim() : ""));
                } else {
                    h.send(ig.describe(p, me, f[0].trim()));
                }
                break;
            }
            case "IGGET": {
                final String id = f[0].trim();
                final long offset = f.length > 1 ? Math.max(0, num(f[1])) : 0;
                final InstaGhost.Post p = ig.get(id);
                if (p == null) {
                    h.send("IGGONE|" + id);
                    return;
                }
                // in un thread a parte: un video grande non blocca gli altri comandi
                Thread t = new Thread(() -> {
                    try {
                        long pos = offset;
                        while (true) {
                            byte[] b = ig.read(id, pos, CHUNK);
                            if (b == null) {
                                h.send("IGGONE|" + id);
                                return;
                            }
                            if (b.length == 0) {
                                break;
                            }
                            if (!h.enqueue("IGDATA|" + id + "|" + pos + "|" + Base64.getEncoder().encodeToString(b),
                                    Outbox.Priority.BULK, 30_000)) {
                                return;
                            }
                            pos += b.length;
                        }
                        h.enqueue("IGDATAEND|" + id + "|" + Long.toHexString(ig.crc(id)) + "|" + p.size, Outbox.Priority.BULK, 30_000);
                    } catch (InterruptedException ignored) {
                        // fine
                    }
                }, "ig-download");
                t.setDaemon(true);
                t.start();
                break;
            }
            case "IGVOTE": {
                InstaGhost.Post p = ig.vote(f[0].trim(), me, f.length > 1 ? (int) num(f[1]) : 0);
                if (p != null) {
                    reg.broadcast(ig.counts(p), null);
                }
                break;
            }
            case "IGFAV": {
                InstaGhost.Post p = ig.fav(f[0].trim(), me, f.length > 1 && f[1].trim().equals("1"));
                if (p != null) {
                    h.send("IGFAVOK|" + p.id + "|" + (f.length > 1 && f[1].trim().equals("1") ? 1 : 0));
                }
                break;
            }
            case "IGSHARE": {
                InstaGhost.Post p = ig.share(f[0].trim());
                if (p != null) {
                    reg.broadcast(ig.counts(p), null);
                }
                break;
            }
            case "IGCOMMENT": {
                // IGCOMMENT|id|cid|tipo|contenuto
                String[] p = rest.split("\\|", 4);
                if (p.length < 4 || p[2].trim().isEmpty()) {
                    return;
                }
                InstaGhost.Comment c = ig.comment(p[0].trim(), me, p[1].trim(), p[2].trim().charAt(0), InstaGhost.unesc(p[3]));
                if (c == null) {
                    h.send("IGERR|" + p[0].trim() + "|Commento non valido");
                    return;
                }
                reg.broadcast(InstaGhost.describe(p[0].trim(), c), null);
                InstaGhost.Post post = ig.get(p[0].trim());
                if (post != null) {
                    reg.broadcast(ig.counts(post), null);
                }
                break;
            }
            case "IGUNCOMMENT": {
                String id = f[0].trim();
                String cid = f.length > 1 ? f[1].trim() : "";
                if (ig.uncomment(id, me, cid)) {
                    reg.broadcast("IGCMTGONE|" + id + "|" + cid, null);
                    InstaGhost.Post post = ig.get(id);
                    if (post != null) {
                        reg.broadcast(ig.counts(post), null);
                    }
                }
                break;
            }
            case "IGCOMMENTS": {
                String id = f[0].trim();
                for (InstaGhost.Comment c : ig.comments(id)) {
                    h.enqueue(InstaGhost.describe(id, c), Outbox.Priority.HIGH, 5000);
                }
                h.send("IGCMTEND|" + id);
                break;
            }
            case "IGDEL": {
                String id = f[0].trim();
                if (ig.delete(id, me)) {
                    ServerLog.info(me + " ha eliminato un post di InstaGhost");
                    reg.broadcast("IGGONE|" + id, null);
                }
                break;
            }
            case "IGBIO":
                ig.setBio(me, InstaGhost.unesc(rest));
                h.send(ig.profile(me, me));
                break;
            case "IGFOLLOW": {
                String who = f[0].trim();
                ig.follow(me, who, f.length > 1 && f[1].trim().equals("1"));
                h.send(ig.profile(me, who));
                ClientHandler t = reg.find(who);
                if (t != null && f.length > 1 && f[1].trim().equals("1")) {
                    t.send("IGFOLLOWED|" + me);
                }
                break;
            }
            case "IGPROFILE":
                h.send(ig.profile(me, f[0].trim().isEmpty() ? me : f[0].trim()));
                break;
            case "IGSEARCH": {
                for (String u : ig.search(InstaGhost.unesc(rest))) {
                    h.send("IGUSER|" + u + "|" + (reg.find(u) != null ? 1 : 0));
                }
                h.send("IGUSEREND");
                break;
            }
            default:
                break;
        }
    }

    private static long num(String s) {
        try {
            return Long.parseLong(s.trim());
        } catch (RuntimeException e) {
            return 0;
        }
    }
}
