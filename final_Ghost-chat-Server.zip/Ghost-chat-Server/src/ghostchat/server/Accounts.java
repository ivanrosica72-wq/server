package ghostchat.server;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

/**
 * Final: account degli utenti (nome utente + password, email facoltativa).
 * <p>
 * Le password non vengono mai salvate: si salva solo l'hash PBKDF2-SHA256 con
 * sale casuale. Per l'accesso automatico il client riceve un "gettone" casuale
 * (di cui il server tiene solo l'hash SHA-256). L'email, una volta verificata con
 * un codice, permette l'accesso rapido: si riceve un codice di 6 cifre via posta.
 * <p>
 * Il file {@code accounts.db} sta nella cartella dei dati. I messaggi continuano a
 * NON essere salvati: l'account serve solo a proteggere il nome utente.
 */
public final class Accounts {

    private static final Accounts INSTANCE = new Accounts();
    private static final SecureRandom RANDOM = new SecureRandom();
    private static final int ITERATIONS = 120_000;
    private static final int MAX_TOKENS = 8;
    private static final long CODE_TTL_MS = 10 * 60_000L;
    public static final int MIN_PASSWORD = 6;

    /** Un account. */
    static final class Account {

        String user;
        String salt;
        String hash;
        int iterations;
        String email = "";
        boolean emailVerified;
        long created;
        final List<String> tokens = new ArrayList<>();
    }

    /** Codice inviato per email (accesso o verifica). */
    private static final class Code {

        final String user;
        final String email;
        final String code;
        final boolean verify;
        final long expires;
        int attempts;

        Code(String user, String email, String code, boolean verify) {
            this.user = user;
            this.email = email;
            this.code = code;
            this.verify = verify;
            this.expires = System.currentTimeMillis() + CODE_TTL_MS;
        }
    }

    private final Map<String, Account> accounts = new LinkedHashMap<>();
    private final Map<String, Code> loginCodes = new HashMap<>();
    private final Map<String, Code> verifyCodes = new HashMap<>();
    private final Map<String, long[]> failures = new HashMap<>();
    private File file;

    private Accounts() {
    }

    public static Accounts getInstance() {
        return INSTANCE;
    }

    // ================================================================ persistenza

    synchronized void load() {
        file = new File(ServerConfig.dataDir(), "accounts.db");
        accounts.clear();
        if (!file.isFile()) {
            return;
        }
        try (BufferedReader r = new BufferedReader(new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8))) {
            String line;
            while ((line = r.readLine()) != null) {
                String[] f = line.split("\\|", -1);
                if (f.length < 8 || line.startsWith("#")) {
                    continue;
                }
                Account a = new Account();
                a.user = f[0];
                a.salt = f[1];
                a.hash = f[2];
                a.iterations = parseInt(f[3], ITERATIONS);
                a.email = f[4];
                a.emailVerified = "1".equals(f[5]);
                a.created = parseLong(f[6]);
                for (String t : f[7].split(",")) {
                    if (!t.isEmpty()) {
                        a.tokens.add(t);
                    }
                }
                accounts.put(key(a.user), a);
            }
            ServerLog.info("Account caricati: " + accounts.size());
        } catch (Throwable t) {
            ServerLog.error("Lettura degli account non riuscita", t);
        }
    }

    private synchronized void save() {
        if (file == null) {
            return;
        }
        File tmp = new File(file.getParentFile(), file.getName() + ".tmp");
        try (Writer w = new OutputStreamWriter(new FileOutputStream(tmp), StandardCharsets.UTF_8)) {
            w.write("# Ghost-chat accounts: utente|sale|hash|iterazioni|email|verificata|creato|gettoni\n");
            for (Account a : accounts.values()) {
                w.write(a.user + "|" + a.salt + "|" + a.hash + "|" + a.iterations + "|" + a.email + "|"
                        + (a.emailVerified ? "1" : "0") + "|" + a.created + "|" + String.join(",", a.tokens) + "\n");
            }
        } catch (Throwable t) {
            ServerLog.error("Salvataggio degli account non riuscito", t);
            return;
        }
        if (file.exists() && !file.delete()) {
            ServerLog.warn("Impossibile sostituire " + file);
        }
        if (!tmp.renameTo(file)) {
            ServerLog.warn("Impossibile rinominare " + tmp);
        }
    }

    // ================================================================ operazioni

    /** @return null se ok, altrimenti il motivo */
    public synchronized String register(String user, String password, String email) {
        if (!ServerConfig.bool("accounts.allowRegistration")) {
            return "Le registrazioni su questo server sono chiuse";
        }
        String err = Protocol.validateNickname(user);
        if (err != null) {
            return err.replace("nickname", "nome utente");
        }
        user = user.trim();
        if (accounts.containsKey(key(user))) {
            return "Il nome utente \"" + user + "\" è già registrato";
        }
        if (password == null || password.length() < MIN_PASSWORD) {
            return "La password deve avere almeno " + MIN_PASSWORD + " caratteri";
        }
        if (password.length() > 128) {
            return "Password troppo lunga";
        }
        Account a = new Account();
        a.user = user;
        a.iterations = ITERATIONS;
        byte[] salt = new byte[16];
        RANDOM.nextBytes(salt);
        a.salt = Base64.getEncoder().encodeToString(salt);
        a.hash = pbkdf2(password, salt, a.iterations);
        a.created = System.currentTimeMillis();
        email = email == null ? "" : email.trim().toLowerCase(Locale.ROOT);
        if (!email.isEmpty()) {
            if (!validEmail(email)) {
                return "Indirizzo email non valido";
            }
            if (findByEmail(email) != null) {
                return "Questa email è già associata a un altro account";
            }
            a.email = email;
        }
        accounts.put(key(user), a);
        save();
        ServerLog.info("Nuovo account registrato: " + user);
        return null;
    }

    public synchronized boolean exists(String user) {
        return user != null && accounts.containsKey(key(user.trim()));
    }

    /** Nome come registrato (maiuscole originali) oppure null. */
    public synchronized String canonical(String user) {
        Account a = user == null ? null : accounts.get(key(user.trim()));
        return a == null ? null : a.user;
    }

    /** @return null se le credenziali sono giuste, altrimenti il motivo */
    public synchronized String checkPassword(String user, String password, String ip) {
        String wait = throttled(ip, user);
        if (wait != null) {
            return wait;
        }
        Account a = user == null ? null : accounts.get(key(user.trim()));
        if (a == null || password == null) {
            fail(ip, user);
            return "Nome utente o password errati";
        }
        String h = pbkdf2(password, Base64.getDecoder().decode(a.salt), a.iterations);
        if (!MessageDigest.isEqual(h.getBytes(StandardCharsets.US_ASCII), a.hash.getBytes(StandardCharsets.US_ASCII))) {
            fail(ip, user);
            return "Nome utente o password errati";
        }
        failures.remove(ip + "/" + key(user));
        return null;
    }

    public synchronized String changePassword(String user, String oldPw, String newPw, String ip) {
        String err = checkPassword(user, oldPw, ip);
        if (err != null) {
            return "La password attuale non è corretta";
        }
        if (newPw == null || newPw.length() < MIN_PASSWORD) {
            return "La nuova password deve avere almeno " + MIN_PASSWORD + " caratteri";
        }
        Account a = accounts.get(key(user));
        byte[] salt = new byte[16];
        RANDOM.nextBytes(salt);
        a.salt = Base64.getEncoder().encodeToString(salt);
        a.iterations = ITERATIONS;
        a.hash = pbkdf2(newPw, salt, a.iterations);
        a.tokens.clear(); // si esce da tutti gli altri dispositivi
        save();
        return null;
    }

    /** Nuovo gettone per l'accesso automatico (restituito in chiaro una sola volta). */
    public synchronized String newToken(String user) {
        Account a = accounts.get(key(user));
        if (a == null) {
            return "";
        }
        byte[] b = new byte[24];
        RANDOM.nextBytes(b);
        String token = Base64.getUrlEncoder().withoutPadding().encodeToString(b);
        a.tokens.add(sha(token));
        while (a.tokens.size() > MAX_TOKENS) {
            a.tokens.remove(0);
        }
        save();
        return token;
    }

    public synchronized boolean checkToken(String user, String token) {
        Account a = user == null ? null : accounts.get(key(user.trim()));
        return a != null && token != null && !token.isEmpty() && a.tokens.contains(sha(token));
    }

    public synchronized void revokeToken(String user, String token) {
        Account a = user == null ? null : accounts.get(key(user.trim()));
        if (a != null && token != null && a.tokens.remove(sha(token))) {
            save();
        }
    }

    public synchronized String email(String user) {
        Account a = accounts.get(key(user));
        return a == null ? "" : a.email;
    }

    public synchronized boolean emailVerified(String user) {
        Account a = accounts.get(key(user));
        return a != null && a.emailVerified && !a.email.isEmpty();
    }

    /**
     * Prepara un codice per l'accesso rapido via email.
     *
     * @return {codice, email, utente} oppure {null, motivo}
     */
    public synchronized String[] loginCode(String email, String ip) {
        String wait = throttled(ip, email);
        if (wait != null) {
            return new String[]{null, wait};
        }
        email = email == null ? "" : email.trim().toLowerCase(Locale.ROOT);
        Account a = findByEmail(email);
        if (a == null || !a.emailVerified) {
            fail(ip, email);
            return new String[]{null, "Nessun account ha questa email verificata"};
        }
        String code = sixDigits();
        loginCodes.put(email, new Code(a.user, email, code, false));
        return new String[]{code, email, a.user};
    }

    /** @return nome utente se il codice e' giusto, altrimenti "!motivo" */
    public synchronized String useLoginCode(String email, String code, String ip) {
        email = email == null ? "" : email.trim().toLowerCase(Locale.ROOT);
        Code c = loginCodes.get(email);
        if (c == null || c.expires < System.currentTimeMillis()) {
            loginCodes.remove(email);
            return "!Codice scaduto: chiedine uno nuovo";
        }
        if (++c.attempts > 5) {
            loginCodes.remove(email);
            return "!Troppi tentativi: chiedi un nuovo codice";
        }
        if (!c.code.equals(code == null ? "" : code.trim())) {
            fail(ip, email);
            return "!Codice non corretto";
        }
        loginCodes.remove(email);
        return c.user;
    }

    /** Associa (o cambia) l'email e prepara il codice di verifica. @return {codice} o {null, motivo} */
    public synchronized String[] startEmailChange(String user, String email) {
        email = email == null ? "" : email.trim().toLowerCase(Locale.ROOT);
        if (!validEmail(email)) {
            return new String[]{null, "Indirizzo email non valido"};
        }
        Account other = findByEmail(email);
        if (other != null && !other.user.equalsIgnoreCase(user)) {
            return new String[]{null, "Questa email è già associata a un altro account"};
        }
        String code = sixDigits();
        verifyCodes.put(key(user), new Code(user, email, code, true));
        return new String[]{code};
    }

    /** @return null se verificata, altrimenti il motivo */
    public synchronized String verifyEmail(String user, String code) {
        Code c = verifyCodes.get(key(user));
        if (c == null || c.expires < System.currentTimeMillis()) {
            verifyCodes.remove(key(user));
            return "Codice scaduto: richiedi la verifica di nuovo";
        }
        if (++c.attempts > 5) {
            verifyCodes.remove(key(user));
            return "Troppi tentativi";
        }
        if (!c.code.equals(code == null ? "" : code.trim())) {
            return "Codice non corretto";
        }
        verifyCodes.remove(key(user));
        Account a = accounts.get(key(user));
        if (a == null) {
            return "Account inesistente";
        }
        a.email = c.email;
        a.emailVerified = true;
        save();
        return null;
    }

    public synchronized void removeEmail(String user) {
        Account a = accounts.get(key(user));
        if (a != null) {
            a.email = "";
            a.emailVerified = false;
            save();
        }
    }

    public synchronized boolean delete(String user) {
        if (accounts.remove(key(user)) != null) {
            save();
            return true;
        }
        return false;
    }

    public synchronized int size() {
        return accounts.size();
    }

    public synchronized List<String> users() {
        List<String> out = new ArrayList<>();
        for (Account a : accounts.values()) {
            out.add(a.user);
        }
        return out;
    }

    // ================================================================ utilita'

    private Account findByEmail(String email) {
        for (Account a : accounts.values()) {
            if (!a.email.isEmpty() && a.email.equalsIgnoreCase(email)) {
                return a;
            }
        }
        return null;
    }

    static boolean validEmail(String e) {
        return e != null && e.length() <= 120 && e.matches("[^@\\s|]+@[^@\\s|]+\\.[A-Za-z]{2,}");
    }

    private static String key(String user) {
        return user.trim().toLowerCase(Locale.ROOT);
    }

    private static String sixDigits() {
        return String.format("%06d", RANDOM.nextInt(1_000_000));
    }

    /** Freno contro i tentativi a raffica: dopo 5 errori bisogna aspettare. */
    private String throttled(String ip, String user) {
        long now = System.currentTimeMillis();
        for (Iterator<Map.Entry<String, long[]>> it = failures.entrySet().iterator(); it.hasNext();) {
            if (now - it.next().getValue()[1] > 15 * 60_000L) {
                it.remove();
            }
        }
        long[] f = failures.get(ip + "/" + (user == null ? "" : key(user)));
        if (f != null && f[0] >= 5) {
            long wait = Math.min(15 * 60_000L, (f[0] - 4) * 30_000L) - (now - f[1]);
            if (wait > 0) {
                return "Troppi tentativi sbagliati: riprova tra " + Math.max(1, wait / 1000) + " secondi";
            }
        }
        return null;
    }

    private void fail(String ip, String user) {
        String k = ip + "/" + (user == null ? "" : key(user));
        long[] f = failures.computeIfAbsent(k, x -> new long[2]);
        f[0]++;
        f[1] = System.currentTimeMillis();
    }

    private static String pbkdf2(String password, byte[] salt, int iterations) {
        try {
            PBEKeySpec spec = new PBEKeySpec(password.toCharArray(), salt, iterations, 256);
            SecretKeyFactory f = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
            return Base64.getEncoder().encodeToString(f.generateSecret(spec).getEncoded());
        } catch (Exception e) {
            throw new IllegalStateException("PBKDF2 non disponibile", e);
        }
    }

    static String sha(String s) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            return Base64.getEncoder().withoutPadding().encodeToString(md.digest(s.getBytes(StandardCharsets.UTF_8)));
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
    }

    private static int parseInt(String s, int def) {
        try {
            return Integer.parseInt(s.trim());
        } catch (RuntimeException e) {
            return def;
        }
    }

    private static long parseLong(String s) {
        try {
            return Long.parseLong(s.trim());
        } catch (RuntimeException e) {
            return 0;
        }
    }
}
