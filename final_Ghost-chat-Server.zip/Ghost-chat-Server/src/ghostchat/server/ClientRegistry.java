package ghostchat.server;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Elenco dei client connessi e registrati (nickname + IP).
 * <p>
 * RT-05: l'elenco e' condiviso da tutti i thread ClientHandler, quindi ogni
 * accesso passa da metodi synchronized. Le operazioni di rete (invio della
 * lista) avvengono FUORI dal lock dell'elenco, cosi' un client lento non
 * blocca le registrazioni degli altri.
 * <p>
 * RS-07: qui dentro ci sono solo gli utenti online, mai i messaggi.
 */
public final class ClientRegistry {

    private static final ClientRegistry INSTANCE = new ClientRegistry();

    /** chiave = nickname in minuscolo (i nickname sono unici senza distinzione maiuscole/minuscole). */
    private final Map<String, ClientHandler> clients = new LinkedHashMap<>();

    /** Serializza gli invii della lista: tutti i client ricevono le liste nello stesso ordine. */
    private final Object broadcastLock = new Object();

    private ClientRegistry() {
    }

    public static ClientRegistry getInstance() {
        return INSTANCE;
    }

    private static String key(String nickname) {
        return nickname.trim().toLowerCase(Locale.ROOT);
    }

    /**
     * Prova a registrare un client.
     *
     * @return true se il nickname era libero
     */
    public synchronized boolean register(String nickname, ClientHandler handler) {
        String k = key(nickname);
        if (clients.containsKey(k)) {
            return false;
        }
        clients.put(k, handler);
        return true;
    }

    /**
     * Final: registra l'account; se era gia' collegato da un altro dispositivo la
     * vecchia connessione viene chiusa.
     *
     * @return la connessione sostituita (gia' chiusa) oppure null
     */
    public ClientHandler registerReplacing(String nickname, ClientHandler handler) {
        ClientHandler old;
        synchronized (this) {
            String k = key(nickname);
            old = clients.get(k);
            clients.put(k, handler);
        }
        if (old != null && old != handler) {
            old.send(Protocol.BYE + Protocol.SEP + "Hai effettuato l'accesso da un altro dispositivo");
            old.closeLater();
        }
        return old;
    }

    /**
     * Rimuove il client dall'elenco (solo se e' davvero lui ad occupare quel nickname).
     *
     * @return true se e' stato rimosso
     */
    public synchronized boolean remove(ClientHandler handler) {
        String nick = handler.getNickname();
        if (nick == null) {
            return false;
        }
        String k = key(nick);
        if (clients.get(k) == handler) {
            clients.remove(k);
            return true;
        }
        return false;
    }

    /** @return il client con quel nickname, oppure null se non e' online. */
    public synchronized ClientHandler find(String nickname) {
        if (nickname == null || nickname.trim().isEmpty()) {
            return null;
        }
        return clients.get(key(nickname));
    }

    public synchronized List<ClientHandler> snapshot() {
        return new ArrayList<>(clients.values());
    }

    public synchronized int size() {
        return clients.size();
    }

    /**
     * RS-04 (final): ogni client riceve l'elenco dei SUOI contatti online (piu' se stesso).
     * Chi non e' tuo contatto non compare: gli utenti si trovano cercando il nome utente.
     */
    public void broadcastUserList() {
        synchronized (broadcastLock) {
            List<ClientHandler> list = snapshot();
            Contacts book = Contacts.getInstance();
            for (ClientHandler me : list) {
                StringBuilder sb = new StringBuilder(Protocol.LIST).append(Protocol.SEP);
                boolean first = true;
                for (ClientHandler h : list) {
                    if (h != me && !book.areContacts(me.getNickname(), h.getNickname())) {
                        continue;
                    }
                    if (!first) {
                        sb.append(';');
                    }
                    // v4: nick@ip@nascosto (chi nasconde lo stato non mostra neanche l'IP)
                    sb.append(h.getNickname()).append('@').append(h.isHidden() ? "" : h.getIp())
                            .append('@').append(h.isHidden() ? '1' : '0');
                    first = false;
                }
                try {
                    me.send(sb.toString());
                } catch (Throwable t) {
                    ServerLog.error("Invio elenco a " + me.getNickname() + " non riuscito", t);
                }
            }
        }
    }

    /** Invia una riga a tutti i client registrati tranne {@code except}. */
    public void broadcast(String line, ClientHandler except) {
        for (ClientHandler h : snapshot()) {
            if (h != except) {
                try {
                    h.send(line);
                } catch (Throwable t) {
                    ServerLog.error("Invio a " + h.getNickname() + " non riuscito", t);
                }
            }
        }
    }

    /** Invia una riga ai nickname indicati che sono online (tranne {@code except}). */
    public void sendTo(Iterable<String> nicks, String line, ClientHandler except) {
        for (String n : nicks) {
            ClientHandler h = find(n);
            if (h != null && h != except) {
                h.send(line);
            }
        }
    }

    /** Chiude tutte le connessioni (usato allo spegnimento del server). */
    public void closeAll(String reason) {
        List<ClientHandler> all = snapshot();
        for (ClientHandler h : all) {
            try {
                h.send(Protocol.BYE + Protocol.SEP + Protocol.clean(reason));
            } catch (Throwable ignored) {
                // si chiude comunque
            }
        }
        try {
            Thread.sleep(300); // tempo per far partire l'avviso
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        for (ClientHandler h : all) {
            h.close();
        }
    }
}
