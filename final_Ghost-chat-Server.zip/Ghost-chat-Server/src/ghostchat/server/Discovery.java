package ghostchat.server;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;

/**
 * v4: ritrovamento automatico del server nella rete locale.
 * <p>
 * Il server ascolta sulla porta UDP {@value #PORT}: quando un client manda in
 * broadcast la domanda {@code GHOSTCHAT?DISCOVER}, risponde con
 * {@code GHOSTCHAT!SERVER|v4|<portaTCP>|<nome del computer>|<utenti online>}.
 * Cosi' il client trova da solo l'indirizzo IP e la porta, senza doverli scrivere.
 * Se la porta UDP non si puo' aprire il server funziona lo stesso (si scrive l'IP a mano).
 */
final class Discovery implements Runnable {

    static final int PORT = 5099;
    static final String QUESTION = "GHOSTCHAT?DISCOVER";
    static final String ANSWER = "GHOSTCHAT!SERVER";

    private final int tcpPort;
    private final String name;

    Discovery(int tcpPort) {
        this.tcpPort = tcpPort;
        String n;
        try {
            n = InetAddress.getLocalHost().getHostName();
        } catch (Throwable t) {
            n = System.getenv("COMPUTERNAME") != null ? System.getenv("COMPUTERNAME") : "Ghost-chat";
        }
        this.name = n.replace("|", " ");
    }

    @Override
    public void run() {
        boolean warned = false;
        while (true) {
            try (DatagramSocket socket = new DatagramSocket(null)) {
                socket.setReuseAddress(true);
                socket.setBroadcast(true);
                socket.bind(new InetSocketAddress(PORT));
                ServerLog.info("Ritrovamento automatico attivo (UDP " + PORT + "): i client trovano il server da soli.");
                warned = false;
                byte[] buf = new byte[512];
                while (true) {
                    DatagramPacket in = new DatagramPacket(buf, buf.length);
                    socket.receive(in);
                    String q = new String(in.getData(), in.getOffset(), in.getLength(), StandardCharsets.UTF_8).trim();
                    if (!q.startsWith(QUESTION)) {
                        continue; // pacchetti estranei: ignorati
                    }
                    String a = ANSWER + "|v4|" + tcpPort + "|" + name + "|" + ClientRegistry.getInstance().size();
                    byte[] out = a.getBytes(StandardCharsets.UTF_8);
                    try {
                        socket.send(new DatagramPacket(out, out.length, in.getAddress(), in.getPort()));
                    } catch (Exception e) {
                        // risposta non inviata: il client riprovera'
                    }
                }
            } catch (Throwable t) {
                if (!warned) {
                    ServerLog.warn("Ritrovamento automatico non disponibile (" + t.getMessage()
                            + "): i client dovranno scrivere l'IP a mano. Nuovo tentativo tra 10 secondi.");
                    warned = true;
                }
                try {
                    Thread.sleep(10_000);
                } catch (InterruptedException e) {
                    return;
                }
            }
        }
    }
}
