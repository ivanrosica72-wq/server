package ghostchat.server;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Properties;

/**
 * Final: configurazione del server, letta da {@code ghostchat-server.properties}
 * (creato con i valori predefiniti al primo avvio, accanto al jar).
 * <p>
 * Qui si impostano le porte per l'accesso da Internet (TLS e WebSocket per le
 * app Android/iOS), la cartella dei dati (account e InstaGhost) e il server di
 * posta usato per i codici di accesso via email.
 */
public final class ServerConfig {

    private static final String FILE_NAME = "ghostchat-server.properties";
    private static final Properties P = new Properties();
    private static File file;

    private ServerConfig() {
    }

    static synchronized void load() {
        file = new File(FILE_NAME).getAbsoluteFile();
        defaults();
        if (file.isFile()) {
            try (InputStream in = new FileInputStream(file)) {
                P.load(new java.io.InputStreamReader(in, java.nio.charset.StandardCharsets.UTF_8));
            } catch (Throwable t) {
                ServerLog.warn("Configurazione non leggibile (" + t.getMessage() + "): uso i valori predefiniti");
            }
        } else {
            save();
            ServerLog.info("Creato il file di configurazione " + file.getPath());
        }
    }

    private static void defaults() {
        put("port", "11112");
        put("mux.enabled", "true");
        put("mux.tls", "true");
        put("mux.ws", "true");
        put("discovery.enabled", "false");
        put("tls.enabled", "false");
        put("tls.port", "5443");
        put("tls.keystore", "ghostchat-tls.p12");
        put("tls.password", "ghostchat");
        put("ws.enabled", "false");
        put("ws.port", "5080");
        put("wss.enabled", "false");
        put("wss.port", "5444");
        put("public.host", "78.154.103.51");
        put("data.dir", "ghostchat-data");
        put("accounts.allowRegistration", "true");
        put("smtp.host", "");
        put("smtp.port", "587");
        put("smtp.security", "starttls");
        put("smtp.user", "");
        put("smtp.password", "");
        put("smtp.from", "");
        put("instaghost.maxPhotoMB", "12");
        put("instaghost.maxVideoMB", "80");
    }

    private static void put(String k, String v) {
        if (!P.containsKey(k)) {
            P.setProperty(k, v);
        }
    }

    private static synchronized void save() {
        try (OutputStream out = new FileOutputStream(file)) {
            P.store(new java.io.OutputStreamWriter(out, java.nio.charset.StandardCharsets.UTF_8),
                    "Ghost-chat server (final). smtp.security = starttls | ssl | none."
                    + " public.host = nome o IP pubblico mostrato all'avvio.");
        } catch (Throwable t) {
            ServerLog.warn("Impossibile salvare " + FILE_NAME + ": " + t.getMessage());
        }
    }

    public static synchronized String str(String key) {
        return P.getProperty(key, "").trim();
    }

    public static synchronized int integer(String key, int def) {
        try {
            return Integer.parseInt(str(key));
        } catch (RuntimeException e) {
            return def;
        }
    }

    public static synchronized boolean bool(String key) {
        return "true".equalsIgnoreCase(str(key)) || "1".equals(str(key)) || "si".equalsIgnoreCase(str(key));
    }

    /** Cartella dei dati persistenti (account, InstaGhost). */
    public static File dataDir() {
        File d = new File(str("data.dir").isEmpty() ? "ghostchat-data" : str("data.dir")).getAbsoluteFile();
        if (!d.isDirectory() && !d.mkdirs()) {
            ServerLog.warn("Impossibile creare la cartella dei dati " + d);
        }
        return d;
    }

    /** Percorso relativo alla cartella del server. */
    public static File file(String key) {
        String v = str(key);
        File f = new File(v);
        return f.isAbsolute() ? f : new File(file.getParentFile(), v);
    }
}
