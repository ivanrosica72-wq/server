package ghostchat.server;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.security.KeyStore;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.Locale;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLServerSocket;

/**
 * Final: accesso da Internet.
 * <p>
 * <b>Porta unica</b> (per l'hosting online, es. Wispbyte, dove si ha una sola
 * porta): sulla porta principale il server riconosce da solo dai primi byte se
 * arriva il protocollo Ghost-chat normale, una connessione cifrata TLS
 * (anche WebSocket dentro TLS) oppure HTTP/WebSocket (app Android/iOS e browser).
 * Le porte separate qui sotto restano disponibili ma sono spente di default.
 * <ul>
 * <li><b>TLS</b> (porta 5443): lo stesso protocollo a righe del server, cifrato.
 * Il certificato viene creato da solo al primo avvio (con {@code keytool});
 * si puo' sostituire con uno vero (es. Let's Encrypt convertito in PKCS12).</li>
 * <li><b>WebSocket</b> (ws 5080, wss 5444): usato dalle app Android e iOS e dal
 * browser. Ogni messaggio WebSocket di testo e' una riga del protocollo; il
 * gateway la passa al server interno, quindi le regole sono identiche.</li>
 * </ul>
 * Il gateway WebSocket serve anche i file statici della cartella {@code web/}
 * (la versione web dell'app), se presente accanto al server.
 */
final class NetGateways {

    private static SSLContext ssl;

    private NetGateways() {
    }

    private static volatile int mainPortForBridge;

    static boolean tlsReady() {
        return ssl != null;
    }

    static void startAll(int mainPort) {
        mainPortForBridge = mainPort;
        if (ServerConfig.bool("tls.enabled") || ServerConfig.bool("wss.enabled") || ServerConfig.bool("mux.tls")) {
            try {
                ssl = sslContext();
            } catch (Throwable t) {
                ServerLog.warn("TLS non disponibile (" + t.getMessage() + "): restano le porte non cifrate");
            }
        }
        if (ssl != null && ServerConfig.bool("tls.enabled")) {
            int p = ServerConfig.integer("tls.port", 5443);
            daemon("tls-" + p, () -> acceptLoop(p, true, s -> GhostChatServer.startHandlerPublic(s)));
        }
        if (ServerConfig.bool("ws.enabled")) {
            int p = ServerConfig.integer("ws.port", 5080);
            daemon("ws-" + p, () -> acceptLoop(p, false, s -> daemon("ws-client", () -> websocket(s, mainPort))));
        }
        if (ssl != null && ServerConfig.bool("wss.enabled")) {
            int p = ServerConfig.integer("wss.port", 5444);
            daemon("wss-" + p, () -> acceptLoop(p, true, s -> daemon("wss-client", () -> websocket(s, mainPort))));
        }
    }

    // ================================================================ porta unica

    /** Smista una connessione arrivata sulla porta principale (in un thread suo). */
    static void dispatch(Socket raw) {
        daemon("mux", () -> {
            try {
                route(raw, false);
            } catch (Throwable t) {
                close(raw);
            }
        });
    }

    private static void route(Socket s, boolean insideTls) throws IOException {
        s.setSoTimeout(30_000);
        InputStream in = s.getInputStream();
        byte[] head = new byte[4];
        int n = in.read(head, 0, 1);
        if (n <= 0) {
            close(s);
            return;
        }
        if (!insideTls && (head[0] & 0xFF) == 0x16) {
            if (ssl == null || !ServerConfig.bool("mux.tls")) {
                close(s);
                return;
            }
            javax.net.ssl.SSLSocket t = (javax.net.ssl.SSLSocket) ssl.getSocketFactory()
                    .createSocket(s, new java.io.ByteArrayInputStream(head, 0, 1), true);
            t.setUseClientMode(false);
            t.startHandshake();
            route(t, true);
            return;
        }
        // abbastanza byte per riconoscere "GET ", "HEAD", "POST", "OPTI"
        while (n < 4) {
            int r = in.read(head, n, 4 - n);
            if (r <= 0) {
                break;
            }
            n += r;
        }
        String start = new String(head, 0, n, StandardCharsets.ISO_8859_1);
        Socket p = new PrefixSocket(s, head, n);
        boolean http = start.equals("GET ") || start.equals("HEAD") || start.equals("POST") || start.equals("OPTI");
        if (http) {
            if (!ServerConfig.bool("mux.ws")) {
                close(s);
                return;
            }
            websocket(p, mainPortForBridge);
        } else {
            GhostChatServer.startHandlerPublic(p);
        }
    }

    private interface SocketTask {

        void accept(Socket s);
    }

    private static void daemon(String name, Runnable r) {
        Thread t = new Thread(r, name);
        t.setDaemon(true);
        t.start();
    }

    private static void acceptLoop(int port, boolean tls, SocketTask task) {
        while (true) {
            try (ServerSocket ss = tls ? ssl.getServerSocketFactory().createServerSocket() : new ServerSocket()) {
                ss.setReuseAddress(true);
                ss.bind(new InetSocketAddress(port));
                if (ss instanceof SSLServerSocket) {
                    ((SSLServerSocket) ss).setNeedClientAuth(false);
                }
                ServerLog.info((tls ? "Porta cifrata (TLS)" : "Porta WebSocket") + " in ascolto: " + port);
                while (true) {
                    Socket s = ss.accept();
                    try {
                        task.accept(s);
                    } catch (Throwable t) {
                        close(s);
                    }
                }
            } catch (Throwable t) {
                ServerLog.warn("Porta " + port + " non disponibile (" + t.getMessage() + "): nuovo tentativo tra 10 s");
                try {
                    Thread.sleep(10_000);
                } catch (InterruptedException e) {
                    return;
                }
            }
        }
    }

    // ================================================================ certificato

    private static SSLContext sslContext() throws Exception {
        File ks = ServerConfig.file("tls.keystore");
        char[] pw = ServerConfig.str("tls.password").toCharArray();
        if (!ks.isFile()) {
            createSelfSigned(ks, new String(pw));
        }
        KeyStore store = KeyStore.getInstance(ks.getName().toLowerCase(Locale.ROOT).endsWith(".jks") ? "JKS" : "PKCS12");
        try (InputStream in = new FileInputStream(ks)) {
            store.load(in, pw);
        }
        KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
        kmf.init(store, pw);
        SSLContext ctx = SSLContext.getInstance("TLS");
        ctx.init(kmf.getKeyManagers(), null, null);
        try {
            java.security.cert.Certificate c = store.getCertificate(store.aliases().nextElement());
            ServerLog.info("Impronta del certificato TLS (SHA-256): " + fingerprint(c.getEncoded()));
        } catch (Throwable ignored) {
            // solo informativo
        }
        return ctx;
    }

    /** Crea un certificato autofirmato con il keytool del JDK. */
    private static void createSelfSigned(File ks, String pw) throws Exception {
        String home = System.getProperty("java.home");
        File keytool = new File(home, "bin" + File.separator + (isWindows() ? "keytool.exe" : "keytool"));
        if (!keytool.isFile()) {
            keytool = new File(new File(home).getParentFile(), "bin" + File.separator + (isWindows() ? "keytool.exe" : "keytool"));
        }
        String host = ServerConfig.str("public.host").isEmpty() ? "ghostchat" : ServerConfig.str("public.host");
        ProcessBuilder pb = new ProcessBuilder(keytool.getPath(), "-genkeypair", "-alias", "ghostchat", "-keyalg", "RSA",
                "-keysize", "2048", "-validity", "3650", "-storetype", "PKCS12", "-keystore", ks.getPath(),
                "-storepass", pw, "-keypass", pw, "-dname", "CN=" + host + ", O=Ghost-chat",
                "-ext", "SAN=dns:localhost,dns:" + host.replaceAll("[^A-Za-z0-9.-]", "") + ",ip:127.0.0.1");
        pb.redirectErrorStream(true);
        Process p = pb.start();
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        try (InputStream in = p.getInputStream()) {
            byte[] b = new byte[4096];
            int n;
            while ((n = in.read(b)) > 0) {
                out.write(b, 0, n);
            }
        }
        if (p.waitFor() != 0 || !ks.isFile()) {
            throw new IOException("keytool non riuscito: " + out.toString("UTF-8").trim());
        }
        ServerLog.info("Creato il certificato TLS autofirmato " + ks.getName());
    }

    static String fingerprint(byte[] der) throws Exception {
        byte[] d = MessageDigest.getInstance("SHA-256").digest(der);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < d.length; i++) {
            sb.append(i > 0 ? ":" : "").append(String.format("%02X", d[i]));
        }
        return sb.toString();
    }

    private static boolean isWindows() {
        return System.getProperty("os.name", "").toLowerCase(Locale.ROOT).contains("win");
    }

    // ================================================================ WebSocket

    private static void websocket(Socket s, int mainPort) {
        Socket inner = null;
        try {
            s.setSoTimeout(15000);
            InputStream rawIn = s.getInputStream();
            OutputStream rawOut = s.getOutputStream();
            String head = readHead(rawIn);
            if (head == null) {
                close(s);
                return;
            }
            String[] lines = head.split("\r\n");
            String[] req = lines[0].split(" ");
            String key = null;
            boolean upgrade = false;
            for (String l : lines) {
                int c = l.indexOf(':');
                if (c > 0) {
                    String name = l.substring(0, c).trim().toLowerCase(Locale.ROOT);
                    String val = l.substring(c + 1).trim();
                    if (name.equals("sec-websocket-key")) {
                        key = val;
                    } else if (name.equals("upgrade") && val.equalsIgnoreCase("websocket")) {
                        upgrade = true;
                    }
                }
            }
            if (!upgrade || key == null) {
                serveStatic(rawOut, req.length > 1 ? req[1] : "/");
                close(s);
                return;
            }
            String accept = Base64.getEncoder().encodeToString(MessageDigest.getInstance("SHA-1")
                    .digest((key + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11").getBytes(StandardCharsets.US_ASCII)));
            rawOut.write(("HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n"
                    + "Sec-WebSocket-Accept: " + accept + "\r\n\r\n").getBytes(StandardCharsets.US_ASCII));
            rawOut.flush();
            s.setSoTimeout(Protocol.READ_TIMEOUT_MS + 15_000);

            inner = new Socket(InetAddress.getLoopbackAddress(), mainPort);
            inner.setTcpNoDelay(true);
            final Socket in2 = inner;
            final Writer toServer = new OutputStreamWriter(inner.getOutputStream(), StandardCharsets.UTF_8);
            // il server interno vede l'indirizzo vero (per il freno ai tentativi di accesso)
            toServer.write("VIA|" + s.getInetAddress().getHostAddress() + "|" + ClientHandler.GATEWAY_SECRET + "\n");
            toServer.flush();
            final Object wsLock = new Object();
            // dal server interno al browser/app: una riga = un messaggio di testo
            Thread down = new Thread(() -> {
                try (BufferedReader r = new BufferedReader(new InputStreamReader(in2.getInputStream(), StandardCharsets.UTF_8))) {
                    String line;
                    while ((line = r.readLine()) != null) {
                        synchronized (wsLock) {
                            frame(rawOut, 1, line.getBytes(StandardCharsets.UTF_8));
                        }
                    }
                } catch (IOException ignored) {
                    // chiusura
                } finally {
                    close(s);
                }
            }, "ws-down");
            down.setDaemon(true);
            down.start();
            DataInputStream din = new DataInputStream(rawIn);
            ByteArrayOutputStream msg = new ByteArrayOutputStream();
            while (true) {
                int b0 = din.read();
                if (b0 < 0) {
                    break;
                }
                int b1 = din.readUnsignedByte();
                boolean fin = (b0 & 0x80) != 0;
                int op = b0 & 0x0F;
                long len = b1 & 0x7F;
                if (len == 126) {
                    len = din.readUnsignedShort();
                } else if (len == 127) {
                    len = din.readLong();
                }
                if (len > Protocol.MAX_LINE_LENGTH * 2L) {
                    break;
                }
                byte[] mask = new byte[4];
                if ((b1 & 0x80) != 0) {
                    din.readFully(mask);
                }
                byte[] data = new byte[(int) len];
                din.readFully(data);
                for (int i = 0; i < data.length; i++) {
                    data[i] ^= mask[i % 4];
                }
                if (op == 8) {
                    synchronized (wsLock) {
                        frame(rawOut, 8, new byte[0]);
                    }
                    break;
                } else if (op == 9) {
                    synchronized (wsLock) {
                        frame(rawOut, 10, data);
                    }
                    continue;
                } else if (op == 10) {
                    continue;
                }
                msg.write(data);
                if (msg.size() > Protocol.MAX_LINE_LENGTH * 2) {
                    break;
                }
                if (fin) {
                    String text = new String(msg.toByteArray(), StandardCharsets.UTF_8);
                    msg.reset();
                    for (String l : text.split("\n")) {
                        if (!l.isEmpty()) {
                            toServer.write(l.replace("\r", ""));
                            toServer.write('\n');
                        }
                    }
                    toServer.flush();
                }
            }
        } catch (Throwable ignored) {
            // connessione chiusa o richiesta non valida
        } finally {
            close(s);
            if (inner != null) {
                close(inner);
            }
        }
    }

    private static void frame(OutputStream out, int op, byte[] data) throws IOException {
        out.write(0x80 | op);
        if (data.length < 126) {
            out.write(data.length);
        } else if (data.length < 65536) {
            out.write(126);
            out.write(data.length >>> 8);
            out.write(data.length & 0xFF);
        } else {
            out.write(127);
            for (int i = 7; i >= 0; i--) {
                out.write((int) (((long) data.length >>> (8 * i)) & 0xFF));
            }
        }
        out.write(data);
        out.flush();
    }

    private static String readHead(InputStream in) throws IOException {
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        int state = 0;
        while (b.size() < 16384) {
            int c = in.read();
            if (c < 0) {
                return null;
            }
            b.write(c);
            state = (c == '\r' && (state == 0 || state == 2)) ? state + 1 : (c == '\n' && (state == 1 || state == 3)) ? state + 1 : 0;
            if (state == 4) {
                return new String(b.toByteArray(), StandardCharsets.ISO_8859_1);
            }
        }
        return null;
    }

    /** Pagina informativa o file della versione web (cartella web/). */
    private static void serveStatic(OutputStream out, String path) throws IOException {
        File web = new File("web").getAbsoluteFile();
        String p = path == null ? "/" : path;
        int q = p.indexOf('?');
        if (q >= 0) {
            p = p.substring(0, q);
        }
        if (p.equals("/") || p.isEmpty()) {
            p = "/index.html";
        }
        File f = new File(web, p.replace("..", "").replace('/', File.separatorChar));
        byte[] body;
        String type;
        int code = 200;
        byte[] packed = null;
        if (!(web.isDirectory() && f.isFile())) {
            // final: la versione web e' anche dentro il jar (comodo sull'hosting: basta caricare il jar)
            try (InputStream in = NetGateways.class.getResourceAsStream("/web" + p.replace("..", ""))) {
                if (in != null) {
                    ByteArrayOutputStream b = new ByteArrayOutputStream();
                    byte[] buf = new byte[16384];
                    int n;
                    while ((n = in.read(buf)) > 0) {
                        b.write(buf, 0, n);
                    }
                    packed = b.toByteArray();
                }
            }
        }
        if (web.isDirectory() && f.isFile() && f.getCanonicalPath().startsWith(web.getCanonicalPath())) {
            body = Files.readAllBytes(f.toPath());
            type = mime(f.getName());
        } else if (packed != null) {
            body = packed;
            type = mime(p);
        } else {
            body = ("<!doctype html><meta charset=utf-8><title>Ghost-chat</title><body style='font-family:sans-serif;"
                    + "background:#1b0f24;color:#eee;padding:40px'><h1>&#128123; Ghost-chat server</h1>"
                    + "<p>Questa porta accetta le connessioni WebSocket delle app Android e iOS.</p>"
                    + "<p>Utenti online: " + ClientRegistry.getInstance().size() + "</p></body>")
                    .getBytes(StandardCharsets.UTF_8);
            type = "text/html; charset=utf-8";
            code = p.equals("/index.html") ? 200 : 404;
        }
        out.write(("HTTP/1.1 " + code + (code == 200 ? " OK" : " Not Found") + "\r\nContent-Type: " + type
                + "\r\nContent-Length: " + body.length + "\r\nCache-Control: no-cache\r\nConnection: close\r\n\r\n")
                .getBytes(StandardCharsets.US_ASCII));
        out.write(body);
        out.flush();
    }

    private static String mime(String name) {
        String n = name.toLowerCase(Locale.ROOT);
        if (n.endsWith(".html")) {
            return "text/html; charset=utf-8";
        }
        if (n.endsWith(".js")) {
            return "application/javascript; charset=utf-8";
        }
        if (n.endsWith(".css")) {
            return "text/css; charset=utf-8";
        }
        if (n.endsWith(".json") || n.endsWith(".webmanifest")) {
            return "application/json";
        }
        if (n.endsWith(".png")) {
            return "image/png";
        }
        if (n.endsWith(".svg")) {
            return "image/svg+xml";
        }
        if (n.endsWith(".woff2")) {
            return "font/woff2";
        }
        return "application/octet-stream";
    }

    private static void close(Socket s) {
        try {
            s.close();
        } catch (Throwable ignored) {
            // niente
        }
    }
}
