package ghostchat.server;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * RT-03: gestisce la socket di UN singolo client.
 * <ul>
 * <li>implementa Runnable e viene eseguita in un Thread separato;</li>
 * <li>legge i messaggi in arrivo dal client e invia quelli a lui destinati;</li>
 * <li>alla disconnessione chiude la socket e rimuove il client dall'elenco.</li>
 * </ul>
 * I messaggi destinati a questo client passano da una coda con priorita'
 * ({@link Outbox}) svuotata da un thread di scrittura dedicato: cosi' chi invia
 * non resta mai bloccato da un destinatario lento, e un file grande non
 * rallenta testo e chiamate.
 * <p>
 * Qualsiasi errore riguarda solo questo client: il server e gli altri
 * client continuano a funzionare.
 */
public class ClientHandler implements Runnable {

    /** Numero massimo di connessioni contemporanee accettate. */
    public static final int MAX_CONNECTIONS = 500;
    /** Quanto si aspetta un destinatario lento prima di interrompere un trasferimento. */
    private static final long BULK_TIMEOUT_MS = 30_000;

    private static final AtomicInteger ACTIVE_CONNECTIONS = new AtomicInteger();

    private final Socket socket;
    private final String ip;
    private final Outbox outbox = new Outbox();
    private final AtomicBoolean closed = new AtomicBoolean(false);
    private final ClientRegistry registry = ClientRegistry.getInstance();

    private volatile BufferedWriter out;
    private volatile String nickname;
    private volatile boolean registered;
    /** v4: stato nascosto (gli altri non vedono online/offline ne' l'IP) */
    private volatile boolean hidden;
    /** v4: foto profilo (jpeg in base64, vuota = nessuna); solo in memoria */
    private volatile String avatar = "";
    private final Groups groups = Groups.getInstance();
    /** final: indirizzo reale di chi arriva dal gateway WebSocket */
    private volatile String realIp;
    private final InstaGhost insta = InstaGhost.getInstance();
    private final CardGames cards = CardGames.getInstance();
    private final Accounts accounts = Accounts.getInstance();
    /** segreto condiviso con il gateway WebSocket (connessioni dal PC stesso) */
    static final String GATEWAY_SECRET = Long.toHexString(new java.security.SecureRandom().nextLong());
    private final StatusStore statusStore = StatusStore.getInstance();

    public ClientHandler(Socket socket) {
        this.socket = socket;
        String address;
        try {
            address = socket.getInetAddress().getHostAddress();
        } catch (Throwable t) {
            address = "sconosciuto";
        }
        this.ip = address;
    }

    public String getNickname() {
        return nickname;
    }

    public String getIp() {
        return realIp != null ? realIp : ip;
    }

    public boolean isHidden() {
        return hidden;
    }

    public String getAvatar() {
        return avatar;
    }

    public static int getActiveConnections() {
        return ACTIVE_CONNECTIONS.get();
    }

    @Override
    public void run() {
        int active = ACTIVE_CONNECTIONS.incrementAndGet();
        try {
            ServerLog.info("Nuova connessione da " + ip + " (connessioni attive: " + active + ")");

            out = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream(), StandardCharsets.UTF_8), 65536);
            if (active > MAX_CONNECTIONS) {
                ServerLog.warn("Troppe connessioni: rifiuto " + ip);
                writeDirect(Protocol.ERR + Protocol.SEP + "Server pieno, riprova più tardi");
                return;
            }

            try {
                socket.setSoTimeout(Protocol.READ_TIMEOUT_MS);
                socket.setKeepAlive(true);
                socket.setTcpNoDelay(true);
            } catch (SocketException e) {
                ServerLog.warn("Impossibile impostare le opzioni della socket di " + ip + ": " + e.getMessage());
            }

            Thread writer = new Thread(this::writeLoop, "ClientHandler-writer-" + ip);
            writer.setDaemon(true);
            writer.start();

            LineReader in = new LineReader(
                    new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8),
                    Protocol.MAX_LINE_LENGTH);

            String line;
            while (!closed.get() && (line = in.readLine()) != null) {
                if (line == LineReader.OVERSIZED) {
                    send(Protocol.ERR + Protocol.SEP + "Messaggio troppo lungo: scartato");
                    continue;
                }
                try {
                    if (!handle(line)) {
                        break;
                    }
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    break;
                } catch (RuntimeException e) {
                    // un comando malformato non deve mai far cadere la connessione
                    ServerLog.error("Comando non gestito da " + describe() + ": " + abbreviate(line), e);
                    send(Protocol.ERR + Protocol.SEP + "Comando non valido");
                }
            }
        } catch (SocketTimeoutException e) {
            ServerLog.warn(describe() + " non risponde da " + (Protocol.READ_TIMEOUT_MS / 1000)
                    + " secondi: connessione chiusa");
        } catch (SocketException e) {
            if (!closed.get()) {
                ServerLog.info("Connessione con " + describe() + " interrotta (" + e.getMessage() + ")");
            }
        } catch (IOException e) {
            if (!closed.get()) {
                ServerLog.error("Errore di rete con " + describe(), e);
            }
        } catch (Throwable t) {
            ServerLog.error("Errore imprevisto nel thread di " + describe(), t);
        } finally {
            ACTIVE_CONNECTIONS.decrementAndGet();
            disconnect();
        }
    }

    /** Thread di scrittura: svuota la coda in uscita verso questo client. */
    private void writeLoop() {
        try {
            String line;
            while ((line = outbox.take()) != null) {
                BufferedWriter w = out;
                if (w == null) {
                    break;
                }
                w.write(line);
                w.write('\n');
                if (outbox.isEmpty()) {
                    w.flush();
                }
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        } catch (IOException e) {
            // socket rotta: chiudendola il thread di lettura fa la pulizia
        } catch (Throwable t) {
            ServerLog.error("Errore nell'invio verso " + describe(), t);
        } finally {
            close();
        }
    }

    /**
     * Gestisce una riga ricevuta dal client.
     *
     * @return false se la connessione va chiusa
     */
    private boolean handle(String line) throws InterruptedException {
        if (line.trim().isEmpty()) {
            return true;
        }
        String command;
        String rest;
        int sep = line.indexOf('|');
        if (sep < 0) {
            command = line.trim();
            rest = "";
        } else {
            command = line.substring(0, sep).trim();
            rest = line.substring(sep + 1);
        }

        switch (command.toUpperCase()) {
            case Protocol.PING:
                send(Protocol.PONG);
                return true;
            case Protocol.QUIT:
                ServerLog.info(describe() + " ha chiuso l'applicazione");
                return false;
            case Protocol.NICK:
                if (ServerConfig.bool("accounts.legacyNick")) {
                    handleNick(rest);
                } else {
                    send(Protocol.NICKERR + Protocol.SEP
                            + "Questo server richiede un account con password: aggiorna Ghost-chat alla versione final");
                }
                return true;
            case "VIA": {
                String[] v = rest.split("\\|", -1);
                if (!registered && v.length == 2 && v[1].equals(GATEWAY_SECRET) && socket.getInetAddress().isLoopbackAddress()) {
                    realIp = v[0].trim();
                }
                return true;
            }
            case "AUTH":
                handleAuth(rest);
                return true;
            case "MAILCODE":
                handleMailCode(rest);
                return true;
            case "ACCOUNT":
            case "GCONSENT":
            case "GINVCANCEL":
            case "CARD":
            case "IGPOST":
            case "IGPREV":
            case "IGCHUNK":
            case "IGUPEND":
            case "IGABORT":
            case "IGFEED":
            case "IGGET":
            case "IGVOTE":
            case "IGFAV":
            case "IGSHARE":
            case "IGCOMMENT":
            case "IGUNCOMMENT":
            case "IGCOMMENTS":
            case "IGDEL":
            case "IGBIO":
            case "IGFOLLOW":
            case "IGPROFILE":
            case "IGSEARCH":
            case "IGONE":
            case "USEARCH":
            case "CREQ":
            case "CANSWER":
            case "CCANCEL":
            case "CREMOVE":
                if (!registered) {
                    send(Protocol.ERR + Protocol.SEP + "Devi prima accedere");
                } else if (ContactFeatures.handles(command.toUpperCase())) {
                    ContactFeatures.handle(this, command.toUpperCase(), rest);
                } else if (!registered) {
                    send(Protocol.ERR + Protocol.SEP + "Devi prima accedere");
                } else {
                    FinalFeatures.handle(this, command.toUpperCase(), rest);
                }
                return true;
            case Protocol.MSG:
            case Protocol.EDIT:
            case Protocol.DEL:
            case Protocol.ACK:
            case Protocol.POLL:
            case Protocol.VOTE:
            case Protocol.VIDEO:
            case Protocol.VIDSTATE:
            case Protocol.FILE:
            case Protocol.CHUNK:
            case Protocol.FILEEND:
            case Protocol.FILECANCEL:
            case Protocol.FILEPOS:
            case Protocol.CALL:
            case Protocol.CALLACCEPT:
            case Protocol.CALLREJECT:
            case Protocol.CALLEND:
            case Protocol.AUDIO:
            case Protocol.REACT:
            case Protocol.PIN:
            case Protocol.LOC:
            case Protocol.LOCUPD:
            case Protocol.LOCSTOP:
            case Protocol.LINK:
            case Protocol.GAME:
            case Protocol.CALLREACT:
            case Protocol.TYPING:
            case Protocol.WB:
                relay(command.toUpperCase(), rest);
                return true;
            case Protocol.PRESENCE:
            case Protocol.AVATAR:
            case Protocol.GCREATE:
            case Protocol.GADD:
            case Protocol.GKICK:
            case Protocol.GLEAVE:
            case Protocol.GNAME:
            case Protocol.GPHOTO:
            case Protocol.SPOST:
            case Protocol.SCHUNK:
            case Protocol.SEND:
            case Protocol.SGET:
            case Protocol.SSEEN:
            case Protocol.SDEL:
            case Protocol.GADMIN:
            case Protocol.GDESC:
            case Protocol.GPERM:
            case Protocol.GINVITE:
            case Protocol.GJOIN:
                if (!registered) {
                    send(Protocol.ERR + Protocol.SEP + "Devi prima registrare un nickname");
                } else {
                    handleV4(command.toUpperCase(), rest);
                }
                return true;
            default:
                send(Protocol.ERR + Protocol.SEP + "Comando sconosciuto: " + Protocol.clean(abbreviate(command)));
                return true;
        }
    }

    /** RS-03: associa il nickname all'IP e aggiunge il client all'elenco degli utenti online. */
    private void handleNick(String requested) {
        if (registered) {
            send(Protocol.ERR + Protocol.SEP + "Sei già registrato come " + nickname);
            return;
        }
        String error = Protocol.validateNickname(requested);
        if (error != null) {
            send(Protocol.NICKERR + Protocol.SEP + error);
            return;
        }
        String nick = requested.trim();
        nickname = nick;
        if (!registry.register(nick, this)) {
            nickname = null;
            ServerLog.info("Nickname \"" + nick + "\" rifiutato per " + ip + ": gia' in uso");
            send(Protocol.NICKERR + Protocol.SEP + "Il nickname \"" + nick + "\" è già in uso");
            return;
        }
        registered = true;
        ServerLog.info("Utente registrato: " + nick + " @ " + ip + " (utenti online: " + registry.size() + ")");
        send(Protocol.WELCOME + Protocol.SEP + nick + Protocol.SEP + ip);
        // RS-04: tutti ricevono l'elenco aggiornato
        registry.broadcastUserList();
        sendInitialState();
    }

    /** Final: nei gruppi si possono invitare solo i propri contatti. */
    private java.util.List<String> onlyContacts(String[] names) {
        java.util.List<String> ok = new java.util.ArrayList<>();
        java.util.List<String> no = new java.util.ArrayList<>();
        for (String n : names) {
            String x = n.trim();
            if (x.isEmpty()) {
                continue;
            }
            if (Contacts.getInstance().areContacts(nickname, x)) {
                ok.add(x);
            } else {
                no.add(x);
            }
        }
        if (!no.isEmpty()) {
            send(Protocol.ERR + Protocol.SEP + "Non sono tuoi contatti, quindi non li puoi invitare: " + String.join(", ", no));
        }
        return ok;
    }

    /** v4: al nuovo arrivato si mandano foto profilo, gruppi, chiamate di gruppo e stati. */
    private void sendInitialState() {
        try {
            ContactFeatures.sendInitial(this);
            Contacts book = Contacts.getInstance();
            for (ClientHandler h : registry.snapshot()) {
                String a = h.getAvatar();
                if (h != this && a != null && !a.isEmpty() && book.areContacts(nickname, h.getNickname())) {
                    send(Protocol.AVATAR + Protocol.SEP + h.getNickname() + Protocol.SEP + a);
                }
            }
            for (Groups.Group g : groups.groupsOf(nickname)) {
                send(groups.describe(g.id));
                String photo = groups.photo(g.id);
                if (!photo.isEmpty()) {
                    send(Protocol.GPHOTO + Protocol.SEP + g.id + Protocol.SEP + photo);
                }
                if (groups.callId(g.id) != null) {
                    send(groups.describeCall(g.id));
                }
            }
            for (StatusStore.Status st : statusStore.all()) {
                if (!st.owner.equalsIgnoreCase(nickname) && !book.areContacts(nickname, st.owner)) {
                    continue; // final: gli stati si vedono solo tra contatti
                }
                send(st.describe());
            }
            for (String v : statusStore.viewsOf(nickname)) {
                send(v);
            }
            // final: inviti ai gruppi in attesa e partite a carte in corso
            for (String inv : groups.pendingFor(nickname)) {
                send(inv);
            }
            for (Groups.Group g : groups.groupsOf(nickname)) {
                for (CardGames.Game cg : cards.active(g.id)) {
                    send("CARDS" + Protocol.SEP + g.id + Protocol.SEP + cards.view(cg, nickname));
                }
            }
        } catch (Throwable t) {
            ServerLog.error("Invio dello stato iniziale a " + describe() + " non riuscito", t);
        }
    }

    // ================================================================ v4: presenza, foto, gruppi, stati

    private void handleV4(String cmd, String rest) throws InterruptedException {
        String[] f = rest.split("\\|", -1);
        switch (cmd) {
            case Protocol.PRESENCE: {
                boolean h = rest.trim().equals("1");
                if (h != hidden) {
                    hidden = h;
                    ServerLog.info(nickname + (h ? " ha nascosto il suo stato" : " mostra di nuovo il suo stato"));
                    registry.broadcastUserList();
                }
                break;
            }
            case Protocol.AVATAR: {
                String b64 = rest.trim();
                if (b64.length() > Protocol.MAX_AVATAR_CHARS || !b64.matches("[A-Za-z0-9+/=]*")) {
                    send(Protocol.ERR + Protocol.SEP + "Foto profilo troppo grande o non valida");
                    return;
                }
                avatar = b64;
                ServerLog.info(nickname + (b64.isEmpty() ? " ha tolto la foto profilo" : " ha cambiato la foto profilo"));
                registry.sendTo(ContactFeatures.audience(nickname), Protocol.AVATAR + Protocol.SEP + nickname + Protocol.SEP + b64, this);
                break;
            }
            case Protocol.GCREATE: {
                if (f.length < 3) {
                    send(Protocol.ERR + Protocol.SEP + "Gruppo non valido");
                    return;
                }
                String gid = f[0].trim();
                String err = groups.create(gid, f[1], nickname, onlyContacts(f[2].split(",")));
                if (err != null) {
                    sendError(err, "#" + gid, gid);
                    return;
                }
                ServerLog.info("Gruppo creato da " + nickname + " (inviti in attesa di consenso)");
                notifyGroup(gid, Protocol.GEVENT + Protocol.SEP + gid + Protocol.SEP + nickname + Protocol.SEP + "create"
                        + Protocol.SEP);
                FinalFeatures.sendInvites(gid);
                break;
            }
            case Protocol.GADD: {
                String gid = f[0].trim();
                if (!groups.isAdmin(gid, nickname)) {
                    sendError("Solo l'amministratore può aggiungere persone", "#" + gid, gid);
                    return;
                }
                // final: le persone vengono invitate e devono accettare
                java.util.List<String> invited = groups.invitePeople(gid,
                        onlyContacts(f.length > 1 ? f[1].split(",") : new String[0]), nickname);
                for (String a : invited) {
                    notifyGroup(gid, Protocol.GEVENT + Protocol.SEP + gid + Protocol.SEP + nickname + Protocol.SEP + "invite"
                            + Protocol.SEP + a);
                }
                FinalFeatures.sendInvites(gid);
                break;
            }
            case Protocol.GKICK: {
                String gid = f[0].trim();
                String who = f.length > 1 ? f[1].trim() : "";
                if (!groups.isAdmin(gid, nickname) || who.equalsIgnoreCase(nickname) || !groups.isMember(gid, who)) {
                    sendError("Solo l'amministratore può rimuovere un partecipante", "#" + gid, gid);
                    return;
                }
                String event = Protocol.GEVENT + Protocol.SEP + gid + Protocol.SEP + nickname + Protocol.SEP + "kick"
                        + Protocol.SEP + who;
                java.util.List<String> before = groups.members(gid);
                groups.remove(gid, who);
                registry.sendTo(before, event, null);
                ClientHandler gone = registry.find(who);
                if (gone != null) {
                    gone.send(Protocol.GROUPGONE + Protocol.SEP + gid);
                }
                notifyGroupState(gid);
                break;
            }
            case Protocol.GLEAVE: {
                String gid = f[0].trim();
                if (!groups.isMember(gid, nickname)) {
                    return;
                }
                java.util.List<String> before = groups.members(gid);
                boolean wasInCall = groups.isParticipant(gid, nickname);
                boolean exists = groups.remove(gid, nickname);
                send(Protocol.GROUPGONE + Protocol.SEP + gid);
                if (exists) {
                    registry.sendTo(before, Protocol.GEVENT + Protocol.SEP + gid + Protocol.SEP + nickname + Protocol.SEP
                            + "leave" + Protocol.SEP, this);
                    notifyGroupState(gid);
                    if (wasInCall) {
                        notifyCall(gid);
                    }
                }
                ServerLog.info(nickname + " è uscito da un gruppo");
                break;
            }
            case Protocol.GADMIN: {
                String gid = f[0].trim();
                String who = f.length > 1 ? f[1].trim() : "";
                boolean make = f.length > 2 && f[2].trim().equals("1");
                if (!groups.isAdmin(gid, nickname)) {
                    sendError("Solo un amministratore può cambiare gli amministratori", "#" + gid, gid);
                    return;
                }
                String err = groups.setAdmin(gid, who, make);
                if (err != null) {
                    sendError(err, "#" + gid, gid);
                    return;
                }
                notifyGroup(gid, Protocol.GEVENT + Protocol.SEP + gid + Protocol.SEP + nickname + Protocol.SEP
                        + (make ? "admin" : "unadmin") + Protocol.SEP + who);
                break;
            }
            case Protocol.GDESC: {
                String gid = f[0].trim();
                int p = rest.indexOf('|');
                String text = p < 0 ? "" : unescapeField(rest.substring(p + 1));
                if (!groups.isMember(gid, nickname) || (groups.onlyAdmins(gid) && !groups.isAdmin(gid, nickname))) {
                    sendError("Solo gli amministratori possono cambiare la descrizione", "#" + gid, gid);
                    return;
                }
                groups.setDescription(gid, text);
                notifyGroup(gid, Protocol.GEVENT + Protocol.SEP + gid + Protocol.SEP + nickname + Protocol.SEP + "desc"
                        + Protocol.SEP);
                break;
            }
            case Protocol.GPERM: {
                String gid = f[0].trim();
                boolean only = f.length > 1 && f[1].trim().equals("1");
                if (!groups.isAdmin(gid, nickname)) {
                    sendError("Solo un amministratore può cambiare i permessi", "#" + gid, gid);
                    return;
                }
                groups.setOnlyAdmins(gid, only);
                notifyGroup(gid, Protocol.GEVENT + Protocol.SEP + gid + Protocol.SEP + nickname + Protocol.SEP + "perm"
                        + Protocol.SEP + (only ? "1" : "0"));
                break;
            }
            case Protocol.GINVITE: {
                String gid = f[0].trim();
                String action = f.length > 1 ? f[1].trim().toLowerCase() : "get";
                if (!groups.isAdmin(gid, nickname)) {
                    sendError("Solo un amministratore può gestire il link d'invito", "#" + gid, gid);
                    return;
                }
                if (action.equals("revoke")) {
                    groups.revokeInvite(gid);
                    send(Protocol.GINVITE + Protocol.SEP + gid + Protocol.SEP);
                } else {
                    String code = groups.invite(gid, action.equals("new"));
                    send(Protocol.GINVITE + Protocol.SEP + gid + Protocol.SEP + (code == null ? "" : code));
                }
                break;
            }
            case Protocol.GJOIN: {
                String res = groups.join(rest, nickname);
                if (res.startsWith("!")) {
                    send(Protocol.ERR + Protocol.SEP + res.substring(1));
                    return;
                }
                ServerLog.info(nickname + " è entrato in un gruppo con un codice d'invito");
                notifyGroup(res, Protocol.GEVENT + Protocol.SEP + res + Protocol.SEP + nickname + Protocol.SEP + "join"
                        + Protocol.SEP);
                sendGroupExtras(res, java.util.Collections.singletonList(nickname));
                break;
            }
            case Protocol.GNAME: {
                String gid = f[0].trim();
                if (groups.onlyAdmins(gid) && !groups.isAdmin(gid, nickname)) {
                    sendError("Solo gli amministratori possono cambiare il nome", "#" + gid, gid);
                    return;
                }
                if (!groups.isMember(gid, nickname) || f.length < 2 || !groups.rename(gid, f[1])) {
                    sendError("Nome del gruppo non valido", "#" + gid, gid);
                    return;
                }
                notifyGroup(gid, Protocol.GEVENT + Protocol.SEP + gid + Protocol.SEP + nickname + Protocol.SEP + "name"
                        + Protocol.SEP);
                break;
            }
            case Protocol.GPHOTO: {
                String gid = f[0].trim();
                String b64 = f.length > 1 ? f[1].trim() : "";
                if (groups.onlyAdmins(gid) && !groups.isAdmin(gid, nickname)) {
                    sendError("Solo gli amministratori possono cambiare la foto", "#" + gid, gid);
                    return;
                }
                if (!groups.isMember(gid, nickname) || b64.length() > Groups.MAX_PHOTO_CHARS
                        || !b64.matches("[A-Za-z0-9+/=]*")) {
                    sendError("Foto del gruppo non valida", "#" + gid, gid);
                    return;
                }
                groups.setPhoto(gid, b64);
                registry.sendTo(groups.members(gid), Protocol.GPHOTO + Protocol.SEP + gid + Protocol.SEP + b64, null);
                registry.sendTo(groups.members(gid), Protocol.GEVENT + Protocol.SEP + gid + Protocol.SEP + nickname
                        + Protocol.SEP + "photo" + Protocol.SEP, null);
                break;
            }
            case Protocol.SPOST: {
                // SPOST|id|tipo|byte|meta|testo
                String[] p = rest.split("\\|", 5);
                if (p.length < 5 || p[1].trim().length() != 1) {
                    sendError("Stato non valido", "#status", p.length > 0 ? p[0] : "");
                    return;
                }
                String sid = p[0].trim();
                long size;
                try {
                    size = Long.parseLong(p[2].trim());
                } catch (NumberFormatException e) {
                    size = -1;
                }
                char kind = p[1].trim().charAt(0);
                String err = statusStore.begin(nickname, sid, kind, size, p[3], p[4]);
                if (err != null) {
                    sendError(err, "#status", sid);
                    return;
                }
                if (kind == 'T') {
                    publishStatus(statusStore.get(nickname, sid));
                }
                break;
            }
            case Protocol.SCHUNK: {
                String sid = f[0].trim();
                byte[] data;
                try {
                    data = java.util.Base64.getDecoder().decode(f.length > 1 ? f[1].trim() : "");
                } catch (IllegalArgumentException e) {
                    data = null;
                }
                if (data == null || !statusStore.chunk(nickname, sid, data)) {
                    statusStore.abort(nickname, sid);
                    sendError("Caricamento dello stato interrotto", "#status", sid);
                }
                break;
            }
            case Protocol.SEND: {
                String sid = f[0].trim();
                StatusStore.Status st = statusStore.finish(nickname, sid, f.length > 1 ? f[1] : "");
                if (st == null) {
                    sendError("Stato non pubblicato: dati danneggiati", "#status", sid);
                    return;
                }
                publishStatus(st);
                break;
            }
            case Protocol.SGET: {
                String owner = f[0].trim();
                String sid = f.length > 1 ? f[1].trim() : "";
                StatusStore.Status st = statusStore.get(owner, sid);
                if (st == null || st.data == null) {
                    sendError("Stato non più disponibile", "#status", sid);
                    return;
                }
                streamStatus(st);
                break;
            }
            case Protocol.SSEEN: {
                String owner = f[0].trim();
                String sid = f.length > 1 ? f[1].trim() : "";
                long t = statusStore.seen(owner, sid, nickname);
                ClientHandler o = t > 0 ? registry.find(owner) : null;
                if (o != null) {
                    o.send(Protocol.SSEEN + Protocol.SEP + nickname + Protocol.SEP + sid + Protocol.SEP + t);
                }
                break;
            }
            case Protocol.SDEL: {
                String sid = f[0].trim();
                if (statusStore.delete(nickname, sid)) {
                    ServerLog.info(nickname + " ha eliminato uno stato");
                    registry.broadcast(Protocol.SGONE + Protocol.SEP + nickname + Protocol.SEP + sid, null);
                }
                break;
            }
            default:
                break;
        }
    }

    private void publishStatus(StatusStore.Status st) {
        if (st == null) {
            return;
        }
        String kind = st.kind == 'T' ? "testo" : st.kind == 'I' ? "foto" : st.kind == 'G' ? "GIF" : "video";
        ServerLog.info(nickname + " ha pubblicato uno stato (" + kind + ")");
        registry.sendTo(ContactFeatures.audience(nickname), st.describe(), null);
    }

    /** Invia a questo client il contenuto di uno stato, a pezzi e con controllo di integrita'. */
    private void streamStatus(StatusStore.Status st) throws InterruptedException {
        byte[] d = st.data;
        String head = st.owner + Protocol.SEP + st.id + Protocol.SEP;
        int chunk = 48 * 1024;
        for (int i = 0; i < d.length; i += chunk) {
            int n = Math.min(chunk, d.length - i);
            String b64 = java.util.Base64.getEncoder().encodeToString(java.util.Arrays.copyOfRange(d, i, i + n));
            if (!enqueue(Protocol.SDATA + Protocol.SEP + head + b64, Outbox.Priority.BULK, BULK_TIMEOUT_MS)) {
                return;
            }
        }
        java.util.zip.CRC32 crc = new java.util.zip.CRC32();
        crc.update(d, 0, d.length);
        enqueue(Protocol.SDATAEND + Protocol.SEP + head + Long.toHexString(crc.getValue()), Outbox.Priority.BULK,
                BULK_TIMEOUT_MS);
    }

    /** Evento del gruppo + stato aggiornato a tutti i membri online. */
    private void notifyGroup(String gid, String event) {
        java.util.List<String> members = groups.members(gid);
        String state = groups.describe(gid);
        if (state != null) {
            registry.sendTo(members, state, null);
        }
        registry.sendTo(members, event, null);
    }

    private void notifyGroupState(String gid) {
        String state = groups.describe(gid);
        if (state != null) {
            registry.sendTo(groups.members(gid), state, null);
        }
    }

    /** Foto e chiamata in corso ai nuovi membri. */
    private void sendGroupExtras(String gid, java.util.List<String> newMembers) {
        String photo = groups.photo(gid);
        for (String m : newMembers) {
            ClientHandler h = registry.find(m);
            if (h == null) {
                continue;
            }
            if (!photo.isEmpty()) {
                h.send(Protocol.GPHOTO + Protocol.SEP + gid + Protocol.SEP + photo);
            }
            if (groups.callId(gid) != null) {
                h.send(groups.describeCall(gid));
            }
        }
    }

    private void notifyCall(String gid) {
        String c = groups.describeCall(gid);
        if (c != null) {
            registry.sendTo(groups.members(gid), c, null);
        }
    }

    /**
     * RS-06: inoltra al SOLO destinatario messaggi, file e chiamate.
     * RS-07: nulla viene salvato, il server fa solo da "postino".
     * Il formato inoltrato e' identico, con il mittente al posto del destinatario.
     */
    private void relay(String cmd, String rest) throws InterruptedException {
        if (!registered) {
            send(Protocol.ERR + Protocol.SEP + "Devi prima registrare un nickname");
            return;
        }
        int sep = rest.indexOf('|');
        String to = (sep < 0 ? rest : rest.substring(0, sep)).trim();
        String payload = sep < 0 ? "" : rest.substring(sep + 1);
        String ref = firstField(payload); // id del messaggio, del file o della chiamata
        // solo questi comandi meritano un avviso se qualcosa va storto; pezzi di file,
        // audio, video e conferme si scartano in silenzio (l'elenco utenti avvisa gia' chi invia)
        boolean notify = cmd.equals(Protocol.MSG) || cmd.equals(Protocol.FILE) || cmd.equals(Protocol.CALL)
                || cmd.equals(Protocol.POLL) || cmd.equals(Protocol.LOC) || cmd.equals(Protocol.GAME);

        if (to.isEmpty()) {
            if (notify) {
                send(Protocol.ERR + Protocol.SEP + "Destinatario mancante");
            }
            return;
        }
        if (sep < 0) {
            if (notify) {
                send(Protocol.ERR + Protocol.SEP + "Formato del messaggio non valido");
            }
            return;
        }

        // ---- controlli specifici per comando
        switch (cmd) {
            case Protocol.MSG:
            case Protocol.EDIT: {
                int p = payload.indexOf('|');
                String text = p < 0 ? "" : payload.substring(p + 1);
                if (cmd.equals(Protocol.MSG)) {
                    // v4: MSG|dest|id|meta|testo
                    int q = text.indexOf('|');
                    text = q < 0 ? "" : text.substring(q + 1);
                }
                if (ref.isEmpty() || text.trim().isEmpty()) {
                    sendError("Messaggio vuoto: non inviato", to, ref);
                    return;
                }
                if (text.length() > Protocol.MAX_TEXT_LENGTH) {
                    sendError("Messaggio troppo lungo: non inviato", to, ref);
                    return;
                }
                break;
            }
            case Protocol.POLL:
                if (ref.isEmpty() || payload.split("\\|", -1).length < 5) {
                    sendError("Sondaggio non valido: non inviato", to, ref);
                    return;
                }
                if (payload.length() > Protocol.MAX_TEXT_LENGTH * 2) {
                    sendError("Sondaggio troppo lungo: non inviato", to, ref);
                    return;
                }
                break;
            case Protocol.VIDEO:
                if (payload.length() > Protocol.MAX_VIDEO_CHARS) {
                    return;
                }
                break;
            case Protocol.FILE: {
                String[] f = payload.split("\\|", -1);
                long size;
                try {
                    size = f.length >= 4 ? Long.parseLong(f[2].trim()) : -1;
                } catch (NumberFormatException e) {
                    size = -1;
                }
                if (f.length < 4 || ref.isEmpty() || size < 0) {
                    sendError("Dati del file non validi: non inviato", to, ref);
                    return;
                }
                if (size > Protocol.MAX_FILE_SIZE) {
                    sendError("File troppo grande (massimo " + (Protocol.MAX_FILE_SIZE / (1024 * 1024))
                            + " MB): non inviato", to, ref);
                    return;
                }
                break;
            }
            case Protocol.AUDIO:
                if (payload.length() > Protocol.MAX_AUDIO_CHARS) {
                    return;
                }
                break;
            case Protocol.REACT:
            case Protocol.PIN:
            case Protocol.CALLREACT:
                if (ref.isEmpty() || payload.length() > 200) {
                    return;
                }
                break;
            case Protocol.LOC:
            case Protocol.LOCUPD:
            case Protocol.LOCSTOP:
            case Protocol.GAME:
                if (ref.isEmpty() || payload.length() > 4000) {
                    if (notify) {
                        sendError("Dati non validi: non inviati", to, ref);
                    }
                    return;
                }
                break;
            case Protocol.LINK:
                if (ref.isEmpty() || payload.length() > 160 * 1024) {
                    return;
                }
                break;
            case Protocol.TYPING:
                if (ref.isEmpty() || payload.length() > 10) {
                    return;
                }
                break;
            case Protocol.FILEPOS:
                if (ref.isEmpty() || payload.length() > 80 || to.startsWith("#")) {
                    return;
                }
                break;
            case Protocol.WB:
                if (ref.isEmpty() || payload.length() > 96 * 1024) {
                    return;
                }
                break;
            default:
                if (ref.isEmpty()) {
                    return; // pezzo di file o segnale di chiamata senza id: si ignora
                }
        }

        if (to.startsWith("#")) {
            relayGroup(cmd, to.substring(1), payload, ref, notify);
            return;
        }

        // final: si scrive solo a chi ha accettato la richiesta di contatto
        if (!Contacts.getInstance().areContacts(nickname, to)) {
            if (notify || cmd.equals(Protocol.CALLACCEPT) || cmd.equals(Protocol.TYPING)) {
                if (notify) {
                    sendError("Non puoi scrivere a " + Protocol.clean(to)
                            + ": prima deve accettare la tua richiesta di contatto", to, ref);
                }
            }
            return;
        }
        ClientHandler target = registry.find(to);
        if (target == null) {
            if (cmd.equals(Protocol.MSG)) {
                ServerLog.info("Messaggio da " + nickname + " per " + to + " scartato: destinatario offline");
                sendError("Messaggio non consegnato: " + Protocol.clean(to) + " non è online", to, ref);
            } else if (cmd.equals(Protocol.POLL)) {
                sendError("Sondaggio non consegnato: " + Protocol.clean(to) + " non è online", to, ref);
            } else if (cmd.equals(Protocol.FILE)) {
                sendError("File non inviato: " + Protocol.clean(to) + " non è online", to, ref);
            } else if (cmd.equals(Protocol.CALL)) {
                sendError("Impossibile chiamare " + Protocol.clean(to) + ": non è online", to, ref);
            } else if (notify) {
                sendError("Non consegnato: " + Protocol.clean(to) + " non è online", to, ref);
            }
            return;
        }
        if (target == this) {
            if (notify) {
                sendError("Non puoi inviare messaggi a te stesso", to, ref);
            }
            return;
        }

        String forwarded = cmd + Protocol.SEP + nickname + Protocol.SEP + payload;
        Outbox.Priority priority = priorityOf(cmd);
        boolean delivered = target.enqueue(forwarded, priority, BULK_TIMEOUT_MS);

        if (!delivered) {
            if (priority == Outbox.Priority.BULK && !cmd.equals(Protocol.FILECANCEL)) {
                sendError("Trasferimento interrotto: " + target.getNickname() + " non riceve dati", to, ref);
            } else if (cmd.equals(Protocol.MSG) || cmd.equals(Protocol.POLL)) {
                sendError("Messaggio non consegnato: " + target.getNickname() + " si è appena disconnesso", to, ref);
            } else if (cmd.equals(Protocol.CALL)) {
                sendError("Impossibile chiamare " + target.getNickname(), to, ref);
            }
            return;
        }
        logRelay(cmd, target.getNickname(), payload);
    }

    /**
     * v4: comando verso un gruppo. Va a tutti gli altri membri online; audio,
     * video e reazioni della chiamata solo a chi partecipa alla chiamata.
     * Il mittente diventa "#idGruppo/nickname".
     */
    private void relayGroup(String cmd, String gid, String payload, String ref, boolean notify)
            throws InterruptedException {
        String to = "#" + gid;
        if (!groups.isMember(gid, nickname)) {
            if (notify) {
                sendError("Non fai più parte di questo gruppo", to, ref);
            }
            return;
        }
        // v5: gruppo in cui scrivono solo gli amministratori
        if (groups.onlyAdmins(gid) && !groups.isAdmin(gid, nickname)) {
            switch (cmd) {
                case Protocol.MSG:
                case Protocol.FILE:
                case Protocol.POLL:
                case Protocol.LOC:
                case Protocol.GAME:
                case Protocol.WB:
                case Protocol.PIN:
                    sendError("Solo gli amministratori possono scrivere in questo gruppo", to, ref);
                    return;
                default:
                    break;
            }
        }
        java.util.List<String> recipients;
        switch (cmd) {
            case Protocol.AUDIO:
            case Protocol.VIDEO:
            case Protocol.VIDSTATE:
            case Protocol.CALLREACT:
                if (!groups.isParticipant(gid, nickname)) {
                    return;
                }
                recipients = groups.participants(gid);
                break;
            case Protocol.CALL: {
                boolean newCall = groups.callId(gid) == null;
                String err = groups.startOrJoin(gid, ref, payload.endsWith("|V"), nickname);
                if (err != null) {
                    sendError(err, to, ref);
                    return;
                }
                notifyCall(gid);
                if (!newCall) {
                    return; // si e' entrati in una chiamata gia' in corso
                }
                ServerLog.info((payload.endsWith("|V") ? "Videochiamata" : "Chiamata") + " di gruppo avviata da " + nickname);
                recipients = groups.members(gid);
                break;
            }
            case Protocol.CALLACCEPT: {
                String err = groups.startOrJoin(gid, ref, false, nickname);
                if (err != null || !ref.equals(groups.callId(gid))) {
                    sendError(err != null ? err : "La chiamata è già terminata", to, ref);
                    return;
                }
                notifyCall(gid);
                return;
            }
            case Protocol.CALLEND:
                if (groups.leaveCall(gid, ref, nickname)) {
                    notifyCall(gid);
                }
                return;
            case Protocol.CALLREJECT:
                return; // chi rifiuta la chiamata di gruppo semplicemente non entra
            default:
                recipients = groups.members(gid);
        }
        String forwarded = cmd + Protocol.SEP + to + "/" + nickname + Protocol.SEP + payload;
        Outbox.Priority priority = priorityOf(cmd);
        int delivered = 0;
        for (String m : recipients) {
            if (m.equalsIgnoreCase(nickname)) {
                continue;
            }
            ClientHandler h = registry.find(m);
            if (h != null && h.enqueue(forwarded, priority, priority == Outbox.Priority.BULK ? BULK_TIMEOUT_MS : 0)) {
                delivered++;
            }
        }
        if (delivered == 0 && notify) {
            sendError("Nessun altro membro del gruppo è online: non consegnato", to, ref);
            return;
        }
        logRelay(cmd, "gruppo " + groups.name(gid), payload);
    }

    private static Outbox.Priority priorityOf(String cmd) {
        switch (cmd) {
            case Protocol.AUDIO:
                return Outbox.Priority.AUDIO;
            case Protocol.VIDEO:
                return Outbox.Priority.VIDEO;
            case Protocol.FILE:
            case Protocol.CHUNK:
            case Protocol.FILEEND:
            case Protocol.FILECANCEL:
                return Outbox.Priority.BULK;
            default:
                return Outbox.Priority.HIGH;
        }
    }

    /** Log a console: chi scrive a chi, MAI il contenuto (privacy). */
    private void logRelay(String cmd, String targetName, String payload) {
        String a = nickname;
        String b = targetName;
        switch (cmd) {
            case Protocol.MSG:
                ServerLog.info("Messaggio inoltrato: " + a + " -> " + b);
                break;
            case Protocol.FILE: {
                String[] f = payload.split("\\|", -1);
                String kind = f.length > 1 ? f[1] : "FILE";
                String size = f.length > 2 ? humanSize(f[2]) : "?";
                ServerLog.info("Invio " + kindName(kind) + ": " + a + " -> " + b + " (" + size + ")");
                break;
            }
            case Protocol.FILECANCEL:
                ServerLog.info("Invio annullato: " + a + " -> " + b);
                break;
            case Protocol.EDIT:
                ServerLog.info("Messaggio modificato: " + a + " -> " + b);
                break;
            case Protocol.DEL:
                ServerLog.info("Messaggio eliminato per tutti: " + a + " -> " + b);
                break;
            case Protocol.POLL:
                ServerLog.info("Sondaggio inviato: " + a + " -> " + b);
                break;
            case Protocol.CALL:
                ServerLog.info((payload.endsWith("|V") ? "Videochiamata: " : "Chiamata vocale: ") + a + " -> " + b);
                break;
            case Protocol.CALLACCEPT:
                ServerLog.info("Chiamata accettata: " + a + " <-> " + b);
                break;
            case Protocol.CALLREJECT:
                ServerLog.info("Chiamata rifiutata: " + a + " -> " + b);
                break;
            case Protocol.CALLEND:
                ServerLog.info("Chiamata terminata: " + a + " <-> " + b);
                break;
            case Protocol.LOC:
                ServerLog.info("Posizione condivisa: " + a + " -> " + b);
                break;
            case Protocol.GAME:
                if (payload.contains("|new|")) {
                    ServerLog.info("Sfida a un minigioco: " + a + " -> " + b);
                }
                break;
            default:
                // CHUNK, FILEEND, AUDIO, VIDEO, ACK, VOTE, REACT, ...: troppo frequenti per il log
        }
    }

    private void sendError(String description, String recipient, String ref) {
        StringBuilder sb = new StringBuilder(Protocol.ERR).append(Protocol.SEP).append(description)
                .append(Protocol.SEP).append(Protocol.clean(recipient));
        if (ref != null && !ref.isEmpty()) {
            sb.append(Protocol.SEP).append(Protocol.clean(ref));
        }
        send(sb.toString());
    }

    private static String firstField(String payload) {
        int p = payload.indexOf('|');
        String f = (p < 0 ? payload : payload.substring(0, p)).trim();
        return f.length() > 64 ? f.substring(0, 64) : f;
    }

    private static String kindName(String kind) {
        switch (kind) {
            case "IMAGE":
                return "foto";
            case "VIDEO":
                return "video";
            case "VOICE":
                return "messaggio vocale";
            case "GIF":
                return "GIF";
            default:
                return "file";
        }
    }

    private static String humanSize(String bytes) {
        try {
            double b = Long.parseLong(bytes.trim());
            if (b < 1024) {
                return (long) b + " B";
            }
            if (b < 1024 * 1024) {
                return String.format("%.1f KB", b / 1024);
            }
            return String.format("%.1f MB", b / (1024 * 1024));
        } catch (NumberFormatException e) {
            return "?";
        }
    }

    /**
     * Invia una riga di controllo (testo, elenco, errori) a questo client.
     * Non blocca mai: la riga va nella coda in uscita.
     *
     * @return true se la riga e' stata accodata
     */
    public boolean send(String line) {
        try {
            return enqueue(line, Outbox.Priority.HIGH, 0);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return false;
        }
    }

    /** Accoda una riga per questo client con la priorita' indicata. */
    public boolean enqueue(String line, Outbox.Priority priority, long timeoutMs) throws InterruptedException {
        if (closed.get()) {
            return false;
        }
        boolean ok = outbox.offer(line, priority, timeoutMs);
        if (!ok && priority == Outbox.Priority.HIGH) {
            // migliaia di messaggi non letti: il client e' bloccato, si chiude
            ServerLog.warn(describe() + " non legge piu' i messaggi: connessione chiusa");
            close();
        }
        return ok;
    }

    /** Scrittura diretta (solo prima che parta il thread di scrittura). */
    private void writeDirect(String line) {
        try {
            BufferedWriter w = out;
            if (w != null) {
                w.write(line);
                w.write('\n');
                w.flush();
            }
        } catch (Throwable ignored) {
            // si chiude comunque
        }
    }

    /** Final: chiude dopo un attimo (per far partire l'ultimo avviso). */
    void closeLater() {
        Thread t = new Thread(() -> {
            try {
                Thread.sleep(400);
            } catch (InterruptedException ignored) {
                // si chiude subito
            }
            close();
        }, "close-later");
        t.setDaemon(true);
        t.start();
    }

    // ================================================================ final: account

    /** AUTH|login|utente|passB64 · AUTH|register|utente|passB64|email · AUTH|token|utente|gettone · AUTH|code|email|codice */
    private void handleAuth(String rest) {
        if (registered) {
            send(Protocol.ERR + Protocol.SEP + "Hai già effettuato l'accesso");
            return;
        }
        String[] f = rest.split("\\|", -1);
        String mode = f.length > 0 ? f[0].trim().toLowerCase(java.util.Locale.ROOT) : "";
        String who = getIp();
        String user;
        boolean giveToken = true;
        switch (mode) {
            case "login": {
                user = f.length > 1 ? f[1].trim() : "";
                String err = accounts.checkPassword(user, f.length > 2 ? b64(f[2]) : null, who);
                if (err != null) {
                    send("AUTHERR" + Protocol.SEP + err + Protocol.SEP + "pass");
                    return;
                }
                break;
            }
            case "register": {
                user = f.length > 1 ? f[1].trim() : "";
                String email = f.length > 4 ? f[4].trim() : "";
                String err = accounts.register(user, f.length > 2 ? b64(f[2]) : null, "");
                if (err != null) {
                    send("AUTHERR" + Protocol.SEP + err + Protocol.SEP + (err.contains("password") ? "pass" : "user"));
                    return;
                }
                if (!email.isEmpty()) {
                    final String u = user;
                    String[] c = accounts.startEmailChange(user, email);
                    if (c[0] != null) {
                        mailCode(email, "Conferma la tua email", "Ciao " + u + ",\n\nil codice per confermare la tua email su"
                                + " Ghost-chat è:\n\n    " + c[0] + "\n\nScade tra 10 minuti.", "ACCOUNT|codesent|" + email);
                    }
                }
                break;
            }
            case "token": {
                user = f.length > 1 ? f[1].trim() : "";
                if (!accounts.checkToken(user, f.length > 2 ? f[2].trim() : "")) {
                    send("AUTHERR" + Protocol.SEP + "Sessione scaduta: accedi di nuovo con la password" + Protocol.SEP + "token");
                    return;
                }
                giveToken = false;
                break;
            }
            case "code": {
                String res = accounts.useLoginCode(f.length > 1 ? f[1] : "", f.length > 2 ? f[2] : "", who);
                if (res.startsWith("!")) {
                    send("AUTHERR" + Protocol.SEP + res.substring(1) + Protocol.SEP + "code");
                    return;
                }
                user = res;
                break;
            }
            default:
                send("AUTHERR" + Protocol.SEP + "Modalità di accesso sconosciuta" + Protocol.SEP + "user");
                return;
        }
        String canon = accounts.canonical(user);
        if (canon == null) {
            send("AUTHERR" + Protocol.SEP + "Account inesistente" + Protocol.SEP + "user");
            return;
        }
        nickname = canon;
        registry.registerReplacing(canon, this);
        registered = true;
        String token = giveToken ? accounts.newToken(canon) : "";
        ServerLog.info("Accesso: " + canon + " @ " + getIp() + " (" + mode + ", utenti online: " + registry.size() + ")");
        send(Protocol.WELCOME + Protocol.SEP + canon + Protocol.SEP + getIp() + Protocol.SEP + token + Protocol.SEP
                + accounts.email(canon) + Protocol.SEP + (accounts.emailVerified(canon) ? "1" : "0"));
        registry.broadcastUserList();
        sendInitialState();
    }

    /** MAILCODE|email: codice di accesso rapido via posta. */
    private void handleMailCode(String rest) {
        String email = rest.trim();
        String[] r = accounts.loginCode(email, getIp());
        if (r[0] == null) {
            send("MAILCODE" + Protocol.SEP + "err" + Protocol.SEP + r[1]);
            return;
        }
        mailCode(r[1], "Il tuo codice di accesso", "Ciao " + r[2] + ",\n\nil codice per entrare in Ghost-chat è:\n\n    " + r[0]
                + "\n\nScade tra 10 minuti. Se non l'hai chiesto tu, ignora questa email.", "MAILCODE|ok|" + mask(r[1]));
    }

    void mailCode(String to, String subject, String body, String okLine) {
        Mailer.sendAsync(to, "Ghost-chat · " + subject, body, err -> {
            if (err == null) {
                send(okLine);
            } else if (okLine.startsWith("MAILCODE")) {
                send("MAILCODE" + Protocol.SEP + "err" + Protocol.SEP + "Invio dell'email non riuscito: " + err);
            } else {
                send("ACCOUNT" + Protocol.SEP + "err" + Protocol.SEP + "Invio dell'email non riuscito: " + err);
            }
        });
    }

    private static String mask(String email) {
        int a = email.indexOf('@');
        if (a <= 1) {
            return email;
        }
        return email.charAt(0) + "•••" + email.substring(a - 1);
    }

    static String b64(String s) {
        try {
            return new String(java.util.Base64.getDecoder().decode(s.trim()), StandardCharsets.UTF_8);
        } catch (IllegalArgumentException e) {
            return "";
        }
    }

    Accounts accounts() {
        return accounts;
    }

    Groups groups() {
        return groups;
    }

    void notifyGroupPublic(String gid, String event) {
        notifyGroup(gid, event);
    }

    void sendGroupExtrasPublic(String gid, java.util.List<String> newMembers) {
        sendGroupExtras(gid, newMembers);
    }

    void sendErrorPublic(String description, String recipient, String ref) {
        sendError(description, recipient, ref);
    }

    /** Chiude la socket (la pulizia vera la fa il thread del client in {@link #disconnect()}). */
    public void close() {
        if (closed.compareAndSet(false, true)) {
            outbox.close();
            try {
                socket.close();
            } catch (Throwable ignored) {
                // gia' chiusa
            }
        }
    }

    /** RS-05: chiude la socket, rimuove il client e notifica gli altri. */
    private void disconnect() {
        close();
        try {
            if (registered && registry.remove(this)) {
                registered = false;
                statusStore.abortAll(nickname);
                insta.abortAll(nickname);
                for (String gid : groups.leaveAllCalls(nickname)) {
                    notifyCall(gid);
                }
                ServerLog.info("Utente disconnesso: " + nickname + " @ " + ip
                        + " (utenti online: " + registry.size() + ")");
                registry.broadcastUserList();
            } else {
                ServerLog.info("Connessione chiusa: " + ip);
            }
        } catch (Throwable t) {
            ServerLog.error("Errore durante la disconnessione di " + describe(), t);
        }
    }

    private String describe() {
        return nickname != null ? nickname + " (" + ip + ")" : ip;
    }

    private static String abbreviate(String s) {
        if (s == null) {
            return "";
        }
        return s.length() > 60 ? s.substring(0, 60) + "..." : s;
    }

    /** v5: campo con "\\p" al posto di "|", "\\n" al posto dell'a capo e "\\\\" al posto di "\\". */
    private static String unescapeField(String s) {
        StringBuilder sb = new StringBuilder(s.length());
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '\\' && i + 1 < s.length()) {
                char n = s.charAt(++i);
                sb.append(n == 'p' ? '|' : n == 'n' ? '\n' : n);
            } else {
                sb.append(c);
            }
        }
        return sb.toString();
    }
}
