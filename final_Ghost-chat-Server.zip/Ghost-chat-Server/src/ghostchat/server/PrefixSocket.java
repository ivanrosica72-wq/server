package ghostchat.server;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.SequenceInputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.net.SocketException;

/**
 * Final (porta unica): una connessione di cui sono gia' stati letti i primi
 * byte per capire il tipo (protocollo Ghost-chat, TLS o HTTP/WebSocket).
 * Quei byte vengono "rimessi davanti" allo stream, il resto passa al socket vero.
 */
final class PrefixSocket extends Socket {

    private final Socket s;
    private final InputStream in;

    PrefixSocket(Socket s, byte[] prefix, int len) throws IOException {
        this.s = s;
        this.in = len <= 0 ? s.getInputStream()
                : new SequenceInputStream(new ByteArrayInputStream(prefix, 0, len), s.getInputStream());
    }

    @Override
    public InputStream getInputStream() {
        return in;
    }

    @Override
    public OutputStream getOutputStream() throws IOException {
        return s.getOutputStream();
    }

    @Override
    public InetAddress getInetAddress() {
        return s.getInetAddress();
    }

    @Override
    public int getPort() {
        return s.getPort();
    }

    @Override
    public int getLocalPort() {
        return s.getLocalPort();
    }

    @Override
    public SocketAddress getRemoteSocketAddress() {
        return s.getRemoteSocketAddress();
    }

    @Override
    public void setSoTimeout(int timeout) throws SocketException {
        s.setSoTimeout(timeout);
    }

    @Override
    public int getSoTimeout() throws SocketException {
        return s.getSoTimeout();
    }

    @Override
    public void setTcpNoDelay(boolean on) throws SocketException {
        s.setTcpNoDelay(on);
    }

    @Override
    public void setKeepAlive(boolean on) throws SocketException {
        s.setKeepAlive(on);
    }

    @Override
    public boolean isClosed() {
        return s.isClosed();
    }

    @Override
    public boolean isConnected() {
        return s.isConnected();
    }

    @Override
    public void shutdownOutput() throws IOException {
        s.shutdownOutput();
    }

    @Override
    public void shutdownInput() throws IOException {
        s.shutdownInput();
    }

    @Override
    public synchronized void close() throws IOException {
        s.close();
    }
}
