package ghostchat.server;

import java.util.ArrayDeque;

/**
 * Coda dei messaggi in uscita verso UN client, con tre priorita':
 * <ol>
 * <li>{@link Priority#HIGH}: testo, elenco utenti, errori, segnali di chiamata;</li>
 * <li>{@link Priority#AUDIO}: audio delle chiamate (se si accumula troppo,
 * il piu' vecchio viene scartato: meglio perdere 40 ms che accumulare ritardo);</li>
 * <li>{@link Priority#VIDEO}: fotogrammi delle videochiamate (ne restano in coda
 * al massimo pochi: quelli vecchi si scartano, conta solo l'immagine piu' recente);</li>
 * <li>{@link Priority#BULK}: pezzi dei file (se il destinatario e' lento, chi
 * invia viene rallentato invece di riempire la memoria del server).</li>
 * </ol>
 * Cosi' un file grande non blocca mai la chat ne' le chiamate. Nessun messaggio
 * viene conservato: la coda contiene solo cio' che e' in viaggio (RS-07).
 */
public final class Outbox {

    public enum Priority {
        HIGH, AUDIO, VIDEO, BULK
    }

    private static final int MAX_HIGH_LINES = 20000;
    private static final long MAX_AUDIO_CHARS = 256L * 1024;
    private static final long MAX_BULK_CHARS = 8L * 1024 * 1024;

    private final ArrayDeque<String> high = new ArrayDeque<>();
    private final ArrayDeque<String> audio = new ArrayDeque<>();
    private final ArrayDeque<String> video = new ArrayDeque<>();
    private static final int MAX_VIDEO_FRAMES = 3;
    private final ArrayDeque<String> bulk = new ArrayDeque<>();
    private long audioChars;
    private long bulkChars;
    private boolean closed;

    /**
     * Accoda una riga.
     *
     * @param timeoutMs solo per BULK: quanto attendere se la coda e' piena
     * @return false se la coda e' chiusa, piena o il tempo e' scaduto
     */
    public synchronized boolean offer(String line, Priority priority, long timeoutMs) throws InterruptedException {
        if (closed || line == null) {
            return false;
        }
        switch (priority) {
            case AUDIO:
                audio.addLast(line);
                audioChars += line.length();
                while (audioChars > MAX_AUDIO_CHARS && audio.size() > 1) {
                    audioChars -= audio.pollFirst().length();
                }
                break;
            case VIDEO:
                video.addLast(line);
                while (video.size() > MAX_VIDEO_FRAMES) {
                    video.pollFirst();
                }
                break;
            case BULK: {
                long deadline = System.currentTimeMillis() + Math.max(0, timeoutMs);
                while (!closed && !bulk.isEmpty() && bulkChars + line.length() > MAX_BULK_CHARS) {
                    long remaining = deadline - System.currentTimeMillis();
                    if (remaining <= 0) {
                        return false;
                    }
                    wait(remaining);
                }
                if (closed) {
                    return false;
                }
                bulk.addLast(line);
                bulkChars += line.length();
                break;
            }
            case HIGH:
            default:
                if (high.size() >= MAX_HIGH_LINES) {
                    return false;
                }
                high.addLast(line);
        }
        notifyAll();
        return true;
    }

    /** @return la prossima riga da inviare (bloccante), oppure null se la coda e' stata chiusa. */
    public synchronized String take() throws InterruptedException {
        while (!closed && high.isEmpty() && audio.isEmpty() && video.isEmpty() && bulk.isEmpty()) {
            wait();
        }
        if (closed) {
            return null;
        }
        String s = high.pollFirst();
        if (s == null) {
            s = audio.pollFirst();
            if (s != null) {
                audioChars -= s.length();
            }
        }
        if (s == null) {
            s = video.pollFirst();
        }
        if (s == null) {
            s = bulk.pollFirst();
            if (s != null) {
                bulkChars -= s.length();
                notifyAll(); // si e' liberato spazio per chi sta inviando un file
            }
        }
        return s;
    }

    public synchronized boolean isEmpty() {
        return high.isEmpty() && audio.isEmpty() && video.isEmpty() && bulk.isEmpty();
    }

    public synchronized void close() {
        closed = true;
        high.clear();
        audio.clear();
        video.clear();
        bulk.clear();
        audioChars = 0;
        bulkChars = 0;
        notifyAll();
    }
}
