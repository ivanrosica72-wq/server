package ghostchat.server;

import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Final: giochi di carte esclusivi dei gruppi, gestiti dal server (cosi' nessuno
 * vede le carte degli altri e le regole sono uguali per desktop, Android e iOS).
 * <p>
 * Mazzo da 40 carte "Ghost": i semi italiani sono sostituiti da simboli
 * dell'app (0 = Fantasmi al posto delle coppe, 1 = Bare al posto dei denari,
 * 2 = Fumetti al posto delle spade, 3 = Stelle al posto dei bastoni). I semi
 * "rossi" (Fantasmi e Bare) si disegnano nel viola di Ghost-chat.
 * Codice carta = seme * 10 + (valore - 1), valore 1..10 (8 Fante, 9 Cavallo, 10 Re).
 * <p>
 * Giochi: briscola (2 o 4 a coppie), scopa (2 o 4 a coppie), rubamazzo (2-4),
 * sette e mezzo (2-8 contro il banco del server).
 */
public final class CardGames {

    private static final CardGames INSTANCE = new CardGames();
    private static final SecureRandom RANDOM = new SecureRandom();
    static final String[] SUITS = {"Fantasmi", "Bare", "Fumetti", "Stelle"};
    static final String[] TYPES = {"briscola", "scopa", "rubamazzo", "settemezzo"};

    public static CardGames getInstance() {
        return INSTANCE;
    }

    /** Un giocatore. */
    static final class Player {

        final String nick;
        boolean accepted;
        final List<Integer> hand = new ArrayList<>();
        final List<Integer> pile = new ArrayList<>();
        int scope;
        int points;
        boolean stood;
        boolean bust;
        boolean left;

        Player(String nick) {
            this.nick = nick;
        }
    }

    /** Una partita. */
    static final class Game {

        final String id;
        final String gid;
        final String type;
        final String host;
        final List<Player> players = new ArrayList<>();
        final List<Integer> deck = new ArrayList<>();
        final List<Integer> table = new ArrayList<>();
        /** carte giocate nella mano corrente: {indice giocatore, carta} */
        final List<int[]> trick = new ArrayList<>();
        final List<Integer> bank = new ArrayList<>();
        String phase = "lobby";
        int turn;
        int starter;
        int briscola = -1;
        int lastTaker = -1;
        String message = "";
        String result = "";
        long updated = System.currentTimeMillis();

        Game(String id, String gid, String type, String host) {
            this.id = id;
            this.gid = gid;
            this.type = type;
            this.host = host;
        }

        int index(String nick) {
            for (int i = 0; i < players.size(); i++) {
                if (players.get(i).nick.equalsIgnoreCase(nick)) {
                    return i;
                }
            }
            return -1;
        }

        boolean teams() {
            return players.size() == 4 && (type.equals("briscola") || type.equals("scopa"));
        }
    }

    private final Map<String, Game> games = new HashMap<>();

    private CardGames() {
    }

    // ================================================================ comandi

    /**
     * Esegue un'azione. @return la partita toccata (da notificare) oppure una
     * stringa d'errore che inizia con "!" dentro {@code err[0]}.
     */
    public synchronized Game act(String gid, String gameId, String me, String action, String[] args, String[] err) {
        err[0] = null;
        Game g = games.get(gameId);
        switch (action) {
            case "new": {
                if (g != null) {
                    err[0] = "Partita già esistente";
                    return null;
                }
                String type = args.length > 0 ? args[0].trim().toLowerCase(Locale.ROOT) : "";
                boolean known = false;
                for (String t : TYPES) {
                    known |= t.equals(type);
                }
                if (!known || !gameId.matches("[A-Za-z0-9]{6,32}")) {
                    err[0] = "Gioco sconosciuto";
                    return null;
                }
                g = new Game(gameId, gid, type, me);
                g.players.add(new Player(me));
                g.players.get(0).accepted = true;
                if (args.length > 1) {
                    for (String n : args[1].split(",")) {
                        if (!n.trim().isEmpty() && g.index(n.trim()) < 0 && Groups.getInstance().isMember(gid, n.trim())) {
                            g.players.add(new Player(n.trim()));
                        }
                    }
                }
                String range = check(type, g.players.size());
                if (range != null) {
                    err[0] = range;
                    return null;
                }
                // niente partite abbandonate in memoria all'infinito
                long now = System.currentTimeMillis();
                games.values().removeIf(x -> now - x.updated > 6 * 3600_000L);
                games.put(gameId, g);
                g.message = me + " propone una partita: aspettiamo gli altri giocatori";
                return g;
            }
            case "accept":
            case "decline": {
                if (g == null || !g.phase.equals("lobby")) {
                    err[0] = "La partita non è più disponibile";
                    return null;
                }
                int i = g.index(me);
                if (i < 0) {
                    err[0] = "Non sei tra i giocatori di questa partita";
                    return null;
                }
                if (action.equals("decline")) {
                    g.players.remove(i);
                    g.message = me + " non gioca";
                    if (check(g.type, g.players.size()) != null) {
                        g.phase = "end";
                        g.result = "Partita annullata: non ci sono abbastanza giocatori";
                    }
                } else {
                    g.players.get(i).accepted = true;
                    g.message = me + " è pronto";
                }
                boolean all = true;
                for (Player p : g.players) {
                    all &= p.accepted;
                }
                if (all && g.phase.equals("lobby")) {
                    start(g);
                }
                g.updated = System.currentTimeMillis();
                return g;
            }
            case "play": {
                if (g == null || !g.phase.equals("play")) {
                    err[0] = "La partita non è in corso";
                    return null;
                }
                int i = g.index(me);
                int card;
                try {
                    card = Integer.parseInt(args.length > 0 ? args[0].trim() : "-1");
                } catch (NumberFormatException e) {
                    card = -1;
                }
                if (i < 0 || i != g.turn || !g.players.get(i).hand.contains(card)) {
                    err[0] = "Non è il tuo turno o la carta non è valida";
                    return null;
                }
                play(g, i, card);
                g.updated = System.currentTimeMillis();
                return g;
            }
            case "hit":
            case "stand": {
                if (g == null || !g.phase.equals("play") || !g.type.equals("settemezzo")) {
                    err[0] = "Azione non valida";
                    return null;
                }
                int i = g.index(me);
                if (i < 0 || i != g.turn) {
                    err[0] = "Non è il tuo turno";
                    return null;
                }
                sevenHalf(g, i, action.equals("hit"));
                g.updated = System.currentTimeMillis();
                return g;
            }
            case "quit": {
                if (g == null) {
                    return null;
                }
                int i = g.index(me);
                if (i < 0) {
                    return null;
                }
                if (!g.phase.equals("end")) {
                    g.phase = "end";
                    g.result = me + " ha abbandonato la partita";
                }
                g.players.get(i).left = true;
                g.updated = System.currentTimeMillis();
                return g;
            }
            case "state":
                if (g == null) {
                    err[0] = "La partita non esiste più";
                }
                return g;
            default:
                err[0] = "Azione sconosciuta";
                return null;
        }
    }

    private static String check(String type, int n) {
        switch (type) {
            case "briscola":
            case "scopa":
                return n == 2 || n == 4 ? null : "Per " + type + " servono 2 o 4 giocatori";
            case "rubamazzo":
                return n >= 2 && n <= 4 ? null : "Per rubamazzo servono da 2 a 4 giocatori";
            default:
                return n >= 1 && n <= 8 ? null : "Per sette e mezzo servono da 1 a 8 giocatori";
        }
    }

    // ================================================================ regole

    private void start(Game g) {
        g.deck.clear();
        for (int c = 0; c < 40; c++) {
            g.deck.add(c);
        }
        Collections.shuffle(g.deck, RANDOM);
        g.phase = "play";
        g.starter = RANDOM.nextInt(g.players.size());
        g.turn = g.starter;
        switch (g.type) {
            case "briscola":
                for (Player p : g.players) {
                    draw(g, p, 3);
                }
                g.briscola = g.deck.remove(0);
                g.deck.add(g.briscola); // la briscola sta in fondo al mazzo, scoperta
                g.message = "Briscola: " + name(g.briscola) + ". Inizia " + g.players.get(g.turn).nick;
                break;
            case "scopa":
            case "rubamazzo":
                for (Player p : g.players) {
                    draw(g, p, 3);
                }
                for (int i = 0; i < 4; i++) {
                    g.table.add(g.deck.remove(0));
                }
                g.message = "Inizia " + g.players.get(g.turn).nick;
                break;
            default:
                g.turn = 0;
                for (Player p : g.players) {
                    draw(g, p, 1);
                }
                g.bank.add(g.deck.remove(0));
                g.message = "Tocca a " + g.players.get(0).nick + ": carta o stai?";
                break;
        }
    }

    private static void draw(Game g, Player p, int n) {
        for (int i = 0; i < n && !g.deck.isEmpty(); i++) {
            p.hand.add(g.deck.remove(0));
        }
    }

    private void play(Game g, int i, int card) {
        Player p = g.players.get(i);
        p.hand.remove(Integer.valueOf(card));
        switch (g.type) {
            case "briscola":
                briscola(g, i, card);
                break;
            case "scopa":
                scopa(g, i, card);
                break;
            default:
                rubamazzo(g, i, card);
                break;
        }
    }

    // ---------------------------------------------------------------- briscola

    private static final int[] BRISCOLA_POINTS = {11, 0, 10, 0, 0, 0, 0, 2, 3, 4};
    private static final int[] BRISCOLA_ORDER = {10, 1, 9, 2, 3, 4, 5, 6, 7, 8};

    private void briscola(Game g, int i, int card) {
        g.trick.add(new int[]{i, card});
        if (g.trick.size() < g.players.size()) {
            g.turn = (i + 1) % g.players.size();
            g.message = g.players.get(i).nick + " gioca " + name(card) + ". Tocca a " + g.players.get(g.turn).nick;
            return;
        }
        int best = 0;
        for (int k = 1; k < g.trick.size(); k++) {
            if (beats(g.trick.get(k)[1], g.trick.get(best)[1], g.briscola / 10)) {
                best = k;
            }
        }
        int winner = g.trick.get(best)[0];
        int pts = 0;
        for (int[] t : g.trick) {
            g.players.get(winner).pile.add(t[1]);
            pts += BRISCOLA_POINTS[t[1] % 10];
        }
        g.players.get(winner).points += pts;
        g.message = g.players.get(winner).nick + " prende (" + pts + " punti)";
        g.trick.clear();
        // si pesca a partire da chi ha preso
        for (int k = 0; k < g.players.size(); k++) {
            draw(g, g.players.get((winner + k) % g.players.size()), 1);
        }
        g.turn = winner;
        boolean empty = true;
        for (Player p : g.players) {
            empty &= p.hand.isEmpty();
        }
        if (empty) {
            finish(g);
        }
    }

    private static boolean beats(int c, int best, int trump) {
        int cs = c / 10;
        int bs = best / 10;
        if (cs == bs) {
            return BRISCOLA_ORDER[c % 10] > BRISCOLA_ORDER[best % 10];
        }
        return cs == trump;
    }

    // ---------------------------------------------------------------- scopa

    private void scopa(Game g, int i, int card) {
        Player p = g.players.get(i);
        int v = card % 10 + 1;
        List<Integer> take = null;
        for (int t : g.table) {
            if (t % 10 + 1 == v) {
                take = new ArrayList<>(Collections.singletonList(t));
                // a parita' si preferisce il sette di Bare
                if (t == 16) {
                    break;
                }
            }
        }
        if (take == null) {
            take = bestSum(g.table, v);
        }
        if (take == null || take.isEmpty()) {
            g.table.add(card);
            g.message = p.nick + " cala " + name(card);
        } else {
            g.table.removeAll(take);
            p.pile.add(card);
            p.pile.addAll(take);
            g.lastTaker = i;
            boolean lastPlay = g.deck.isEmpty() && allEmpty(g);
            if (g.table.isEmpty() && !lastPlay) {
                p.scope++;
                g.message = p.nick + " fa SCOPA con " + name(card) + "!";
            } else {
                g.message = p.nick + " prende " + take.size() + (take.size() == 1 ? " carta" : " carte") + " con " + name(card);
            }
        }
        advanceRound(g, i);
    }

    /** Combinazione di carte del tavolo che somma v: si preferiscono sette di Bare, Bare e piu' carte. */
    private static List<Integer> bestSum(List<Integer> table, int v) {
        List<Integer> best = null;
        int bestScore = -1;
        int n = table.size();
        for (int mask = 1; mask < (1 << n); mask++) {
            int sum = 0;
            int score = 0;
            List<Integer> pick = new ArrayList<>();
            for (int k = 0; k < n; k++) {
                if ((mask & (1 << k)) != 0) {
                    int c = table.get(k);
                    sum += c % 10 + 1;
                    pick.add(c);
                    score += 1 + (c / 10 == 1 ? 3 : 0) + (c == 16 ? 50 : 0) + (c % 10 == 6 ? 2 : 0);
                }
            }
            if (sum == v && pick.size() > 1 && score > bestScore) {
                best = pick;
                bestScore = score;
            }
        }
        return best;
    }

    private static boolean allEmpty(Game g) {
        for (Player p : g.players) {
            if (!p.hand.isEmpty()) {
                return false;
            }
        }
        return true;
    }

    /** Dopo una giocata (scopa e rubamazzo): turno successivo, nuova distribuzione o fine. */
    private void advanceRound(Game g, int i) {
        g.turn = (i + 1) % g.players.size();
        if (allEmpty(g)) {
            if (g.deck.isEmpty()) {
                if (!g.table.isEmpty() && g.lastTaker >= 0) {
                    g.players.get(g.lastTaker).pile.addAll(g.table);
                    g.table.clear();
                }
                finish(g);
                return;
            }
            for (int k = 0; k < g.players.size(); k++) {
                draw(g, g.players.get((g.starter + k) % g.players.size()), 3);
            }
            g.turn = g.starter;
        }
        if (g.phase.equals("play")) {
            g.message += ". Tocca a " + g.players.get(g.turn).nick;
        }
    }

    // ---------------------------------------------------------------- rubamazzo

    private void rubamazzo(Game g, int i, int card) {
        Player p = g.players.get(i);
        int v = card % 10;
        // prima si prova a rubare il mazzetto di un avversario
        for (int k = 0; k < g.players.size(); k++) {
            Player o = g.players.get(k);
            if (k != i && !o.pile.isEmpty() && o.pile.get(o.pile.size() - 1) % 10 == v) {
                p.pile.addAll(o.pile);
                int stolen = o.pile.size();
                o.pile.clear();
                p.pile.add(card);
                g.lastTaker = i;
                g.message = p.nick + " ruba il mazzo di " + o.nick + " (" + stolen + " carte)!";
                advanceRound(g, i);
                return;
            }
        }
        for (int t : g.table) {
            if (t % 10 == v) {
                g.table.remove(Integer.valueOf(t));
                p.pile.add(t);
                p.pile.add(card);
                g.lastTaker = i;
                g.message = p.nick + " prende " + name(t);
                advanceRound(g, i);
                return;
            }
        }
        g.table.add(card);
        g.message = p.nick + " cala " + name(card);
        advanceRound(g, i);
    }

    // ---------------------------------------------------------------- sette e mezzo

    private static double sevenValue(List<Integer> cards) {
        double s = 0;
        for (int c : cards) {
            int r = c % 10 + 1;
            s += r >= 8 ? 0.5 : r;
        }
        return s;
    }

    private void sevenHalf(Game g, int i, boolean hit) {
        Player p = g.players.get(i);
        if (hit) {
            draw(g, p, 1);
            double v = sevenValue(p.hand);
            if (v > 7.5) {
                p.bust = true;
                p.stood = true;
                g.message = p.nick + " ha sballato (" + fmt(v) + ")";
            } else if (v == 7.5) {
                p.stood = true;
                g.message = p.nick + " fa SETTE E MEZZO!";
            } else {
                g.message = p.nick + " pesca: " + fmt(v) + ". Carta o stai?";
                return;
            }
        } else {
            p.stood = true;
            g.message = p.nick + " sta con " + fmt(sevenValue(p.hand));
        }
        int next = -1;
        for (int k = i + 1; k < g.players.size(); k++) {
            if (!g.players.get(k).stood) {
                next = k;
                break;
            }
        }
        if (next >= 0) {
            g.turn = next;
            g.message += ". Tocca a " + g.players.get(next).nick;
            return;
        }
        // gioca il banco: pesca finche' non arriva almeno a 5
        while (sevenValue(g.bank) < 5 && !g.deck.isEmpty()) {
            g.bank.add(g.deck.remove(0));
        }
        double bank = sevenValue(g.bank);
        StringBuilder sb = new StringBuilder("Banco: " + fmt(bank) + (bank > 7.5 ? " (sballa)" : "") + ". ");
        List<String> winners = new ArrayList<>();
        for (Player pl : g.players) {
            double v = sevenValue(pl.hand);
            boolean win = !pl.bust && (bank > 7.5 || v > bank);
            pl.points = win ? 1 : 0;
            if (win) {
                winners.add(pl.nick);
            }
        }
        sb.append(winners.isEmpty() ? "Vince il banco!" : "Battono il banco: " + String.join(", ", winners));
        g.phase = "end";
        g.result = sb.toString();
    }

    private static String fmt(double v) {
        return v == Math.floor(v) ? String.valueOf((int) v) : String.valueOf(v).replace('.', ',');
    }

    // ---------------------------------------------------------------- fine e punteggi

    private void finish(Game g) {
        g.phase = "end";
        g.trick.clear();
        switch (g.type) {
            case "briscola": {
                if (g.teams()) {
                    int a = g.players.get(0).points + g.players.get(2).points;
                    int b = g.players.get(1).points + g.players.get(3).points;
                    g.result = a == b ? "Pareggio 60 a 60!"
                            : "Vincono " + (a > b ? g.players.get(0).nick + " e " + g.players.get(2).nick
                                    : g.players.get(1).nick + " e " + g.players.get(3).nick) + " (" + Math.max(a, b) + " a "
                            + Math.min(a, b) + ")";
                } else {
                    g.result = winnerText(g, "punti");
                }
                break;
            }
            case "scopa": {
                int sides = g.teams() ? 2 : g.players.size();
                int[] score = new int[sides];
                List<List<Integer>> piles = new ArrayList<>();
                int[] scope = new int[sides];
                for (int s = 0; s < sides; s++) {
                    piles.add(new ArrayList<>());
                }
                for (int k = 0; k < g.players.size(); k++) {
                    int s = g.teams() ? k % 2 : k;
                    piles.get(s).addAll(g.players.get(k).pile);
                    scope[s] += g.players.get(k).scope;
                }
                StringBuilder detail = new StringBuilder();
                award(piles, score, sides, "carte", pile -> pile.size(), detail);
                award(piles, score, sides, "denari (Bare)", pile -> count(pile, c -> c / 10 == 1), detail);
                award(piles, score, sides, "primiera", CardGames::primiera, detail);
                for (int s = 0; s < sides; s++) {
                    if (piles.get(s).contains(16)) {
                        score[s]++;
                        detail.append("settebello: ").append(sideName(g, s)).append(" · ");
                    }
                    score[s] += scope[s];
                }
                for (int k = 0; k < g.players.size(); k++) {
                    g.players.get(k).points = score[g.teams() ? k % 2 : k];
                }
                int best = 0;
                boolean tie = false;
                for (int s = 1; s < sides; s++) {
                    if (score[s] > score[best]) {
                        best = s;
                        tie = false;
                    } else if (score[s] == score[best]) {
                        tie = true;
                    }
                }
                g.result = (tie ? "Pareggio! " : "Vince " + sideName(g, best) + " con " + score[best] + " punti. ") + detail;
                break;
            }
            case "rubamazzo":
                for (Player p : g.players) {
                    p.points = p.pile.size();
                }
                g.result = winnerText(g, "carte");
                break;
            default:
                break;
        }
    }

    private interface Measure {

        int of(List<Integer> pile);
    }

    private static void award(List<List<Integer>> piles, int[] score, int sides, String what, Measure m, StringBuilder detail) {
        int best = -1;
        int bestV = -1;
        boolean tie = false;
        for (int s = 0; s < sides; s++) {
            int v = m.of(piles.get(s));
            if (v > bestV) {
                bestV = v;
                best = s;
                tie = false;
            } else if (v == bestV) {
                tie = true;
            }
        }
        if (!tie && best >= 0) {
            score[best]++;
            detail.append(what).append(" · ");
        }
    }

    private static int count(List<Integer> pile, java.util.function.IntPredicate p) {
        int n = 0;
        for (int c : pile) {
            if (p.test(c)) {
                n++;
            }
        }
        return n;
    }

    private static final int[] PRIMIERA = {16, 12, 13, 14, 15, 18, 21, 10, 10, 10};

    private static int primiera(List<Integer> pile) {
        int total = 0;
        for (int s = 0; s < 4; s++) {
            int best = 0;
            for (int c : pile) {
                if (c / 10 == s) {
                    best = Math.max(best, PRIMIERA[c % 10]);
                }
            }
            if (best == 0) {
                return 0; // senza un seme niente primiera
            }
            total += best;
        }
        return total;
    }

    private static String sideName(Game g, int s) {
        return g.teams() ? g.players.get(s).nick + " e " + g.players.get(s + 2).nick : g.players.get(s).nick;
    }

    private static String winnerText(Game g, String unit) {
        Player best = null;
        boolean tie = false;
        for (Player p : g.players) {
            if (best == null || p.points > best.points) {
                best = p;
                tie = false;
            } else if (p.points == best.points) {
                tie = true;
            }
        }
        return best == null ? "" : tie ? "Pareggio con " + best.points + " " + unit + "!"
                : "Vince " + best.nick + " con " + best.points + " " + unit + "!";
    }

    static String name(int c) {
        int r = c % 10 + 1;
        String rank = r == 1 ? "Asso" : r == 8 ? "Fante" : r == 9 ? "Cavallo" : r == 10 ? "Re" : String.valueOf(r);
        return rank + " di " + SUITS[c / 10];
    }

    // ================================================================ vista per ogni giocatore

    /** Partita vista da un utente (JSON): le carte degli altri restano nascoste. */
    public synchronized String view(Game g, String me) {
        int mine = g.index(me);
        StringBuilder sb = new StringBuilder(512);
        sb.append('{');
        kv(sb, "id", g.id).append(',');
        kv(sb, "gid", g.gid).append(',');
        kv(sb, "type", g.type).append(',');
        kv(sb, "host", g.host).append(',');
        kv(sb, "phase", g.phase).append(',');
        sb.append("\"me\":").append(mine).append(',');
        sb.append("\"turn\":").append(g.phase.equals("play") ? g.turn : -1).append(',');
        sb.append("\"teams\":").append(g.teams()).append(',');
        sb.append("\"briscola\":").append(g.briscola).append(',');
        sb.append("\"deck\":").append(g.deck.size()).append(',');
        kv(sb, "msg", g.message).append(',');
        kv(sb, "result", g.result).append(',');
        sb.append("\"table\":").append(ints(g.table)).append(',');
        sb.append("\"trick\":[");
        for (int k = 0; k < g.trick.size(); k++) {
            sb.append(k > 0 ? "," : "").append("{\"p\":").append(g.trick.get(k)[0]).append(",\"c\":").append(g.trick.get(k)[1])
                    .append('}');
        }
        sb.append("],");
        boolean showAll = g.phase.equals("end");
        boolean seven = g.type.equals("settemezzo");
        // il banco di sette e mezzo: si vede la prima carta, tutte alla fine
        List<Integer> bank = showAll ? g.bank : g.bank.isEmpty() ? g.bank : g.bank.subList(0, 1);
        sb.append("\"bank\":").append(ints(bank)).append(',');
        sb.append("\"hand\":").append(mine >= 0 ? ints(g.players.get(mine).hand) : "[]").append(',');
        sb.append("\"players\":[");
        for (int k = 0; k < g.players.size(); k++) {
            Player p = g.players.get(k);
            sb.append(k > 0 ? "," : "").append('{');
            kv(sb, "n", p.nick).append(',');
            sb.append("\"acc\":").append(p.accepted).append(',');
            sb.append("\"cards\":").append(p.hand.size()).append(',');
            sb.append("\"pile\":").append(p.pile.size()).append(',');
            sb.append("\"top\":").append(p.pile.isEmpty() ? -1 : p.pile.get(p.pile.size() - 1)).append(',');
            sb.append("\"pts\":").append(g.type.equals("briscola") && !showAll && g.teams() ? -1 : p.points).append(',');
            sb.append("\"scope\":").append(p.scope).append(',');
            sb.append("\"stood\":").append(p.stood).append(',');
            sb.append("\"bust\":").append(p.bust).append(',');
            sb.append("\"left\":").append(p.left).append(',');
            // a sette e mezzo le carte si vedono quando il giocatore ha finito; alla fine si vede tutto
            boolean visible = showAll || (seven && (p.stood || k == mine));
            sb.append("\"shown\":").append(visible ? ints(p.hand) : "[]");
            sb.append('}');
        }
        sb.append("]}");
        return sb.toString();
    }

    public synchronized List<String> recipients(Game g) {
        List<String> out = new ArrayList<>();
        for (String m : Groups.getInstance().members(g.gid)) {
            out.add(m);
        }
        return out;
    }

    /** Partite di un gruppo ancora attive (per chi si collega dopo). */
    public synchronized List<Game> active(String gid) {
        List<Game> out = new ArrayList<>();
        for (Game g : games.values()) {
            if (g.gid.equals(gid) && !g.phase.equals("end")) {
                out.add(g);
            }
        }
        return out;
    }

    private static String ints(List<Integer> l) {
        StringBuilder sb = new StringBuilder("[");
        for (int k = 0; k < l.size(); k++) {
            sb.append(k > 0 ? "," : "").append(l.get(k));
        }
        return sb.append(']').toString();
    }

    private static StringBuilder kv(StringBuilder sb, String k, String v) {
        sb.append('"').append(k).append("\":\"");
        for (char c : (v == null ? "" : v).toCharArray()) {
            switch (c) {
                case '"':
                    sb.append("\\\"");
                    break;
                case '\\':
                    sb.append("\\\\");
                    break;
                case '\n':
                    sb.append("\\n");
                    break;
                case '|':
                    sb.append("\\u007c");
                    break;
                default:
                    if (c < 0x20) {
                        sb.append(String.format("\\u%04x", (int) c));
                    } else {
                        sb.append(c);
                    }
            }
        }
        return sb.append('"');
    }
}
