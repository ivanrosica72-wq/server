package ghostchat.server;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Date;
import java.util.Locale;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;

/**
 * Final: piccolo client SMTP (senza librerie esterne) per inviare i codici di
 * accesso e di verifica dell'email. Supporta STARTTLS (porta 587), SSL diretto
 * (porta 465) e AUTH LOGIN. Si configura in {@code ghostchat-server.properties}
 * (smtp.host, smtp.port, smtp.security, smtp.user, smtp.password, smtp.from).
 * <p>
 * Se smtp.host e' vuoto il codice viene solo scritto nella console del server
 * (comodo per le prove in classe o in rete locale).
 */
final class Mailer {

    private Mailer() {
    }

    static boolean configured() {
        return !ServerConfig.str("smtp.host").isEmpty();
    }

    /** Invia in un thread a parte; il risultato arriva a {@code done} (true = inviata). */
    static void sendAsync(String to, String subject, String body, java.util.function.Consumer<String> done) {
        Thread t = new Thread(() -> {
            String err = null;
            try {
                send(to, subject, body);
            } catch (Throwable e) {
                err = e.getMessage() == null ? e.toString() : e.getMessage();
                ServerLog.warn("Invio dell'email a " + to + " non riuscito: " + err);
            }
            done.accept(err);
        }, "mailer");
        t.setDaemon(true);
        t.start();
    }

    static void send(String to, String subject, String body) throws Exception {
        if (!configured()) {
            ServerLog.plain("");
            ServerLog.plain("   [EMAIL non configurata] per " + to + " -> " + subject);
            ServerLog.plain("   " + body.replace("\n", "\n   "));
            ServerLog.plain("");
            return;
        }
        String host = ServerConfig.str("smtp.host");
        int port = ServerConfig.integer("smtp.port", 587);
        String security = ServerConfig.str("smtp.security").toLowerCase(Locale.ROOT);
        String user = ServerConfig.str("smtp.user");
        String pass = ServerConfig.str("smtp.password");
        String from = ServerConfig.str("smtp.from").isEmpty() ? user : ServerConfig.str("smtp.from");

        Socket s;
        if (security.equals("ssl")) {
            s = SSLSocketFactory.getDefault().createSocket();
            s.connect(new InetSocketAddress(host, port), 15000);
        } else {
            s = new Socket();
            s.connect(new InetSocketAddress(host, port), 15000);
        }
        s.setSoTimeout(20000);
        try {
            Conn c = new Conn(s);
            c.expect(220);
            c.cmd("EHLO ghostchat", 250);
            if (security.equals("starttls")) {
                c.cmd("STARTTLS", 220);
                SSLSocket tls = (SSLSocket) ((SSLSocketFactory) SSLSocketFactory.getDefault())
                        .createSocket(s, host, port, true);
                tls.setUseClientMode(true);
                tls.startHandshake();
                s = tls;
                c = new Conn(tls);
                c.cmd("EHLO ghostchat", 250);
            }
            if (!user.isEmpty()) {
                c.cmd("AUTH LOGIN", 334);
                c.cmd(b64(user), 334);
                c.cmd(b64(pass), 235);
            }
            c.cmd("MAIL FROM:<" + address(from) + ">", 250);
            c.cmd("RCPT TO:<" + to + ">", 250, 251);
            c.cmd("DATA", 354);
            String date = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss Z", Locale.US).format(new Date());
            StringBuilder msg = new StringBuilder();
            msg.append("From: Ghost-chat <").append(address(from)).append(">\r\n");
            msg.append("To: <").append(to).append(">\r\n");
            msg.append("Subject: =?UTF-8?B?").append(b64(subject)).append("?=\r\n");
            msg.append("Date: ").append(date).append("\r\n");
            msg.append("MIME-Version: 1.0\r\n");
            msg.append("Content-Type: text/plain; charset=UTF-8\r\n");
            msg.append("Content-Transfer-Encoding: base64\r\n\r\n");
            String enc = Base64.getMimeEncoder().encodeToString(body.getBytes(StandardCharsets.UTF_8));
            msg.append(enc).append("\r\n.");
            c.cmd(msg.toString(), 250);
            c.cmd("QUIT", 221);
        } finally {
            try {
                s.close();
            } catch (Throwable ignored) {
                // niente
            }
        }
    }

    private static String address(String from) {
        int a = from.indexOf('<');
        int b = from.indexOf('>');
        return a >= 0 && b > a ? from.substring(a + 1, b) : from.trim();
    }

    private static String b64(String s) {
        return Base64.getEncoder().encodeToString(s.getBytes(StandardCharsets.UTF_8));
    }

    private static final class Conn {

        final BufferedReader in;
        final OutputStream out;

        Conn(Socket s) throws Exception {
            in = new BufferedReader(new InputStreamReader(s.getInputStream(), StandardCharsets.UTF_8));
            out = s.getOutputStream();
        }

        void cmd(String line, int... ok) throws Exception {
            out.write((line + "\r\n").getBytes(StandardCharsets.UTF_8));
            out.flush();
            expect(ok);
        }

        void expect(int... ok) throws Exception {
            String line;
            int code;
            do {
                line = in.readLine();
                if (line == null) {
                    throw new IllegalStateException("il server di posta ha chiuso la connessione");
                }
                code = line.length() >= 3 ? Integer.parseInt(line.substring(0, 3)) : -1;
            } while (line.length() > 3 && line.charAt(3) == '-');
            for (int o : ok) {
                if (o == code) {
                    return;
                }
            }
            throw new IllegalStateException("risposta SMTP inattesa: " + line);
        }
    }
}
