package ghostchat.server;

import java.util.List;

/**
 * Final (server online): comandi della rubrica.
 *
 * <pre>
 *  client -> server
 *    USEARCH|req|testo            cerca per nome utente
 *    CREQ|utente                  chiede di potervi scrivere
 *    CANSWER|utente|1/0           accetta / rifiuta la richiesta ricevuta
 *    CCANCEL|utente               ritira la richiesta inviata
 *    CREMOVE|utente               toglie il contatto (per entrambi)
 *  server -> client
 *    CONTACTS|a,b,c               tutti i contatti (all'accesso)
 *    USEARCHR|req|utente:stato:online;...   stato c/o/i/n, online 1/0
 *    CREQIN|utente                qualcuno vuole scriverti: va confermato
 *    CREQOUT|utente               richiesta inviata, in attesa
 *    CREQGONE|utente              richiesta ritirata/gestita (togliere dall'elenco)
 *    CREQNO|utente                l'altro ha rifiutato
 *    CONTACTADD|utente            nuovo contatto (richiesta accettata)
 *    CONTACTDEL|utente            contatto tolto
 *    CREQERR|utente|motivo
 * </pre>
 */
final class ContactFeatures {

    private ContactFeatures() {
    }

    static boolean handles(String cmd) {
        switch (cmd) {
            case "USEARCH":
            case "CREQ":
            case "CANSWER":
            case "CCANCEL":
            case "CREMOVE":
                return true;
            default:
                return false;
        }
    }

    /** Stato iniziale della rubrica, mandato subito dopo l'accesso. */
    static void sendInitial(ClientHandler h) {
        Contacts c = Contacts.getInstance();
        String me = h.getNickname();
        h.send("CONTACTS" + Protocol.SEP + String.join(",", c.contactsOf(me)));
        for (String from : c.incomingOf(me)) {
            h.send("CREQIN" + Protocol.SEP + from);
        }
        for (String to : c.outgoingOf(me)) {
            h.send("CREQOUT" + Protocol.SEP + to);
        }
    }

    static void handle(ClientHandler h, String cmd, String rest) {
        Contacts c = Contacts.getInstance();
        ClientRegistry reg = ClientRegistry.getInstance();
        String me = h.getNickname();
        String[] f = rest.split("\\|", -1);
        String other = f.length > 0 ? f[0].trim() : "";
        switch (cmd) {
            case "USEARCH": {
                String req = other;
                String q = f.length > 1 ? f[1] : "";
                StringBuilder sb = new StringBuilder("USEARCHR").append(Protocol.SEP).append(Protocol.clean(req)).append(Protocol.SEP);
                boolean first = true;
                for (String u : Contacts.search(q, me, 25)) {
                    if (!first) {
                        sb.append(';');
                    }
                    first = false;
                    ClientHandler on = reg.find(u);
                    boolean visible = on != null && !on.isHidden() && c.areContacts(me, u);
                    sb.append(u).append(':').append(c.state(me, u)).append(':').append(visible ? '1' : '0');
                }
                h.send(sb.toString());
                return;
            }
            case "CREQ": {
                String canon = Accounts.getInstance().canonical(other);
                String r = c.request(me, other);
                switch (r) {
                    case "sent":
                        ServerLog.info(me + " ha chiesto il contatto a " + canon);
                        h.send("CREQOUT" + Protocol.SEP + canon);
                        reg.sendTo(java.util.Collections.singletonList(canon), "CREQIN" + Protocol.SEP + me, null);
                        return;
                    case "accepted":
                        linked(me, canon);
                        return;
                    case "already":
                        h.send("CONTACTADD" + Protocol.SEP + canon);
                        return;
                    default:
                        h.send("CREQERR" + Protocol.SEP + Protocol.clean(other) + Protocol.SEP + r);
                }
                return;
            }
            case "CANSWER": {
                String canon = Accounts.getInstance().canonical(other);
                boolean accept = f.length > 1 && f[1].trim().equals("1");
                if (canon == null || !c.answer(me, canon, accept)) {
                    h.send("CREQGONE" + Protocol.SEP + Protocol.clean(other));
                    return;
                }
                if (accept) {
                    linked(me, canon);
                } else {
                    ServerLog.info(me + " ha rifiutato la richiesta di " + canon);
                    h.send("CREQGONE" + Protocol.SEP + canon);
                    reg.sendTo(java.util.Collections.singletonList(canon), "CREQNO" + Protocol.SEP + me, null);
                }
                return;
            }
            case "CCANCEL": {
                String canon = Accounts.getInstance().canonical(other);
                if (canon != null && c.cancel(me, canon)) {
                    reg.sendTo(java.util.Collections.singletonList(canon), "CREQGONE" + Protocol.SEP + me, null);
                }
                h.send("CREQGONE" + Protocol.SEP + (canon == null ? Protocol.clean(other) : canon));
                return;
            }
            case "CREMOVE": {
                String canon = Accounts.getInstance().canonical(other);
                if (canon != null && c.remove(me, canon)) {
                    ServerLog.info(me + " ha tolto " + canon + " dai contatti");
                    h.send("CONTACTDEL" + Protocol.SEP + canon);
                    reg.sendTo(java.util.Collections.singletonList(canon), "CONTACTDEL" + Protocol.SEP + me, null);
                    reg.broadcastUserList();
                }
                return;
            }
            default:
        }
    }

    /** a e b sono diventati contatti: lo sanno entrambi e vedono lo stato online dell'altro. */
    private static void linked(String a, String b) {
        ClientRegistry reg = ClientRegistry.getInstance();
        ServerLog.info(a + " e " + b + " ora sono contatti");
        for (String[] p : new String[][]{{a, b}, {b, a}}) {
            ClientHandler h = reg.find(p[0]);
            if (h != null) {
                h.send("CREQGONE" + Protocol.SEP + p[1]);
                h.send("CONTACTADD" + Protocol.SEP + p[1]);
                ClientHandler o = reg.find(p[1]);
                String av = o == null ? null : o.getAvatar();
                if (av != null && !av.isEmpty()) {
                    h.send(Protocol.AVATAR + Protocol.SEP + p[1] + Protocol.SEP + av);
                }
            }
        }
        reg.broadcastUserList();
    }

    /** Contatti di {@code me} piu' lui stesso: a chi mandare foto profilo e stati. */
    static List<String> audience(String me) {
        List<String> l = Contacts.getInstance().contactsOf(me);
        l.add(me);
        return l;
    }
}
