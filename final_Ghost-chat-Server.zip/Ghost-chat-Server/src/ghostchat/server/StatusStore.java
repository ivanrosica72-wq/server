package ghostchat.server;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.zip.CRC32;

/**
 * Stati in stile WhatsApp (v4): testo, foto, GIF o brevi video che restano
 * visibili 24 ore. Sono tenuti SOLO in memoria (mai su disco) e spariscono
 * dopo 24 ore, quando l'autore li elimina o quando il server si spegne.
 * Per ogni stato si ricorda chi l'ha visto, per mostrarlo all'autore.
 */
public final class StatusStore {

    public static final long LIFETIME_MS = 24L * 60 * 60 * 1000;
    public static final long MAX_IMAGE = 8L * 1024 * 1024;
    public static final long MAX_VIDEO = 16L * 1024 * 1024;
    public static final int MAX_PER_USER = 10;
    /** Memoria massima occupata da tutti gli stati. */
    public static final long MAX_TOTAL = 400L * 1024 * 1024;
    public static final int MAX_TEXT = 700;
    public static final int MAX_META = 200;

    private static final StatusStore INSTANCE = new StatusStore();

    public static final class Status {

        final String owner;
        final String id;
        final char kind; // T testo, I foto, G gif, V video
        final long time;
        final String meta;
        final String text;
        final long size;
        byte[] data; // null per gli stati di testo
        /** chi l'ha visto -> quando */
        final Map<String, Long> viewers = new LinkedHashMap<>();

        Status(String owner, String id, char kind, long time, long size, String meta, String text) {
            this.owner = owner;
            this.id = id;
            this.kind = kind;
            this.time = time;
            this.size = size;
            this.meta = meta;
            this.text = text;
        }

        /** STATUS|autore|id|tipo|ora|byte|meta|testo */
        String describe() {
            return "STATUS" + Protocol.SEP + owner + Protocol.SEP + id + Protocol.SEP + kind + Protocol.SEP + time
                    + Protocol.SEP + size + Protocol.SEP + meta + Protocol.SEP + text;
        }
    }

    /** Stato in caricamento (in attesa dei pezzi). */
    private static final class Upload {

        final Status status;
        final java.io.ByteArrayOutputStream buf;

        Upload(Status status) {
            this.status = status;
            this.buf = new java.io.ByteArrayOutputStream((int) Math.min(status.size, 1 << 20));
        }
    }

    /** chiave: autore in minuscolo + "\n" + id */
    private final Map<String, Status> statuses = new LinkedHashMap<>();
    private final Map<String, Upload> uploads = new LinkedHashMap<>();
    private long totalBytes;

    private StatusStore() {
    }

    public static StatusStore getInstance() {
        return INSTANCE;
    }

    private static String key(String owner, String id) {
        return owner.toLowerCase(Locale.ROOT) + "\n" + id;
    }

    public static boolean validId(String id) {
        return id != null && id.matches("[A-Za-z0-9]{4,32}");
    }

    private int countOf(String owner) {
        int n = 0;
        for (Status s : statuses.values()) {
            if (s.owner.equalsIgnoreCase(owner)) {
                n++;
            }
        }
        for (Upload u : uploads.values()) {
            if (u.status.owner.equalsIgnoreCase(owner)) {
                n++;
            }
        }
        return n;
    }

    /**
     * Inizia la pubblicazione di uno stato.
     *
     * @return null se ok (per il testo lo stato e' gia' pubblicato), altrimenti l'errore
     */
    public synchronized String begin(String owner, String id, char kind, long size, String meta, String text) {
        if (!validId(id)) {
            return "Stato non valido";
        }
        if (statuses.containsKey(key(owner, id)) || uploads.containsKey(key(owner, id))) {
            return "Stato già pubblicato";
        }
        if (countOf(owner) >= MAX_PER_USER) {
            return "Puoi avere al massimo " + MAX_PER_USER + " stati attivi";
        }
        String m = Protocol.clean(meta == null ? "" : meta);
        String t = Protocol.clean(text == null ? "" : text);
        if (m.length() > MAX_META || t.length() > MAX_TEXT * 2) {
            return "Testo dello stato troppo lungo";
        }
        switch (kind) {
            case 'T':
                if (t.trim().isEmpty()) {
                    return "Lo stato di testo è vuoto";
                }
                statuses.put(key(owner, id), new Status(owner, id, kind, System.currentTimeMillis(), 0, m, t));
                return null;
            case 'I':
            case 'G':
            case 'V': {
                long max = kind == 'V' ? MAX_VIDEO : MAX_IMAGE;
                if (size <= 0 || size > max) {
                    return "File dello stato troppo grande (massimo " + (max / (1024 * 1024)) + " MB)";
                }
                if (totalBytes + size > MAX_TOTAL) {
                    return "Il server non ha più spazio per gli stati: riprova più tardi";
                }
                totalBytes += size;
                uploads.put(key(owner, id), new Upload(new Status(owner, id, kind, 0, size, m, t)));
                return null;
            }
            default:
                return "Tipo di stato non valido";
        }
    }

    /** @return false se il caricamento non esiste o i dati sono troppi */
    public synchronized boolean chunk(String owner, String id, byte[] data) {
        Upload u = uploads.get(key(owner, id));
        if (u == null) {
            return false;
        }
        if (u.buf.size() + data.length > u.status.size) {
            abort(owner, id);
            return false;
        }
        u.buf.write(data, 0, data.length);
        return true;
    }

    /**
     * Fine del caricamento: controllo di integrita' e pubblicazione.
     *
     * @return lo stato pubblicato, oppure null se i dati non sono corretti
     */
    public synchronized Status finish(String owner, String id, String crcHex) {
        Upload u = uploads.remove(key(owner, id));
        if (u == null) {
            return null;
        }
        byte[] data = u.buf.toByteArray();
        CRC32 crc = new CRC32();
        crc.update(data, 0, data.length);
        long expected;
        try {
            expected = Long.parseLong(crcHex.trim(), 16);
        } catch (NumberFormatException e) {
            expected = -1;
        }
        if (data.length != u.status.size || crc.getValue() != expected) {
            totalBytes -= u.status.size;
            return null;
        }
        Status s = new Status(owner, id, u.status.kind, System.currentTimeMillis(), data.length, u.status.meta,
                u.status.text);
        s.data = data;
        statuses.put(key(owner, id), s);
        return s;
    }

    public synchronized void abort(String owner, String id) {
        Upload u = uploads.remove(key(owner, id));
        if (u != null) {
            totalBytes -= u.status.size;
        }
    }

    /** Un utente si e' disconnesso: i suoi caricamenti a meta' vengono scartati. */
    public synchronized void abortAll(String owner) {
        Iterator<Map.Entry<String, Upload>> it = uploads.entrySet().iterator();
        while (it.hasNext()) {
            Upload u = it.next().getValue();
            if (u.status.owner.equalsIgnoreCase(owner)) {
                totalBytes -= u.status.size;
                it.remove();
            }
        }
    }

    public synchronized Status get(String owner, String id) {
        return statuses.get(key(owner, id));
    }

    /** @return true se lo stato esisteva ed e' stato eliminato */
    public synchronized boolean delete(String owner, String id) {
        Status s = statuses.remove(key(owner, id));
        if (s != null && s.data != null) {
            totalBytes -= s.size;
        }
        return s != null;
    }

    /** @return l'ora in cui e' stato visto (0 = stato inesistente) */
    public synchronized long seen(String owner, String id, String viewer) {
        Status s = statuses.get(key(owner, id));
        if (s == null || s.owner.equalsIgnoreCase(viewer)) {
            return 0;
        }
        Long t = s.viewers.get(viewer);
        if (t == null) {
            t = System.currentTimeMillis();
            s.viewers.put(viewer, t);
        }
        return t;
    }

    public synchronized List<Status> all() {
        return new ArrayList<>(statuses.values());
    }

    /** Visualizzazioni degli stati di un utente: righe SSEEN|chi|idStato|ora. */
    public synchronized List<String> viewsOf(String owner) {
        List<String> out = new ArrayList<>();
        for (Status s : statuses.values()) {
            if (s.owner.equalsIgnoreCase(owner)) {
                for (Map.Entry<String, Long> v : s.viewers.entrySet()) {
                    out.add("SSEEN" + Protocol.SEP + v.getKey() + Protocol.SEP + s.id + Protocol.SEP + v.getValue());
                }
            }
        }
        return out;
    }

    /** Toglie gli stati piu' vecchi di 24 ore. @return quelli scaduti */
    public synchronized List<Status> expire() {
        List<Status> gone = new ArrayList<>();
        long limit = System.currentTimeMillis() - LIFETIME_MS;
        Iterator<Map.Entry<String, Status>> it = statuses.entrySet().iterator();
        while (it.hasNext()) {
            Status s = it.next().getValue();
            if (s.time < limit) {
                if (s.data != null) {
                    totalBytes -= s.size;
                }
                gone.add(s);
                it.remove();
            }
        }
        return gone;
    }

    public synchronized int size() {
        return statuses.size();
    }
}
