package ghostchat.server;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * Gruppi di chat (v4), tenuti SOLO in memoria: esistono finche' il server e'
 * acceso. Il server conosce solo nome, foto, amministratore e membri del
 * gruppo; i messaggi vengono inoltrati ai membri online e non salvati.
 * <p>
 * Ogni gruppo puo' avere una chiamata (vocale o video) in corso, con
 * l'elenco dei partecipanti: audio e video vengono inoltrati solo a loro.
 * Tutti i metodi sono synchronized: i gruppi sono condivisi tra i thread.
 */
public final class Groups {

    public static final int MAX_MEMBERS = 32;
    public static final int MAX_CALL_PARTICIPANTS = 8;
    public static final int MAX_NAME = 40;
    public static final int MAX_PHOTO_CHARS = 96 * 1024;
    public static final int MAX_GROUPS = 2000;

    private static final Groups INSTANCE = new Groups();

    /** Un gruppo. I nickname sono salvati come scritti, confrontati senza maiuscole. */
    public static final class Group {

        final String id;
        String name;
        /** v5: piu' amministratori */
        final Set<String> admins = new LinkedHashSet<>();
        final List<String> members = new ArrayList<>();
        String description = "";
        boolean onlyAdmins;
        String invite;
        String photo = "";
        /** chiamata in corso (null = nessuna) */
        String callId;
        boolean callVideo;
        final Set<String> participants = new LinkedHashSet<>();
        /** final: inviti in attesa di consenso (nickname -> chi ha invitato) */
        final Map<String, String> pending = new LinkedHashMap<>();

        Group(String id) {
            this.id = id;
        }

        boolean isMember(String nick) {
            return indexOf(nick) >= 0;
        }

        int indexOf(String nick) {
            for (int i = 0; i < members.size(); i++) {
                if (members.get(i).equalsIgnoreCase(nick)) {
                    return i;
                }
            }
            return -1;
        }

        boolean isParticipant(String nick) {
            for (String p : participants) {
                if (p.equalsIgnoreCase(nick)) {
                    return true;
                }
            }
            return false;
        }

        void removeParticipant(String nick) {
            participants.removeIf(p -> p.equalsIgnoreCase(nick));
            if (participants.isEmpty()) {
                callId = null;
            }
        }

        /** GROUP|id|nome|admin|m1,m2,... */
        boolean isAdmin(String nick) {
            for (String a : admins) {
                if (a.equalsIgnoreCase(nick)) {
                    return true;
                }
            }
            return false;
        }

        /** GROUP|id|nome|admin1,admin2|membri|descrizione|flag (v5: flag "a" = scrivono solo gli admin) */
        String describe() {
            return "GROUP" + Protocol.SEP + id + Protocol.SEP + name + Protocol.SEP + String.join(",", admins)
                    + Protocol.SEP + String.join(",", members) + Protocol.SEP + description.replace("\\", "\\\\")
                    .replace("|", "\\p").replace("\n", "\\n") + Protocol.SEP + (onlyAdmins ? "a" : "") + Protocol.SEP + String.join(",", pending.keySet());
        }

        /** GCALL|id|idChiamata|A/V|p1,p2 (idChiamata vuoto = nessuna chiamata) */
        String describeCall() {
            return "GCALL" + Protocol.SEP + id + Protocol.SEP + (callId == null ? "" : callId) + Protocol.SEP
                    + (callVideo ? "V" : "A") + Protocol.SEP + String.join(",", participants);
        }
    }

    private final Map<String, Group> groups = new LinkedHashMap<>();

    private Groups() {
    }

    public static Groups getInstance() {
        return INSTANCE;
    }

    /** Id valido: lettere minuscole e cifre, da 6 a 24 caratteri. */
    public static boolean validId(String id) {
        return id != null && id.matches("[a-z0-9]{6,24}");
    }

    /** Nome del gruppo ripulito, oppure null se non valido. */
    public static String cleanName(String name) {
        if (name == null) {
            return null;
        }
        String n = Protocol.clean(name).replace("|", " ").trim();
        if (n.isEmpty()) {
            return null;
        }
        return n.length() > MAX_NAME ? n.substring(0, MAX_NAME).trim() : n;
    }

    public synchronized Group get(String id) {
        return groups.get(id);
    }

    /** @return descrizione dell'errore oppure null se creato */
    public synchronized String create(String id, String name, String admin, List<String> others) {
        if (!validId(id)) {
            return "Id del gruppo non valido";
        }
        if (groups.containsKey(id)) {
            return "Gruppo già esistente";
        }
        if (groups.size() >= MAX_GROUPS) {
            return "Troppi gruppi sul server";
        }
        String n = cleanName(name);
        if (n == null) {
            return "Il gruppo deve avere un nome";
        }
        Group g = new Group(id);
        g.name = n;
        g.admins.add(admin);
        g.members.add(admin);
        for (String o : others) {
            String m = o.trim();
            if (m.isEmpty() || Protocol.validateNickname(m) != null || g.isMember(m) || hasPending(g, m)) {
                continue;
            }
            if (g.members.size() + g.pending.size() >= MAX_MEMBERS) {
                break;
            }
            // final: nessuno entra in un gruppo senza dare il consenso
            g.pending.put(m, admin);
        }
        if (g.pending.isEmpty()) {
            return "Aggiungi almeno un altro partecipante";
        }
        groups.put(id, g);
        return null;
    }

    /** Gruppi di cui fa parte un utente (copie delle descrizioni). */
    public synchronized List<Group> groupsOf(String nick) {
        List<Group> out = new ArrayList<>();
        for (Group g : groups.values()) {
            if (g.isMember(nick)) {
                out.add(g);
            }
        }
        return out;
    }

    public synchronized List<String> members(String id) {
        Group g = groups.get(id);
        return g == null ? new ArrayList<>() : new ArrayList<>(g.members);
    }

    public synchronized List<String> participants(String id) {
        Group g = groups.get(id);
        return g == null ? new ArrayList<>() : new ArrayList<>(g.participants);
    }

    public synchronized boolean isMember(String id, String nick) {
        Group g = groups.get(id);
        return g != null && g.isMember(nick);
    }

    public synchronized boolean isParticipant(String id, String nick) {
        Group g = groups.get(id);
        return g != null && g.isParticipant(nick);
    }

    public synchronized boolean isAdmin(String id, String nick) {
        Group g = groups.get(id);
        return g != null && g.isAdmin(nick);
    }

    // ================================================================ v5: admin, descrizione, permessi, inviti

    public static final int MAX_DESCRIPTION = 400;
    private final Map<String, String> invites = new LinkedHashMap<>();
    private final java.security.SecureRandom random = new java.security.SecureRandom();

    /** Promuove o toglie un amministratore (deve restarne almeno uno). */
    public synchronized String setAdmin(String id, String nick, boolean admin) {
        Group g = groups.get(id);
        if (g == null || !g.isMember(nick)) {
            return "Non fa parte del gruppo";
        }
        String real = g.members.get(g.indexOf(nick));
        if (admin) {
            g.admins.add(real);
            return null;
        }
        if (g.admins.size() <= 1 && g.isAdmin(nick)) {
            return "Il gruppo deve avere almeno un amministratore";
        }
        g.admins.removeIf(a -> a.equalsIgnoreCase(nick));
        return null;
    }

    public synchronized boolean setDescription(String id, String text) {
        Group g = groups.get(id);
        if (g == null) {
            return false;
        }
        String t = text == null ? "" : text.replace("\r", "").trim();
        g.description = t.length() > MAX_DESCRIPTION ? t.substring(0, MAX_DESCRIPTION) : t;
        return true;
    }

    public synchronized void setOnlyAdmins(String id, boolean only) {
        Group g = groups.get(id);
        if (g != null) {
            g.onlyAdmins = only;
        }
    }

    public synchronized boolean onlyAdmins(String id) {
        Group g = groups.get(id);
        return g != null && g.onlyAdmins;
    }

    /** Codice d'invito del gruppo (crea quello nuovo se "fresh" o se non c'e'). */
    public synchronized String invite(String id, boolean fresh) {
        Group g = groups.get(id);
        if (g == null) {
            return null;
        }
        if (g.invite != null && !fresh) {
            return g.invite;
        }
        if (g.invite != null) {
            invites.remove(g.invite);
        }
        String alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
        String code;
        do {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < 8; i++) {
                sb.append(alphabet.charAt(random.nextInt(alphabet.length())));
            }
            code = sb.toString();
        } while (invites.containsKey(code));
        g.invite = code;
        invites.put(code, id);
        return code;
    }

    public synchronized void revokeInvite(String id) {
        Group g = groups.get(id);
        if (g != null && g.invite != null) {
            invites.remove(g.invite);
            g.invite = null;
        }
    }

    /** Entra con un codice: restituisce l'id del gruppo, oppure un messaggio d'errore che inizia con "!". */
    public synchronized String join(String code, String nick) {
        String c = code == null ? "" : code.trim().toUpperCase(Locale.ROOT);
        int slash = c.lastIndexOf('/');
        if (slash >= 0) {
            c = c.substring(slash + 1);
        }
        String id = invites.get(c);
        Group g = id == null ? null : groups.get(id);
        if (g == null) {
            return "!Codice d'invito non valido o revocato";
        }
        if (g.isMember(nick)) {
            return "!Fai già parte di questo gruppo";
        }
        if (g.members.size() >= MAX_MEMBERS) {
            return "!Il gruppo è pieno";
        }
        g.members.add(nick);
        return id;
    }

    // ================================================================ final: consenso agli inviti

    private static boolean hasPending(Group g, String nick) {
        for (String p : g.pending.keySet()) {
            if (p.equalsIgnoreCase(nick)) {
                return true;
            }
        }
        return false;
    }

    private static String pendingKey(Group g, String nick) {
        for (String p : g.pending.keySet()) {
            if (p.equalsIgnoreCase(nick)) {
                return p;
            }
        }
        return null;
    }

    /** Invita (senza aggiungere): @return i nickname davvero invitati */
    public synchronized List<String> invitePeople(String id, List<String> nicks, String by) {
        List<String> out = new ArrayList<>();
        Group g = groups.get(id);
        if (g == null) {
            return out;
        }
        for (String n : nicks) {
            String m = n.trim();
            if (m.isEmpty() || Protocol.validateNickname(m) != null || g.isMember(m) || hasPending(g, m)
                    || g.members.size() + g.pending.size() >= MAX_MEMBERS) {
                continue;
            }
            g.pending.put(m, by);
            out.add(m);
        }
        return out;
    }

    /**
     * Risposta a un invito. @return "ok", "no" oppure "!motivo"
     */
    public synchronized String answer(String id, String nick, boolean accept) {
        Group g = groups.get(id);
        String k = g == null ? null : pendingKey(g, nick);
        if (k == null) {
            return "!L'invito non è più valido";
        }
        g.pending.remove(k);
        if (!accept) {
            return "no";
        }
        if (g.members.size() >= MAX_MEMBERS) {
            return "!Il gruppo è pieno";
        }
        g.members.add(k);
        return "ok";
    }

    /** Inviti in attesa per un utente: righe GINVREQ|gid|nome|daChi|membri */
    public synchronized List<String> pendingFor(String nick) {
        List<String> out = new ArrayList<>();
        for (Group g : groups.values()) {
            String k = pendingKey(g, nick);
            if (k != null) {
                out.add("GINVREQ" + Protocol.SEP + g.id + Protocol.SEP + g.name + Protocol.SEP + g.pending.get(k)
                        + Protocol.SEP + g.members.size());
            }
        }
        return out;
    }

    public synchronized String inviteLine(String id, String nick) {
        Group g = groups.get(id);
        String k = g == null ? null : pendingKey(g, nick);
        return k == null ? null : "GINVREQ" + Protocol.SEP + g.id + Protocol.SEP + g.name + Protocol.SEP + g.pending.get(k)
                + Protocol.SEP + g.members.size();
    }

    /** L'amministratore annulla un invito. */
    public synchronized boolean cancelInvite(String id, String nick) {
        Group g = groups.get(id);
        String k = g == null ? null : pendingKey(g, nick);
        return k != null && g.pending.remove(k) != null;
    }

    /** @return i nickname davvero aggiunti */
    public synchronized List<String> add(String id, List<String> nicks) {
        List<String> added = new ArrayList<>();
        Group g = groups.get(id);
        if (g == null) {
            return added;
        }
        for (String n : nicks) {
            String m = n.trim();
            if (m.isEmpty() || Protocol.validateNickname(m) != null || g.isMember(m) || g.members.size() >= MAX_MEMBERS) {
                continue;
            }
            g.members.add(m);
            added.add(m);
        }
        return added;
    }

    /**
     * Toglie un membro (rimosso o uscito). Se era l'amministratore, lo diventa il primo rimasto.
     *
     * @return true se il gruppo esiste ancora
     */
    public synchronized boolean remove(String id, String nick) {
        Group g = groups.get(id);
        if (g == null) {
            return false;
        }
        int i = g.indexOf(nick);
        if (i >= 0) {
            g.members.remove(i);
        }
        g.removeParticipant(nick);
        g.admins.removeIf(a -> a.equalsIgnoreCase(nick));
        if (g.members.isEmpty()) {
            if (g.invite != null) {
                invites.remove(g.invite);
            }
            groups.remove(id);
            return false;
        }
        if (g.admins.isEmpty()) {
            g.admins.add(g.members.get(0));
        }
        return true;
    }

    public synchronized boolean rename(String id, String name) {
        Group g = groups.get(id);
        String n = cleanName(name);
        if (g == null || n == null) {
            return false;
        }
        g.name = n;
        return true;
    }

    public synchronized void setPhoto(String id, String b64) {
        Group g = groups.get(id);
        if (g != null) {
            g.photo = b64 == null ? "" : b64;
        }
    }

    public synchronized String photo(String id) {
        Group g = groups.get(id);
        return g == null ? "" : g.photo;
    }

    public synchronized String describe(String id) {
        Group g = groups.get(id);
        return g == null ? null : g.describe();
    }

    public synchronized String describeCall(String id) {
        Group g = groups.get(id);
        return g == null ? null : g.describeCall();
    }

    public synchronized String name(String id) {
        Group g = groups.get(id);
        return g == null ? id : g.name;
    }

    // ================================================================ chiamate di gruppo

    /**
     * Avvia la chiamata del gruppo, oppure fa entrare nella chiamata gia' in corso.
     *
     * @return null se ok, altrimenti l'errore
     */
    public synchronized String startOrJoin(String id, String callId, boolean video, String nick) {
        Group g = groups.get(id);
        if (g == null || !g.isMember(nick)) {
            return "Non fai parte di questo gruppo";
        }
        if (g.callId == null) {
            g.callId = callId;
            g.callVideo = video;
            g.participants.clear();
        } else if (!g.callId.equals(callId)) {
            return "C'è già un'altra chiamata in corso nel gruppo";
        }
        if (!g.isParticipant(nick)) {
            if (g.participants.size() >= MAX_CALL_PARTICIPANTS) {
                return "Chiamata piena (massimo " + MAX_CALL_PARTICIPANTS + " persone)";
            }
            g.participants.add(nick);
        }
        return null;
    }

    /** Esce dalla chiamata del gruppo. @return true se qualcosa e' cambiato */
    public synchronized boolean leaveCall(String id, String callId, String nick) {
        Group g = groups.get(id);
        if (g == null || g.callId == null || (callId != null && !g.callId.equals(callId)) || !g.isParticipant(nick)) {
            return false;
        }
        g.removeParticipant(nick);
        return true;
    }

    /** Un utente si e' disconnesso: esce da tutte le chiamate. @return gli id dei gruppi coinvolti */
    public synchronized List<String> leaveAllCalls(String nick) {
        List<String> changed = new ArrayList<>();
        for (Group g : groups.values()) {
            if (g.isParticipant(nick)) {
                g.removeParticipant(nick);
                changed.add(g.id);
            }
        }
        return changed;
    }

    public synchronized String callId(String id) {
        Group g = groups.get(id);
        return g == null ? null : g.callId;
    }

    public synchronized int size() {
        return groups.size();
    }

    static String key(String nick) {
        return nick.toLowerCase(Locale.ROOT);
    }
}
