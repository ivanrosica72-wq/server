package ghostchat.server;

import java.io.IOException;
import java.net.BindException;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * RT-04: classe principale del server Ghost-chat.
 * <p>
 * Apre la ServerSocket, accetta le connessioni in un ciclo continuo (RS-01)
 * e per ognuna avvia {@code new Thread(new ClientHandler(socket))} (RS-02).
 * Nessuna interfaccia grafica: tutto il log va in console (RT-02).
 * <p>
 * Avvio: {@code java -jar Ghost-chat-Server.jar [porta]} (default 5000).
 * In NetBeans la porta si cambia da Proprieta' progetto &gt; Run &gt; Arguments.
 */
public class GhostChatServer {

    private static volatile boolean running = true;
    private static volatile ServerSocket serverSocket;

    public static void main(String[] args) {
        // final: accenti ed emoji corretti anche nella console del pannello di hosting
        try {
            System.setOut(new java.io.PrintStream(new java.io.FileOutputStream(java.io.FileDescriptor.out), true, "UTF-8"));
            System.setErr(new java.io.PrintStream(new java.io.FileOutputStream(java.io.FileDescriptor.err), true, "UTF-8"));
        } catch (Exception ignored) {
            // codifica di sistema
        }
        // nessun errore, in nessun thread, deve chiudere il server
        Thread.setDefaultUncaughtExceptionHandler((thread, error)
                -> ServerLog.error("Errore imprevisto nel thread " + thread.getName()
                        + " (il server continua a funzionare)", error));

        // final: configurazione, account e InstaGhost (salvati nella cartella dei dati)
        ServerConfig.load();
        // final: sull'hosting (Wispbyte/Pterodactyl) la porta assegnata arriva in SERVER_PORT
        String envPort = System.getenv("SERVER_PORT");
        int port = args != null && args.length > 0 ? parsePort(args)
                : envPort != null && envPort.trim().matches("\\d{1,5}") ? Integer.parseInt(envPort.trim())
                : ServerConfig.integer("port", Protocol.DEFAULT_PORT);
        printBanner(port);
        try {
            Accounts.getInstance().load();
            Contacts.getInstance().load();
            InstaGhost.getInstance().load();
        } catch (Throwable t) {
            ServerLog.error("Caricamento dei dati non riuscito", t);
        }
        if (!Mailer.configured()) {
            ServerLog.info("Email non configurata: i codici di accesso verranno scritti qui in console"
                    + " (imposta smtp.* in ghostchat-server.properties)");
        }
        try {
            NetGateways.startAll(port);
        } catch (Throwable t) {
            ServerLog.warn("Accesso da Internet non disponibile: " + t.getMessage());
        }

        try {
            Runtime.getRuntime().addShutdownHook(new Thread(GhostChatServer::shutdownNow, "shutdown"));
        } catch (Throwable t) {
            ServerLog.warn("Impossibile registrare la chiusura ordinata: " + t.getMessage());
        }

        try {
            Thread console = new Thread(new ConsoleCommands(), "console");
            console.setDaemon(true);
            console.start();
        } catch (Throwable t) {
            ServerLog.warn("Comandi da console non disponibili: " + t.getMessage());
        }

        // v4: i client trovano il server da soli nella rete locale (UDP broadcast)
        try {
            if (!ServerConfig.bool("discovery.enabled")) {
                throw new IllegalStateException("spento (server online: discovery.enabled=false)");
            }
            Thread discovery = new Thread(new Discovery(port), "discovery");
            discovery.setDaemon(true);
            discovery.start();
        } catch (Throwable t) {
            ServerLog.info("Ritrovamento automatico nella rete locale: " + t.getMessage());
        }

        // v4: gli stati spariscono dopo 24 ore
        try {
            Thread expiry = new Thread(() -> {
                while (true) {
                    try {
                        Thread.sleep(60_000);
                        for (StatusStore.Status st : StatusStore.getInstance().expire()) {
                            ClientRegistry.getInstance().broadcast(Protocol.SGONE + Protocol.SEP + st.owner
                                    + Protocol.SEP + st.id, null);
                        }
                    } catch (InterruptedException e) {
                        return;
                    } catch (Throwable t) {
                        ServerLog.error("Pulizia degli stati non riuscita", t);
                    }
                }
            }, "status-expiry");
            expiry.setDaemon(true);
            expiry.start();
        } catch (Throwable t) {
            ServerLog.warn("Scadenza automatica degli stati non disponibile: " + t.getMessage());
        }

        // RS-01: il server deve essere SEMPRE pronto. Se la ServerSocket non si
        // puo' aprire o si rompe, si riprova invece di terminare.
        while (running) {
            try {
                listen(port);
            } catch (BindException e) {
                ServerLog.error("La porta " + port + " e' gia' in uso (forse il server e' gia' avviato?)."
                        + " Nuovo tentativo tra 5 secondi", null);
                sleep(5000);
            } catch (IOException e) {
                if (running) {
                    ServerLog.error("Errore della ServerSocket. Riavvio dell'ascolto tra 3 secondi", e);
                    sleep(3000);
                }
            } catch (Throwable t) {
                if (running) {
                    ServerLog.error("Errore imprevisto nel ciclo principale. Riavvio dell'ascolto tra 3 secondi", t);
                    sleep(3000);
                }
            }
        }
        ServerLog.info("Server arrestato.");
    }

    /** Apre la ServerSocket e accetta connessioni finche' funziona. */
    private static void listen(int port) throws IOException {
        try (ServerSocket ss = new ServerSocket()) {
            ss.setReuseAddress(true);
            ss.bind(new InetSocketAddress(port));
            serverSocket = ss;
            ServerLog.info("Server in ascolto sulla porta " + port + ". In attesa di client...");

            while (running) {
                Socket socket;
                try {
                    socket = ss.accept();
                } catch (SocketException e) {
                    if (!running) {
                        return;
                    }
                    if (ss.isClosed()) {
                        throw e; // la ServerSocket e' morta: il chiamante la riapre
                    }
                    ServerLog.warn("Connessione in ingresso non riuscita: " + e.getMessage());
                    continue;
                } catch (IOException e) {
                    ServerLog.warn("Connessione in ingresso non riuscita: " + e.getMessage());
                    continue;
                }
                // final: porta unica (protocollo, TLS e WebSocket sulla stessa porta)
                if (ServerConfig.bool("mux.enabled")) {
                    NetGateways.dispatch(socket);
                } else {
                    startHandler(socket);
                }
            }
        } finally {
            serverSocket = null;
        }
    }

    /** Final: usato anche dalla porta cifrata (TLS). */
    static void startHandlerPublic(Socket socket) {
        startHandler(socket);
    }

    /** RS-02 / RT-04: un nuovo Thread con un nuovo ClientHandler per ogni connessione. */
    private static void startHandler(Socket socket) {
        try {
            Thread t = new Thread(new ClientHandler(socket));
            t.setName("ClientHandler-" + socket.getInetAddress().getHostAddress() + ":" + socket.getPort());
            t.setDaemon(true);
            t.start();
        } catch (Throwable t) {
            // es. OutOfMemoryError "unable to create native thread": si rifiuta solo questo client
            ServerLog.error("Impossibile avviare il thread per un nuovo client", t);
            try {
                socket.close();
            } catch (Throwable ignored) {
                // niente da fare
            }
        }
    }

    /** Arresto ordinato: avvisa i client e chiude tutto. */
    static void shutdownNow() {
        if (!running) {
            return;
        }
        running = false;
        ServerLog.info("Arresto del server in corso...");
        try {
            ClientRegistry.getInstance().closeAll("Il server è stato arrestato");
        } catch (Throwable ignored) {
            // in chiusura si ignora tutto
        }
        ServerSocket ss = serverSocket;
        if (ss != null) {
            try {
                ss.close();
            } catch (Throwable ignored) {
                // gia' chiusa
            }
        }
    }

    private static int parsePort(String[] args) {
        if (args == null || args.length == 0 || args[0] == null || args[0].trim().isEmpty()) {
            return Protocol.DEFAULT_PORT;
        }
        try {
            int p = Integer.parseInt(args[0].trim());
            if (p >= 1 && p <= 65535) {
                return p;
            }
            ServerLog.warn("Porta \"" + args[0] + "\" fuori intervallo (1-65535): uso " + Protocol.DEFAULT_PORT);
        } catch (NumberFormatException e) {
            ServerLog.warn("Porta \"" + args[0] + "\" non valida: uso " + Protocol.DEFAULT_PORT);
        }
        return Protocol.DEFAULT_PORT;
    }

    private static void printBanner(int port) {
        ServerLog.plain("");
        ServerLog.plain("   .-.     GHOST-CHAT  -  Server");
        ServerLog.plain("  (o o)    Le chat esistono solo finche' i client sono aperti:");
        ServerLog.plain("  | O \\    il server inoltra i messaggi ma non ne salva nessuno (online 24/7).");
        ServerLog.plain("   \\   \\");
        ServerLog.plain("    `~~~'  Porta: " + port);
        List<String> addresses = localAddresses();
        if (!addresses.isEmpty()) {
            ServerLog.plain("           Indirizzi da usare nei client: " + String.join(", ", addresses)
                    + " (oppure localhost sullo stesso PC)");
        }
        String pub = ServerConfig.str("public.host");
        ServerLog.plain("           Porta unica per tutto: client PC (anche TLS), app Android/iOS (WebSocket) e browser");
        if (!pub.isEmpty()) {
            ServerLog.plain("           Indirizzo pubblico: " + pub + ":" + port + "  -  web: http://" + pub + ":" + port + "/");
        }
        ServerLog.plain("           Scrivi \"aiuto\" per l'elenco dei comandi.");
        ServerLog.plain("");
    }

    /** Indirizzi IPv4 della macchina, utili per sapere a cosa collegare i client. */
    private static List<String> localAddresses() {
        List<String> result = new ArrayList<>();
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                try {
                    if (!ni.isUp() || ni.isLoopback() || ni.isVirtual()) {
                        continue;
                    }
                    for (InetAddress a : Collections.list(ni.getInetAddresses())) {
                        if (a instanceof Inet4Address && !a.isLoopbackAddress()) {
                            result.add(a.getHostAddress());
                        }
                    }
                } catch (Throwable ignored) {
                    // interfaccia non leggibile: si salta
                }
            }
        } catch (Throwable ignored) {
            // nessuna informazione disponibile
        }
        return result;
    }

    private static void sleep(long ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
