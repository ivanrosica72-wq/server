package ghostchat.server;

import java.io.IOException;
import java.io.Reader;

/**
 * Lettore di righe con lunghezza massima.
 * <p>
 * BufferedReader.readLine() accetterebbe righe lunghe a piacere: un client
 * malfunzionante potrebbe esaurire la memoria. Questa classe scarta le righe
 * troppo lunghe e restituisce {@link #OVERSIZED} al loro posto.
 */
public final class LineReader {

    /** Valore speciale restituito al posto di una riga troppo lunga. */
    public static final String OVERSIZED = new String("<<riga troppo lunga>>");

    private final Reader in;
    private final int maxLength;
    private final char[] buffer = new char[16384];
    private int pos;
    private int len;

    public LineReader(Reader in, int maxLength) {
        this.in = in;
        this.maxLength = maxLength;
    }

    /**
     * @return la riga letta (senza terminatore), {@link #OVERSIZED} se troppo
     * lunga, oppure null se lo stream e' terminato
     */
    public String readLine() throws IOException {
        StringBuilder sb = null;
        boolean overflow = false;
        boolean readSomething = false;
        while (true) {
            if (pos >= len) {
                len = in.read(buffer, 0, buffer.length);
                pos = 0;
                if (len <= 0) {
                    len = 0;
                    if (!readSomething) {
                        return null;
                    }
                    return overflow ? OVERSIZED : finish(sb);
                }
            }
            readSomething = true;
            // cerca la fine riga nel blocco gia' letto (molto piu' veloce che carattere per carattere)
            int start = pos;
            int nl = -1;
            for (int i = pos; i < len; i++) {
                if (buffer[i] == '\n') {
                    nl = i;
                    break;
                }
            }
            int end = nl >= 0 ? nl : len;
            if (!overflow) {
                int current = sb == null ? 0 : sb.length();
                if (current + (end - start) > maxLength) {
                    overflow = true;
                    sb = null;
                } else {
                    if (sb == null) {
                        sb = new StringBuilder(Math.max(64, end - start));
                    }
                    sb.append(buffer, start, end - start);
                }
            }
            if (nl >= 0) {
                pos = nl + 1;
                return overflow ? OVERSIZED : finish(sb);
            }
            pos = len;
        }
    }

    private static String finish(StringBuilder sb) {
        if (sb == null) {
            return "";
        }
        int l = sb.length();
        if (l > 0 && sb.charAt(l - 1) == '\r') {
            sb.setLength(l - 1);
        }
        return sb.toString();
    }
}
