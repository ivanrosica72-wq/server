# Ghost-chat Server su Wispbyte (online 24/7)

Il server è un solo file: **`GhostChatServer.jar`** (Java 8 o più recente, nessuna libreria esterna).
Indirizzo che usano i client: **78.154.103.51 : 11112**.

## 1. Caricare il server

1. Nel pannello Wispbyte apri il tuo server (tipo **Java**) e vai su **Files**.
2. Carica `GhostChatServer.jar` nella cartella principale (`/home/container`).
3. In **Startup** imposta il file da avviare su `GhostChatServer.jar`
   (variabile *Server Jar File* / *JARFILE*; se il comando è libero usa:
   `java -Xms64M -Xmx{{SERVER_MEMORY}}M -jar GhostChatServer.jar`).
4. Controlla in **Network** che la porta assegnata sia **11112**: il server legge da solo la variabile `SERVER_PORT`
   del pannello, quindi usa sempre la porta giusta.
5. Premi **Start**. Nella console compare il fantasmino e la riga
   `Server in ascolto sulla porta 11112`.

Al primo avvio il server crea accanto al jar:
- `ghostchat-server.properties` – configurazione (modificabile da *Files*, poi *Restart*);
- `ghostchat-tls.p12` – certificato per le connessioni cifrate;
- `ghostchat-data/` – account, contatti, InstaGhost. **Non cancellarla**: sono i dati degli utenti.

## 2. Una porta per tutto

Su Wispbyte si ha di solito una sola porta, quindi sulla 11112 il server accetta insieme:
- il **client per computer** (connessione normale o cifrata TLS: casella *Connessione cifrata* nella schermata di accesso);
- le **app Android e iOS** (WebSocket `ws://78.154.103.51:11112`);
- il **browser**: `http://78.154.103.51:11112/` apre la versione web di Ghost-chat (è già dentro il jar;
  una cartella `web/` accanto al jar, se presente, ha la precedenza).

## 3. Comandi in console

Scrivi `aiuto` nella console del pannello per l'elenco (utenti online, avvisi, espulsioni, stato...).

## 4. Email per l'accesso con codice (facoltativo)

In `ghostchat-server.properties` compila `smtp.host`, `smtp.port`, `smtp.security`, `smtp.user`, `smtp.password`,
`smtp.from` (es. Gmail: `smtp.gmail.com`, `587`, `starttls`, password per le app). Senza email i codici vengono
scritti nella console.

## 5. Cambiare indirizzo

Se Wispbyte ti assegna un altro IP o un'altra porta: nei client si cambiano nella schermata di accesso
(campi *Server* e *Porta*, anche nei preferiti); nel server aggiorna `public.host`.

## Note

- Il server non salva i messaggi delle chat: li inoltra e basta. Restano salvati solo account, contatti e InstaGhost.
- Memoria: bastano 256-512 MB. I video di InstaGhost occupano spazio disco nella cartella `ghostchat-data/instaghost`
  (limiti in `instaghost.maxVideoMB`).
- Se il pannello chiede la versione di Java, va bene qualsiasi versione dalla 8 in su (consigliata 17 o 21).
