/* Ghost-chat mobile · connessione al server (WebSocket, anche cifrata wss:// da Internet) */
"use strict";
const Net = (() => {
  let ws = null, url = "", authLine = "", online = false, wantOpen = false, retry = 0, pingTimer = null, retryTimer = null;
  const handlers = {};
  const on = (cmd, fn) => { (handlers[cmd] = handlers[cmd] || []).push(fn); };
  const emit = (cmd, payload) => { for (const fn of (handlers[cmd] || [])) { try { fn(payload); } catch (e) { console.error(cmd, e); } } };

  const escape = t => String(t ?? "").replace(/\\/g, "\\\\").replace(/\r/g, "").replace(/\n/g, "\\n");
  const unescape = t => String(t ?? "").replace(/\\(.)/g, (m, c) => c === "n" ? "\n" : c === "p" ? "|" : c);
  const escField = t => escape(t).replace(/\|/g, "\\p");
  const b64 = s => btoa(unescape_(encodeURIComponent(s)));
  function unescape_(s) { return s.replace(/%([0-9A-F]{2})/g, (m, p) => String.fromCharCode(parseInt(p, 16))); }

  function connect(host, port, tls, line) {
    url = `${tls ? "wss" : "ws"}://${host}:${port}`;
    authLine = line;
    wantOpen = true;
    retry = 0;
    open();
  }

  function open() {
    clearTimeout(retryTimer);
    try { if (ws) ws.close(); } catch (e) { /* niente */ }
    emit("_connecting", url);
    let sock;
    try { sock = new WebSocket(url); } catch (e) { emit("_failed", "Indirizzo non valido: " + e.message); return; }
    ws = sock;
    sock.onopen = () => { sock.send(authLine); };
    sock.onmessage = ev => {
      for (const line of String(ev.data).split("\n")) {
        if (!line) continue;
        const i = line.indexOf("|");
        const cmd = (i < 0 ? line : line.slice(0, i)).toUpperCase();
        const payload = i < 0 ? "" : line.slice(i + 1);
        if (cmd === "WELCOME") {
          online = true; retry = 0;
          const f = payload.split("|");
          if (f[2]) authLine = `AUTH|token|${f[0]}|${f[2]}`; // le riconnessioni usano il gettone
          clearInterval(pingTimer); pingTimer = setInterval(() => send("PING"), 20000);
        }
        if (cmd === "AUTHERR" || cmd === "NICKERR") { wantOpen = false; online = false; }
        emit(cmd, payload);
      }
    };
    sock.onclose = () => {
      if (sock !== ws) return;
      const was = online; online = false; clearInterval(pingTimer);
      if (!wantOpen) { emit("_closed", ""); return; }
      if (!was && retry === 0) { emit("_failed", "Server non raggiungibile (" + url + ")"); wantOpen = false; return; }
      retry++;
      const d = Math.min(30, 2 ** Math.min(retry, 5));
      emit("_lost", d);
      retryTimer = setTimeout(open, d * 1000);
    };
    sock.onerror = () => { /* gestito da onclose */ };
  }

  function send(line) { if (ws && ws.readyState === 1) { ws.send(line); return true; } return false; }
  function close() { wantOpen = false; try { send("QUIT"); ws && ws.close(); } catch (e) { /* niente */ } online = false; }
  /** Richiesta breve (es. codice via email) su una connessione a parte. */
  function oneShot(host, port, tls, line, expect) {
    return new Promise(res => {
      let done = false; const s = new WebSocket(`${tls ? "wss" : "ws"}://${host}:${port}`);
      const fin = v => { if (!done) { done = true; res(v); try { s.close(); } catch (e) { /* niente */ } } };
      s.onopen = () => s.send(line);
      s.onmessage = ev => { for (const l of String(ev.data).split("\n")) if (l.startsWith(expect + "|")) fin(l.slice(expect.length + 1)); };
      s.onerror = () => fin("err|Server non raggiungibile");
      setTimeout(() => fin("err|Nessuna risposta dal server"), 30000);
    });
  }
  return { connect, send, close, on, oneShot, escape, unescape, escField, b64, isOnline: () => online, buffered: () => (ws ? ws.bufferedAmount : 0) };
})();
