/* Ghost-chat mobile · stati (24 ore, solo tra contatti): testo colorato, foto, GIF e video.
 * SPOST|id|T/I/G/V|byte|meta|testo · SCHUNK · SEND · SGET · SSEEN · SDEL · STATUS / SDATA / SDATAEND / SGONE dal server. */
"use strict";
const Status = (() => {
  const LIFE = 24 * 3600 * 1000;
  const COLORS = ["#6A1B9A", "#311B92", "#AD1457", "#00838F", "#2E7D32", "#EF6C00", "#37474F", "#000000"];
  let items = new Map();     // owner/id -> stato
  const views = new Map();   // id dei miei stati -> Map(chi -> ora)
  const loading = new Map(); // owner/id -> { parts, cbs }
  const key = (o, id) => kc(o) + "/" + id;
  function reset() { items = new Map(); views.clear(); loading.clear(); }
  const seenSet = () => new Set(Store.get("seenStatus", []));
  function markSeen(s) { const set = seenSet(); set.add(key(s.owner, s.id) + "@" + s.time); Store.set("seenStatus", [...set].slice(-400)); }
  const isSeen = s => isMe(s.owner) || seenSet().has(key(s.owner, s.id) + "@" + s.time);
  function alive() { const now = Date.now(); for (const [k, s] of items) if (now - s.time > LIFE) items.delete(k); return [...items.values()]; }
  function byOwner() {
    const m = new Map();
    for (const s of alive().sort((a, b) => a.time - b.time)) { const k = kc(s.owner); if (!m.has(k)) m.set(k, { owner: s.owner, list: [] }); m.get(k).list.push(s); }
    return m;
  }

  // ============================================================ eventi dal server
  Net.on("STATUS", p => {
    const f = p.split("|"); if (f.length < 7) return;
    const s = { owner: f[0], id: f[1], kind: (f[2] || "T")[0], time: parseInt(f[3], 10) || Date.now(), size: parseInt(f[4], 10) || 0,
      bg: parseMeta(f[5]).bg || "#6A1B9A", text: Net.unescape(f.slice(6).join("|")), url: null };
    if (!isMe(s.owner) && !isContact(s.owner)) return;
    const old = items.get(key(s.owner, s.id)); if (old && old.url) s.url = old.url;
    items.set(key(s.owner, s.id), s);
    redrawStrip();
  });
  Net.on("SGONE", p => { const [o, id] = p.split("|"); items.delete(key(o, id)); redrawStrip(); });
  Net.on("SSEEN", p => { const [who, id, t] = p.split("|"); if (!views.has(id)) views.set(id, new Map()); views.get(id).set(who, parseInt(t, 10) || Date.now()); });
  Net.on("SDATA", p => { const f = p.split("|"); const l = loading.get(key(f[0], f[1])); if (l) { try { l.parts.push(Media.b64ToBytes(f[2] || "")); } catch (e) { l.bad = true; } } });
  Net.on("SDATAEND", p => {
    const f = p.split("|"); const k = key(f[0], f[1]); const l = loading.get(k); if (!l) return; loading.delete(k);
    const s = items.get(k); if (!s || l.bad) { l.cbs.forEach(cb => cb(null)); return; }
    const blob = new Blob(l.parts, { type: s.kind === "V" ? "video/mp4" : s.kind === "G" ? "image/gif" : "image/jpeg" });
    s.url = URL.createObjectURL(blob); l.cbs.forEach(cb => cb(s.url));
  });
  Net.on("ERR", p => { if ((p.split("|")[1] || "") === "#status") { const id = p.split("|")[2]; for (const [k, l] of loading) if (k.endsWith("/" + id)) { loading.delete(k); l.cbs.forEach(cb => cb(null)); } } });
  function fetchData(s, cb) {
    if (s.url) return cb(s.url);
    const k = key(s.owner, s.id);
    if (loading.has(k)) { loading.get(k).cbs.push(cb); return; }
    loading.set(k, { parts: [], cbs: [cb] });
    Net.send(`SGET|${s.owner}|${s.id}`);
  }

  // ============================================================ striscia in cima alle chat
  function strip() {
    const row = h("div", { class: "stories glass", id: "status-strip" });
    fill(row); return row;
  }
  function redrawStrip() { const row = $("#status-strip"); if (row) { row.innerHTML = ""; fill(row); } }
  function fill(row) {
    const groups = byOwner();
    const mine = groups.get(kc(App.me));
    const me = avatar(App.me || "?"); if (mine) me.classList.add("ring", "seen"); else me.append(h("span", { class: "plus" }, "+"));
    row.append(h("div", { class: "story", onclick: () => mine ? view(mine.list, 0) : compose() }, me, h("div", {}, "Il mio stato")));
    const others = [...groups.values()].filter(g => !isMe(g.owner)).sort((a, b) => (a.list.every(isSeen) - b.list.every(isSeen)) || (b.list[b.list.length - 1].time - a.list[a.list.length - 1].time));
    for (const g of others) {
      const av = avatar(g.owner); av.classList.add("ring"); if (g.list.every(isSeen)) av.classList.add("seen");
      row.append(h("div", { class: "story", onclick: () => view(g.list, Math.max(0, g.list.findIndex(s => !isSeen(s)))) }, av, h("div", {}, g.owner)));
    }
    if (!others.length && !mine) row.append(h("div", { class: "muted", style: "font-size:.78em;align-self:center;max-width:180px" }, "Gli stati dei tuoi contatti appaiono qui per 24 ore."));
  }
  function openList() {
    const groups = byOwner(); const mine = groups.get(kc(App.me));
    const s = sheet("Stati", h("div", { class: "item", onclick: () => { s.close(); compose(); } }, h("span", { class: "mi" }, "➕"), h("div", { class: "main" }, h("div", { class: "name" }, "Pubblica un nuovo stato"), h("div", { class: "sub" }, "Testo, foto, GIF o video · dura 24 ore"))),
      mine ? h("div", { class: "item", onclick: () => { s.close(); view(mine.list, 0); } }, avatar(App.me), h("div", { class: "main" }, h("div", { class: "name" }, "I miei stati"), h("div", { class: "sub" }, mine.list.length + " attivi"))) : null,
      h("div", { class: "label" }, "DEI CONTATTI"),
      ...[...groups.values()].filter(g => !isMe(g.owner)).map(g => h("div", { class: "item", onclick: () => { s.close(); view(g.list, 0); } }, avatar(g.owner), h("div", { class: "main" }, h("div", { class: "name" }, g.owner), h("div", { class: "sub" }, `${g.list.length} · ${time(g.list[g.list.length - 1].time)}${g.list.every(isSeen) ? " · visti" : ""}`)))));
  }

  // ============================================================ visualizzazione
  function view(list, start) {
    let i = start, timer = null, video = null, paused = false, t0 = 0, dur = 5000, left = 0;
    const bars = h("div", { class: "st-bars" }, ...list.map(() => h("div", {}, h("i", {}))));
    const stage = h("div", { class: "st-stage" });
    const info = h("div", { class: "st-head" });
    const foot = h("div", { class: "st-foot" });
    const w = h("div", { class: "statusview" }, bars, info, stage, foot);
    const close = () => { clearTimeout(timer); if (video) video.pause(); w.remove(); redrawStrip(); };
    stage.addEventListener("click", e => { const r = stage.getBoundingClientRect(); if (e.clientX - r.left < r.width * .3) go(i - 1); else go(i + 1); });
    stage.addEventListener("pointerdown", () => { paused = true; clearTimeout(timer); left = dur - (Date.now() - t0); if (video) video.pause(); });
    stage.addEventListener("pointerup", () => { if (!paused) return; paused = false; t0 = Date.now() - (dur - left); if (video) video.play(); else timer = setTimeout(() => go(i + 1), left); });
    function go(n) {
      clearTimeout(timer); if (video) { video.pause(); video = null; }
      if (n < 0) n = 0; if (n >= list.length) return close();
      i = n; const s = list[i];
      [...bars.children].forEach((b, k) => { const f = b.firstChild; f.style.transition = "none"; f.style.width = k < i ? "100%" : "0"; });
      info.innerHTML = ""; info.append(avatar(s.owner), h("div", { style: "flex:1" }, h("b", {}, isMe(s.owner) ? "Il mio stato" : s.owner), h("div", { class: "sub" }, time(s.time))),
        h("button", { class: "iconbtn", style: "color:#fff", onclick: close, html: svg("close") }));
      stage.innerHTML = ""; foot.innerHTML = "";
      if (s.kind === "T") { stage.append(h("div", { class: "st-text", style: `background:${s.bg}` }, s.text)); run(5000 + Math.min(5000, s.text.length * 40)); }
      else {
        stage.append(h("div", { class: "muted", style: "color:#fff" }, "Caricamento…"));
        fetchData(s, url => {
          if (list[i] !== s) return;
          stage.innerHTML = "";
          if (!url) { stage.append(h("div", { style: "color:#fff" }, "Stato non più disponibile")); run(2000); return; }
          if (s.kind === "V") { video = h("video", { src: url, autoplay: true, playsinline: true }); video.onloadedmetadata = () => run(Math.min(60000, (video.duration || 10) * 1000)); video.onended = () => go(i + 1); stage.append(video); }
          else { stage.append(h("img", { src: url, alt: "" })); run(6000); }
          if (s.text) stage.append(h("div", { class: "st-caption" }, s.text));
        });
      }
      if (!isMe(s.owner)) {
        if (!isSeen(s)) { markSeen(s); Net.send(`SSEEN|${s.owner}|${s.id}`); }
        const reply = h("input", { class: "field", placeholder: "Rispondi a " + s.owner });
        reply.addEventListener("focus", () => { paused = true; clearTimeout(timer); if (video) video.pause(); });
        reply.addEventListener("keydown", e => { if (e.key === "Enter" && reply.value.trim()) { const c = chatOf(App.contacts.get(kc(s.owner)) || s.owner, true); send(c, `💬 Risposta al tuo stato (${s.kind === "T" ? "“" + s.text.slice(0, 60) + "”" : s.kind === "V" ? "video" : "foto"}): ${reply.value.trim()}`); toast("Risposta inviata"); close(); } });
        foot.append(reply, h("div", { class: "row", style: "justify-content:center" }, ...["❤️", "😂", "😮", "👍"].map(e => h("button", { class: "btn small", onclick: () => { const c = chatOf(App.contacts.get(kc(s.owner)) || s.owner, true); send(c, `${e} al tuo stato`); toast("Inviato"); } }, e))));
      } else {
        const v = views.get(s.id); const n = v ? v.size : 0;
        foot.append(h("div", { class: "row", style: "justify-content:center" },
          h("button", { class: "btn small", onclick: () => { paused = true; clearTimeout(timer); sheet(`Visto da ${n}`, ...(n ? [...v.entries()].map(([who, t]) => h("div", { class: "item" }, avatar(who), h("div", { class: "main" }, who), h("span", { class: "muted" }, time(t)))) : [h("p", { class: "muted" }, "Ancora nessuno")])); } }, `👁 ${n}`),
          h("button", { class: "btn small", onclick: async () => { paused = true; clearTimeout(timer); if (await confirmBox("Elimina stato", "Eliminare questo stato per tutti?", "Elimina", true)) { Net.send("SDEL|" + s.id); items.delete(key(s.owner, s.id)); list.splice(i, 1); [...bars.children][i]?.remove(); if (!list.length) close(); else go(Math.min(i, list.length - 1)); } } }, "🗑 Elimina"),
          h("button", { class: "btn small", onclick: () => { close(); compose(); } }, "➕ Nuovo")));
      }
    }
    function run(ms) {
      dur = ms; t0 = Date.now(); const f = bars.children[i].firstChild;
      requestAnimationFrame(() => { f.style.transition = `width ${ms}ms linear`; f.style.width = "100%"; });
      if (!video) timer = setTimeout(() => go(i + 1), ms);
    }
    document.body.append(w); go(i);
  }

  // ============================================================ pubblicazione
  function compose() {
    let bg = COLORS[0];
    const ta = h("textarea", { class: "area st-compose", placeholder: "Scrivi qualcosa…", maxlength: 700, style: `background:${bg}` });
    const cols = h("div", { class: "row", style: "gap:6px;flex-wrap:wrap" }, ...COLORS.map(cl => h("button", { class: "wb-col", style: `background:${cl}`, onclick: () => { bg = cl; ta.style.background = cl; } })));
    const file = h("input", { type: "file", accept: "image/*,video/*", style: "display:none", onchange: () => { const f = file.files[0]; if (f) { s.close(); postMedia(f); } } });
    const s = sheet("Nuovo stato", ta, cols, file,
      h("div", { class: "row", style: "margin-top:10px" }, h("button", { class: "btn", onclick: () => file.click() }, "📷 Foto o video"),
        h("button", { class: "btn primary", onclick: () => { const t = ta.value.trim(); if (!t) return toast("Scrivi qualcosa", true); postText(t, bg); s.close(); } }, "Pubblica")));
    setTimeout(() => ta.focus(), 100);
  }
  function postText(text, bg) {
    const id = newId().replace(/[^A-Za-z0-9]/g, "").slice(0, 24);
    if (!Net.send(`SPOST|${id}|T|0|${buildMeta({ bg })}|${Net.escField(text)}`)) return toast("Non sei connesso", true);
    toast("Stato pubblicato ✨");
  }
  async function postMedia(f) {
    const caption = await ask("Didascalia", "Facoltativa", "Scrivi una didascalia", "", "Pubblica"); if (caption === null) return;
    let kind = f.type === "image/gif" ? "G" : f.type.startsWith("image/") ? "I" : f.type.startsWith("video/") ? "V" : null;
    if (!kind) return toast("Scegli una foto o un video", true);
    let blob = f; if (kind === "I") blob = await Media.compressImage(f, 1600, .85);
    const max = kind === "V" ? 16 * 1048576 : 8 * 1048576;
    if (blob.size > max) return toast(`File troppo grande (massimo ${max / 1048576} MB)`, true);
    const buf = new Uint8Array(await blob.arrayBuffer()); const id = newId().replace(/[^A-Za-z0-9]/g, "").slice(0, 24);
    if (!Net.send(`SPOST|${id}|${kind}|${buf.length}||${Net.escField(caption.trim())}`)) return toast("Non sei connesso", true);
    toast("Caricamento dello stato…");
    let crc = Media.Crc32.start();
    for (let i = 0; i < buf.length; i += 48 * 1024) { const part = buf.subarray(i, i + 48 * 1024); crc = Media.Crc32.update(crc, part); Net.send(`SCHUNK|${id}|${Media.bytesToB64(part)}`); if ((i / 49152) % 8 === 7) await new Promise(r => setTimeout(r, 15)); }
    Net.send(`SEND|${id}|${Media.Crc32.hex(crc).padStart(8, "0")}`);
    const s = { owner: App.me, id, kind, time: Date.now(), size: buf.length, bg: "", text: caption.trim(), url: URL.createObjectURL(blob) };
    items.set(key(App.me, id), s); redrawStrip();
  }
  return { strip, openList, compose, reset, redrawStrip };
})();
