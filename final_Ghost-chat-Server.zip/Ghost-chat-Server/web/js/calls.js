/* Ghost-chat mobile · chiamate e videochiamate (a due e di gruppo), compatibili con il computer:
 * audio PCM 16 bit 16 kHz mono a pacchetti di 40 ms (AUDIO), video a fotogrammi JPEG (VIDEO),
 * segnali CALL / CALLACCEPT / CALLREJECT / CALLEND / VIDSTATE / CALLREACT, stato dei gruppi con GCALL. */
"use strict";
const Calls = (() => {
  const RATE = 16000, FRAME = 640;
  let call = null;          // chiamata in corso (a due o di gruppo)
  let media = null;         // microfono, fotocamera, elaborazione audio
  let ui = null;            // finestra della chiamata
  let ringTimer = null, ringTone = null;
  const groupCalls = new Map(); // gid -> { callId, video, parts: [] }
  const remote = new Map();     // chi parla -> { next, frame, video, level }

  // ============================================================ audio in uscita e in entrata
  async function startMedia(video) {
    if (media) return true;
    const cam = Store.get("callCam", "user");
    let stream;
    try {
      stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true },
        video: video ? { facingMode: cam, width: { ideal: 640 }, height: { ideal: 480 } } : false });
    } catch (e) {
      if (video) { try { stream = await navigator.mediaDevices.getUserMedia({ audio: true }); toast("Fotocamera non disponibile: chiamata solo audio", true); video = false; } catch (e2) { stream = null; } }
      if (!stream) { toast("Microfono non disponibile: consenti l'accesso al microfono", true); return false; }
    }
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    try { await ctx.resume(); } catch (e) { /* niente */ }
    const src = ctx.createMediaStreamSource(stream);
    const proc = ctx.createScriptProcessor(2048, 1, 1);
    const mute = ctx.createGain(); mute.gain.value = 0;
    const ratio = ctx.sampleRate / RATE; let pos = 0, carry = new Float32Array(0); const out = new Int16Array(FRAME); let n = 0;
    proc.onaudioprocess = e => {
      const inp = e.inputBuffer.getChannelData(0);
      const all = new Float32Array(carry.length + inp.length); all.set(carry); all.set(inp, carry.length);
      let peak = 0;
      while (pos + 1 < all.length) {
        const i0 = Math.floor(pos), fr = pos - i0; const s = all[i0] * (1 - fr) + all[i0 + 1] * fr;
        peak = Math.max(peak, Math.abs(s));
        out[n++] = Math.max(-1, Math.min(1, s)) * 0x7FFF;
        if (n === FRAME) { n = 0; if (call && media && call.state === "connected" && !media.muted) sendAudio(out); }
        pos += ratio;
      }
      const used = Math.floor(pos); carry = all.slice(used); pos -= used;
      if (media) media.level = peak;
    };
    src.connect(proc); proc.connect(mute); mute.connect(ctx.destination);
    media = { stream, ctx, src, proc, mute, muted: false, camOn: !!video, cam, level: 0, video: null, canvas: document.createElement("canvas"), vtimer: null };
    if (video) attachVideo();
    return true;
  }
  function attachVideo() {
    const v = h("video", { autoplay: true, playsinline: true, muted: true }); v.muted = true; v.srcObject = media.stream; v.play().catch(() => {});
    media.video = v;
    clearInterval(media.vtimer);
    media.vtimer = setInterval(sendFrame, 140);
  }
  function sendAudio(pcm) {
    const u8 = new Uint8Array(pcm.buffer.slice(0));
    const b64 = Media.bytesToB64(u8);
    Net.send(`AUDIO|${call.dest}|${call.callId}|${b64}`);
  }
  function sendFrame() {
    if (!call || call.state !== "connected" || !media || !media.camOn || !media.video || !media.video.videoWidth) return;
    if (Net.buffered && Net.buffered() > 400000) return; // rete lenta: si salta un fotogramma
    const v = media.video, w = 320, hgt = Math.round(320 * v.videoHeight / v.videoWidth) || 240;
    const cv = media.canvas; cv.width = w; cv.height = hgt; const g = cv.getContext("2d");
    g.drawImage(v, 0, 0, w, hgt);
    const b64 = cv.toDataURL("image/jpeg", .55).split(",")[1];
    if (b64.length < 190000) Net.send(`VIDEO|${call.dest}|${call.callId}|${b64}`);
  }
  function stopMedia() {
    if (!media) return;
    clearInterval(media.vtimer);
    try { media.proc.disconnect(); media.src.disconnect(); media.mute.disconnect(); } catch (e) { /* niente */ }
    media.stream.getTracks().forEach(t => t.stop());
    try { media.ctx.close(); } catch (e) { /* niente */ }
    media = null; remote.clear();
  }
  function playAudio(who, b64) {
    if (!media || !call || call.state !== "connected") return;
    let bytes; try { bytes = Media.b64ToBytes(b64); } catch (e) { return; }
    const nS = bytes.length >> 1; if (!nS) return;
    const dv = new DataView(bytes.buffer, bytes.byteOffset, nS * 2);
    const ctx = media.ctx; const buf = ctx.createBuffer(1, nS, RATE); const ch = buf.getChannelData(0);
    let peak = 0; for (let i = 0; i < nS; i++) { const s = dv.getInt16(i * 2, true) / 32768; ch[i] = s; peak = Math.max(peak, Math.abs(s)); }
    const r = remote.get(who) || remote.set(who, { next: 0, frame: null, video: "off", level: 0 }).get(who);
    r.level = peak; r.heard = Date.now();
    const now = ctx.currentTime;
    if (r.next < now + .02 || r.next > now + .5) r.next = now + .08;
    const src = ctx.createBufferSource(); src.buffer = buf; src.connect(ctx.destination); src.start(r.next);
    r.next += nS / RATE;
  }

  // ============================================================ suoneria
  function ring(kind) {
    stopRing();
    const play = () => { if (kind === "in") { Sound.beep(880, .25, .12); setTimeout(() => Sound.beep(660, .25, .12), 300); vibrate([400, 200, 400]); } else Sound.beep(440, .4, .05); };
    play(); ringTone = setInterval(play, kind === "in" ? 2000 : 3000);
  }
  function stopRing() { clearInterval(ringTone); ringTone = null; }

  // ============================================================ avvio e risposta
  async function start(c, video) {
    if (call) { toast("Sei già in una chiamata", true); openUI(); return; }
    if (c.group) return joinGroup(c.id.slice(1), video);
    if (!isContact(c.id)) return toast(`${c.name} non è ancora tra i tuoi contatti`, true);
    if (isBlocked(c.id)) return toast("Hai bloccato " + c.name, true);
    if (!App.users.has(kc(c.id))) return toast(`${c.name} non è online in questo momento`, true);
    const callId = newId();
    call = { group: false, chat: c, peer: c.id, dest: c.id, callId, video, state: "calling", outgoing: true, startedAt: 0 };
    if (!(await startMedia(video))) { call = null; return; }
    call.video = media.camOn;
    if (!Net.send(`CALL|${c.id}|${callId}|${call.video ? "V" : "A"}`)) { toast("Non sei connesso al server", true); finish(null); return; }
    ring("out"); openUI();
    clearTimeout(ringTimer); ringTimer = setTimeout(() => { if (call && call.callId === callId && call.state === "calling") { Net.send(`CALLEND|${c.id}|${callId}`); finish("📵 Nessuna risposta", false); } }, 45000);
  }
  async function accept(withVideo) {
    if (!call || call.state !== "ringing") return;
    stopRing(); clearTimeout(ringTimer);
    if (!(await startMedia(withVideo))) { reject(); return; }
    if (call.group) {
      call.state = "connected"; call.startedAt = Date.now();
      Net.send(`CALLACCEPT|${call.dest}|${call.callId}`);
      if (media.camOn) Net.send(`VIDSTATE|${call.dest}|${call.callId}|cam`);
    } else {
      Net.send(`CALLACCEPT|${call.peer}|${call.callId}`);
      connected();
    }
    openUI();
  }
  function reject() {
    if (!call) return;
    stopRing(); clearTimeout(ringTimer);
    if (!call.group) Net.send(`CALLREJECT|${call.peer}|${call.callId}|rifiutata`);
    const c = call.chat; call = null; closeUI();
    if (c && !c.group) system(c, "📵 Hai rifiutato la chiamata");
  }
  function connected() {
    if (!call) return;
    stopRing(); clearTimeout(ringTimer);
    call.state = "connected"; call.startedAt = Date.now();
    Net.send(`VIDSTATE|${call.dest}|${call.callId}|${media && media.camOn ? "cam" : "off"}`);
    openUI();
  }
  function hangup() {
    if (!call) return;
    if (call.state === "ringing") return reject();
    Net.send(`CALLEND|${call.dest}|${call.callId}`);
    if (call.group) { const c = call.chat; call = null; stopMedia(); closeUI(); if (c) system(c, "📞 Sei uscito dalla chiamata di gruppo"); if (App.active) renderConvHead(); return; }
    finish(call.state === "connected" ? null : "📵 Chiamata annullata", true);
  }
  function hangupAll() { if (call) hangup(); }
  /** Fine della chiamata a due, con la riga nel registro della chat. */
  function finish(text, byMe) {
    if (!call) return;
    stopRing(); clearTimeout(ringTimer);
    const c = call.chat; const dur = call.startedAt ? Date.now() - call.startedAt : 0; const video = call.video;
    call = null; stopMedia(); closeUI();
    if (c) system(c, text || `${video ? "📹 Videochiamata" : "📞 Chiamata"} · ${fmtDur(dur)}`);
    if (!byMe && text) toast(text);
  }

  // ============================================================ chiamate di gruppo
  async function joinGroup(gid, video) {
    const g = App.groups.get(gid); const c = chatOf("#" + gid, true);
    if (!g || c.alive === false) return toast("Non fai più parte di questo gruppo", true);
    const gc = groupCalls.get(gid);
    const callId = gc ? gc.callId : newId();
    call = { group: true, gid, chat: c, dest: "#" + gid, callId, video, state: "connected", outgoing: !gc, startedAt: Date.now() };
    if (!(await startMedia(video))) { call = null; return; }
    if (gc) Net.send(`CALLACCEPT|#${gid}|${callId}`); else Net.send(`CALL|#${gid}|${callId}|${media.camOn ? "V" : "A"}`);
    if (media.camOn) setTimeout(() => call && Net.send(`VIDSTATE|#${gid}|${callId}|cam`), 400);
    openUI();
  }
  function onGroupCall(p) {
    const f = p.split("|"); const gid = f[0], callId = f[1] || "", video = f[2] === "V", parts = (f[3] || "").split(",").filter(Boolean);
    if (!callId) groupCalls.delete(gid); else groupCalls.set(gid, { callId, video, parts });
    if (call && call.group && call.gid === gid) {
      if (!callId || callId !== call.callId) { const c = call.chat; call = null; stopMedia(); closeUI(); if (c) system(c, "📞 La chiamata di gruppo è terminata"); }
      else { for (const k of [...remote.keys()]) if (!parts.some(x => kc(x) === kc(k))) remote.delete(k); drawUI(); }
    }
    if (call && call.group && call.gid === gid && call.state === "ringing" && !callId) { stopRing(); call = null; closeUI(); }
    if (App.active && App.active.id === "#" + gid) renderBanner(App.active);
    renderChats();
  }
  function renderBanner(c) {
    const box = $("#call-banner"); if (!box) return; box.innerHTML = "";
    if (!c.group) { if (call && call.chat === c && !ui) box.append(h("div", { class: "callbar", onclick: openUI }, "📞 Chiamata in corso · tocca per tornare")); return; }
    const gc = groupCalls.get(c.id.slice(1)); if (!gc) return;
    const inIt = call && call.group && call.gid === c.id.slice(1);
    box.append(h("div", { class: "callbar", onclick: () => inIt ? openUI() : joinGroup(c.id.slice(1), gc.video) },
      (gc.video ? "📹" : "📞") + ` Chiamata di gruppo in corso · ${gc.parts.length} ${gc.parts.length === 1 ? "persona" : "persone"} · ` + (inIt ? "tocca per tornare" : "Partecipa")));
  }

  // ============================================================ segnali dal server
  function sig(p) { const f = p.split("|"); return { from: f[0], id: f[1] || "", extra: f.slice(2).join("|") }; }
  Net.on("CALL", p => {
    const s = sig(p);
    if (s.from.startsWith("#")) {
      const o = origin(s.from); if (!o.chat || isMe(o.nick)) return;
      if (call) return;
      call = { group: true, gid: o.chat.id.slice(1), chat: o.chat, dest: o.chat.id, callId: s.id, video: s.extra.trim().toUpperCase() === "V", state: "ringing", caller: o.nick };
      ring("in"); openUI();
      clearTimeout(ringTimer); ringTimer = setTimeout(() => { if (call && call.state === "ringing" && call.callId === s.id) { stopRing(); call = null; closeUI(); } }, 40000);
      return;
    }
    const o = origin(s.from);
    if (!o.chat) { Net.send(`CALLREJECT|${s.from}|${s.id}|rifiutata`); return; }
    if (call) { Net.send(`CALLREJECT|${s.from}|${s.id}|occupato`); system(o.chat, "📵 Chiamata persa (eri in un'altra chiamata)"); return; }
    call = { group: false, chat: o.chat, peer: s.from, dest: s.from, callId: s.id, video: s.extra.trim().toUpperCase() === "V", state: "ringing", outgoing: false };
    ring("in"); openUI();
    clearTimeout(ringTimer); ringTimer = setTimeout(() => { if (call && call.state === "ringing" && call.callId === s.id) { stopRing(); const c = call.chat; call = null; closeUI(); system(c, "📵 Chiamata persa"); o.chat.unread++; updateBadges(); } }, 45000);
  });
  const matches = s => call && !call.group && kc(s.from) === kc(call.peer) && s.id === call.callId;
  Net.on("CALLACCEPT", p => { const s = sig(p); if (matches(s) && call.state === "calling") connected(); });
  Net.on("CALLREJECT", p => {
    const s = sig(p); if (!matches(s) || call.state !== "calling") return;
    const why = s.extra.toLowerCase(); Sound.beep(300, .5, .08);
    finish(why.includes("occupato") ? `📵 ${call.peer} è occupato in un'altra chiamata` : why.includes("nessuna") ? "📵 Nessuna risposta" : "📵 Chiamata rifiutata", false);
  });
  Net.on("CALLEND", p => {
    const s = sig(p); if (!matches(s)) return;
    if (call.state === "ringing") { const c = call.chat; stopRing(); clearTimeout(ringTimer); call = null; closeUI(); system(c, "📵 Chiamata persa"); if (App.active !== c) { c.unread++; updateBadges(); } }
    else if (call.state === "connected") finish(null, false);
    else finish("📵 Chiamata non riuscita", false);
  });
  Net.on("CALLREACT", p => {
    const s = sig(p); if (!call || s.id !== call.callId) return;
    const who = s.from.includes("/") ? s.from.split("/")[1] : s.from; floatReaction(s.extra.slice(0, 8), who);
  });
  Net.on("VIDSTATE", p => {
    const s = sig(p); if (!call || s.id !== call.callId) return;
    const who = s.from.includes("/") ? s.from.split("/")[1] : s.from;
    const r = remote.get(who) || remote.set(who, { next: 0, frame: null, video: "off", level: 0 }).get(who);
    r.video = /cam|screen/.test(s.extra) ? s.extra.trim() : "off"; if (r.video === "off") r.frame = null; drawUI();
  });
  Net.on("AUDIO", p => {
    const i = p.indexOf("|"), j = p.indexOf("|", i + 1); const from = p.slice(0, i), id = p.slice(i + 1, j);
    if (!call || id !== call.callId) return;
    playAudio(from.includes("/") ? from.split("/")[1] : from, p.slice(j + 1));
  });
  Net.on("VIDEO", p => {
    const i = p.indexOf("|"), j = p.indexOf("|", i + 1); const from = p.slice(0, i), id = p.slice(i + 1, j);
    if (!call || id !== call.callId || call.state !== "connected") return;
    const who = from.includes("/") ? from.split("/")[1] : from;
    const r = remote.get(who) || remote.set(who, { next: 0, frame: null, video: "cam", level: 0 }).get(who);
    r.frame = "data:image/jpeg;base64," + p.slice(j + 1); if (r.video === "off") r.video = "cam";
    const img = ui && ui.querySelector(`img[data-who="${CSS.escape(kc(who))}"]`);
    if (img) img.src = r.frame; else drawUI();
  });

  // ============================================================ finestra della chiamata
  let uiTimer = null, minimized = false;
  function openUI() { minimized = false; if (!ui) { ui = h("div", { class: "callui" }); document.body.append(ui); clearInterval(uiTimer); uiTimer = setInterval(tickUI, 500); } drawUI(); if (App.active) renderBanner(App.active); }
  function closeUI() { clearInterval(uiTimer); if (ui) ui.remove(); ui = null; document.querySelectorAll(".callpill").forEach(e => e.remove()); if (App.active) { renderBanner(App.active); } }
  function minimize() { minimized = true; if (ui) ui.style.display = "none"; const pill = h("div", { class: "callpill", onclick: () => { pill.remove(); minimized = false; ui.style.display = ""; drawUI(); } }, "📞 ", h("span", { id: "callpill-t" }, "")); document.body.append(pill); }
  function tickUI() {
    if (!call) return;
    const t = call.state === "connected" && call.startedAt ? fmtDur(Date.now() - call.startedAt) : "";
    const st = ui && ui.querySelector(".call-time"); if (st && t) st.textContent = t;
    const pill = $("#callpill-t"); if (pill) pill.textContent = (call.chat ? call.chat.name : "") + " · " + (t || "...");
    if (ui) for (const [who, r] of remote) { const tile = ui.querySelector(`[data-tile="${CSS.escape(kc(who))}"]`); if (tile) tile.classList.toggle("talking", Date.now() - (r.heard || 0) < 400 && r.level > .05); }
    const me = ui && ui.querySelector('[data-tile="__me"]'); if (me && media) me.classList.toggle("talking", media.level > .05 && !media.muted);
  }
  function tile(who, label) {
    const r = remote.get(who) || {}; const pic = r.frame && r.video !== "off";
    return h("div", { class: "tile", "data-tile": kc(who) }, pic ? h("img", { src: r.frame, "data-who": kc(who), alt: "" }) : avatar(who), h("span", { class: "tname" }, label || who));
  }
  function drawUI() {
    if (!ui || !call) return;
    if (minimized) return;
    ui.innerHTML = "";
    const c = call.chat; const name = call.group ? c.name : call.peer;
    const statusTxt = call.state === "ringing" ? (call.group ? `${call.caller} ha avviato una ${call.video ? "videochiamata" : "chiamata"} nel gruppo` : `${call.video ? "Videochiamata" : "Chiamata"} in arrivo…`)
      : call.state === "calling" ? "Squilla…" : call.group ? "Chiamata di gruppo" : (remote.get(call.peer)?.video === "cam" ? "Videochiamata" : "Chiamata");
    ui.append(h("div", { class: "call-head" }, h("button", { class: "iconbtn", style: "color:#fff", title: "Riduci", onclick: minimize, html: svg("back") }),
      h("div", { style: "flex:1;min-width:0" }, h("b", {}, name), h("div", { class: "call-sub" }, statusTxt, " ", h("span", { class: "call-time" }, ""))),
      call.state === "connected" && !call.group && App.users ? h("span", { class: "muted", style: "color:#fff" }, "🔒") : null));
    const stage = h("div", { class: "call-stage" });
    if (call.group && call.state === "connected") {
      const gc = groupCalls.get(call.gid); const parts = (gc ? gc.parts : []).filter(n => !isMe(n));
      const grid = h("div", { class: "tiles n" + Math.min(4, parts.length + 1) });
      for (const n of parts) grid.append(tile(n));
      if (!parts.length) grid.append(h("div", { class: "muted", style: "color:#fff;text-align:center;align-self:center" }, "Aspettando gli altri…"));
      stage.append(grid);
    } else if (!call.group && call.state === "connected" && remote.get(call.peer)?.frame && remote.get(call.peer)?.video !== "off") {
      stage.append(h("img", { class: "remote-video", src: remote.get(call.peer).frame, "data-who": kc(call.peer), alt: "" }));
    } else {
      const big = call.group ? chatAvatar(c) : avatar(call.peer); big.classList.add("huge");
      stage.append(h("div", { class: "tile solo", "data-tile": kc(call.peer || "") }, big));
    }
    if (media && media.camOn && media.video) { const me = h("div", { class: "selfview", "data-tile": "__me" }, media.video); media.video.classList.toggle("mirror", media.cam === "user"); stage.append(me); }
    ui.append(stage);
    const bar = h("div", { class: "call-bar" });
    const B = (ic, t, fn, cls) => h("button", { class: "cbtn " + (cls || ""), title: t, onclick: fn }, h("span", {}, ic), h("small", {}, t));
    if (call.state === "ringing") {
      bar.append(B("✖", "Rifiuta", reject, "red"), B("📞", call.group ? "Partecipa" : "Rispondi", () => accept(false), "green"));
      if (call.video) bar.append(B("📹", "Con video", () => accept(true), "green"));
    } else {
      bar.append(B(media && media.muted ? "🔇" : "🎙", media && media.muted ? "Riattiva" : "Muto", () => { if (media) { media.muted = !media.muted; drawUI(); } }),
        B(media && media.camOn ? "📷" : "🚫", media && media.camOn ? "Camera" : "Camera off", toggleCam),
        media && media.camOn ? B("🔄", "Gira", flipCam) : null,
        B("😊", "Reazioni", reactions),
        B("✆", "Chiudi", hangup, "red"));
    }
    ui.append(bar);
    tickUI();
  }
  async function toggleCam() {
    if (!media || !call) return;
    if (media.camOn) {
      media.stream.getVideoTracks().forEach(t => { t.stop(); media.stream.removeTrack(t); });
      media.camOn = false; clearInterval(media.vtimer); media.video = null;
      Net.send(`VIDSTATE|${call.dest}|${call.callId}|off`);
    } else {
      try {
        const s = await navigator.mediaDevices.getUserMedia({ video: { facingMode: media.cam, width: { ideal: 640 }, height: { ideal: 480 } } });
        s.getVideoTracks().forEach(t => media.stream.addTrack(t)); media.camOn = true; attachVideo();
        Net.send(`VIDSTATE|${call.dest}|${call.callId}|cam`);
      } catch (e) { toast("Fotocamera non disponibile", true); }
    }
    drawUI();
  }
  async function flipCam() {
    if (!media || !media.camOn) return;
    media.cam = media.cam === "user" ? "environment" : "user"; Store.set("callCam", media.cam);
    media.stream.getVideoTracks().forEach(t => { t.stop(); media.stream.removeTrack(t); });
    try { const s = await navigator.mediaDevices.getUserMedia({ video: { facingMode: media.cam } }); s.getVideoTracks().forEach(t => media.stream.addTrack(t)); attachVideo(); }
    catch (e) { media.camOn = false; toast("Fotocamera non disponibile", true); }
    drawUI();
  }
  function reactions() {
    const s = sheet("Reazione", h("div", { class: "react-row" }, ...["😂", "❤️", "👍", "👏", "🎉", "😮", "😢", "👻"].map(e => h("button", { onclick: () => {
      s.close(); if (!call) return; Net.send(`CALLREACT|${call.dest}|${call.callId}|${e}`); floatReaction(e, App.me);
    } }, e))));
  }
  function floatReaction(e, who) {
    if (!ui) return;
    const el = h("div", { class: "float-react", style: `left:${10 + Math.random() * 70}%` }, e, h("small", {}, isMe(who) ? "tu" : who));
    ui.append(el); setTimeout(() => el.remove(), 2600);
  }

  return { start, hangupAll, onGroupCall, renderBanner, inCall: () => !!call };
})();
