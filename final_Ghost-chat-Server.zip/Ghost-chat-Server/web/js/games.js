/* Ghost-chat mobile · minigiochi nelle chat a due (Tris, Forza 4, Sasso carta forbici, Impiccato, Quiz,
 * Dama, Battaglia navale, Scacchi) e lavagna condivisa. Regole e protocollo identici alla versione per computer:
 * GAME|dest|id|codice|azione|argomenti... · WB|dest|id|azione|argomenti... */
"use strict";
const Games = (() => {
  const QUIZ_BANK = [["Qual è la capitale dell'Australia?", ["Sydney", "Canberra", "Melbourne", "Perth"], 1], ["Quanti lati ha un esagono?", ["5", "6", "7", "8"], 1], ["Chi ha dipinto la Gioconda?", ["Michelangelo", "Raffaello", "Leonardo da Vinci", "Caravaggio"], 2], ["Qual è il pianeta più grande del Sistema solare?", ["Saturno", "Giove", "Nettuno", "Terra"], 1], ["In che anno è caduto il Muro di Berlino?", ["1987", "1989", "1991", "1993"], 1], ["Qual è il simbolo chimico dell'oro?", ["Ag", "Go", "Au", "Or"], 2], ["Quante sono le regioni italiane?", ["18", "19", "20", "21"], 2], ["Qual è il fiume più lungo d'Italia?", ["Tevere", "Adige", "Po", "Arno"], 2], ["Chi ha scritto la Divina Commedia?", ["Petrarca", "Boccaccio", "Dante Alighieri", "Manzoni"], 2], ["Quanto fa 7 × 8?", ["54", "56", "58", "64"], 1], ["Qual è l'oceano più grande?", ["Atlantico", "Indiano", "Artico", "Pacifico"], 3], ["Che linguaggio usa la Java Virtual Machine come codice intermedio?", ["Assembly", "Bytecode", "C", "JavaScript"], 1], ["Quanti bit ci sono in un byte?", ["4", "8", "16", "32"], 1], ["Qual è la montagna più alta del mondo?", ["K2", "Monte Bianco", "Everest", "Kilimangiaro"], 2], ["In che continente si trova l'Egitto?", ["Asia", "Africa", "Europa", "Oceania"], 1], ["Chi ha formulato la teoria della relatività?", ["Newton", "Einstein", "Galileo", "Bohr"], 1], ["Qual è la capitale del Canada?", ["Toronto", "Vancouver", "Ottawa", "Montréal"], 2], ["Quanti giocatori ha in campo una squadra di calcio?", ["9", "10", "11", "12"], 2], ["Qual è il gas più abbondante nell'atmosfera terrestre?", ["Ossigeno", "Azoto", "Anidride carbonica", "Argon"], 1], ["In che anno è stata scoperta l'America da Colombo?", ["1482", "1492", "1502", "1512"], 1], ["Che cosa significa la sigla CPU?", ["Central Processing Unit", "Computer Power Unit", "Core Program Utility", "Central Program Unit"], 0], ["Qual è l'animale terrestre più veloce?", ["Leone", "Ghepardo", "Antilope", "Cavallo"], 1], ["Quante sono le corde di una chitarra classica?", ["4", "5", "6", "7"], 2], ["Qual è la lingua più parlata come lingua madre al mondo?", ["Inglese", "Spagnolo", "Cinese mandarino", "Hindi"], 2], ["Chi ha composto \"Le quattro stagioni\"?", ["Vivaldi", "Mozart", "Verdi", "Bach"], 0], ["Qual è il numero primo più piccolo?", ["0", "1", "2", "3"], 2], ["In che città si trova la Torre pendente?", ["Firenze", "Pisa", "Siena", "Lucca"], 1], ["Qual è il metallo liquido a temperatura ambiente?", ["Piombo", "Mercurio", "Stagno", "Zinco"], 1], ["Qual è la capitale della Spagna?", ["Barcellona", "Siviglia", "Madrid", "Valencia"], 2], ["Quanto vale pi greco arrotondato a due decimali?", ["3,12", "3,14", "3,16", "3,41"], 1], ["Qual è l'organo più grande del corpo umano?", ["Fegato", "Cervello", "Pelle", "Polmoni"], 2], ["Che porta usa di solito il protocollo HTTPS?", ["21", "80", "443", "8080"], 2], ["Quale di questi NON è un linguaggio di programmazione?", ["Python", "Java", "HTML", "C++"], 2], ["Qual è la stella più vicina alla Terra?", ["Sirio", "Proxima Centauri", "Il Sole", "Betelgeuse"], 2], ["Quanti minuti ci sono in un giorno?", ["1240", "1440", "1640", "2400"], 1], ["In quale paese si trova Machu Picchu?", ["Messico", "Cile", "Perù", "Bolivia"], 2], ["Qual è il simbolo chimico del sodio?", ["So", "Sd", "Na", "S"], 2], ["Chi ha scritto \"I promessi sposi\"?", ["Verga", "Manzoni", "Leopardi", "Foscolo"], 1], ["Qual è la capitale del Giappone?", ["Kyoto", "Osaka", "Tokyo", "Hiroshima"], 2], ["Quante ossa ha di solito un essere umano adulto?", ["186", "206", "226", "246"], 1], ["Qual è il mare che bagna Venezia?", ["Tirreno", "Ionio", "Adriatico", "Ligure"], 2], ["In informatica, che cosa vuol dire RAM?", ["Random Access Memory", "Read And Modify", "Rapid Access Module", "Run All Memory"], 0], ["Qual è il colore che si ottiene mescolando blu e giallo?", ["Viola", "Verde", "Arancione", "Marrone"], 1], ["Quale pianeta è chiamato \"pianeta rosso\"?", ["Venere", "Marte", "Mercurio", "Giove"], 1], ["Chi è l'autore di \"Romeo e Giulietta\"?", ["Dickens", "Shakespeare", "Molière", "Goethe"], 1], ["Quanti anni dura un secolo?", ["10", "50", "100", "1000"], 2], ["Qual è la capitale della Germania?", ["Monaco", "Berlino", "Amburgo", "Francoforte"], 1], ["In che anno è iniziata la Prima guerra mondiale?", ["1912", "1914", "1916", "1918"], 1], ["Che cosa misura un termometro?", ["Pressione", "Umidità", "Temperatura", "Velocità"], 2], ["Qual è il più grande deserto caldo del mondo?", ["Gobi", "Kalahari", "Sahara", "Atacama"], 2], ["Quale numero romano corrisponde a 50?", ["V", "X", "L", "C"], 2], ["Qual è la valuta del Regno Unito?", ["Euro", "Dollaro", "Sterlina", "Franco"], 2], ["Quante zampe ha un ragno?", ["6", "8", "10", "12"], 1], ["Chi ha dipinto \"La notte stellata\"?", ["Monet", "Van Gogh", "Picasso", "Dalí"], 1], ["Qual è la formula chimica dell'acqua?", ["CO2", "H2O", "O2", "NaCl"], 1], ["Qual è la capitale della Francia?", ["Lione", "Marsiglia", "Parigi", "Nizza"], 2], ["In che sistema numerico lavora un computer al livello più basso?", ["Decimale", "Binario", "Esadecimale", "Ottale"], 1], ["Qual è il vulcano attivo più alto d'Europa?", ["Vesuvio", "Stromboli", "Etna", "Hekla"], 2]];
  const NAMES = { ttt: "Tris", c4: "Forza 4", rps: "Sasso, carta, forbici", hm: "Impiccato", dm: "Dama", bn: "Battaglia navale", qz: "Quiz", ch: "Scacchi" };
  const ICONS = { ttt: "⭕", c4: "🔴", rps: "✊", hm: "🪢", dm: "⚫", bn: "🚢", qz: "🧠", ch: "♟" };
  const RPS_NAMES = ["Sasso", "Carta", "Forbici"], RPS_EMOJI = ["✊", "✋", "✌"];

  // ============================================================ motori dei giochi
  class Base {
    constructor(code, id, mine) { this.code = code; this.id = id; this.mine = mine; this.outcome = ""; this.note = ""; this.title = NAMES[code]; this.out = null; }
    isOver() { return !!this.outcome; }
    send(...a) { if (this.out) this.out(a); }
    quit(byMe) { if (this.isOver()) return; this.outcome = byMe ? "THEY_WON" : "I_WON"; this.quitBy = byMe ? "me" : "them"; if (byMe) this.send("quit"); }
    newArgs() { return []; }
    endText(opp) {
      if (this.quitBy === "me") return "Hai abbandonato la partita";
      if (this.quitBy === "them") return opp + " ha abbandonato la partita";
      return this.outcome === "I_WON" ? "🏆 Hai vinto!" : this.outcome === "THEY_WON" ? "Ha vinto " + opp : this.outcome === "DRAW" ? "🤝 Pareggio" : "";
    }
  }

  // ---- Tris e Forza 4 (GameState del computer)
  class Grid extends Base {
    constructor(code, id, mine) { super(code, id, mine); this.board = new Array(code === "ttt" ? 9 : 42).fill(0); this.moves = 0; this.win = null; }
    me() { return this.mine ? 1 : 2; }
    isMyTurn() { return !this.isOver() && (this.moves % 2 === 0 ? 1 : 2) === this.me(); }
    move(byMe, index, num) {
      if (this.isOver() || num !== this.moves) return false;
      const player = byMe ? this.me() : 3 - this.me(); if (player !== (this.moves % 2 === 0 ? 1 : 2)) return false;
      let cell;
      if (this.code === "ttt") { if (index < 0 || index >= 9 || this.board[index]) return false; cell = index; }
      else { if (index < 0 || index >= 7) return false; cell = -1; for (let r = 5; r >= 0; r--) if (!this.board[r * 7 + index]) { cell = r * 7 + index; break; } if (cell < 0) return false; }
      this.board[cell] = player; this.moves++; this.last = cell;
      const line = this.code === "ttt" ? this.tttLine(player) : this.c4Line(player, cell);
      if (line) { this.win = line; this.outcome = player === this.me() ? "I_WON" : "THEY_WON"; }
      else if (this.moves >= this.board.length) this.outcome = "DRAW";
      return true;
    }
    play(index) { const n = this.moves; if (this.move(true, index, n)) { this.send("move", index, n); return true; } return false; }
    tttLine(p) { for (const l of [[0, 1, 2], [3, 4, 5], [6, 7, 8], [0, 3, 6], [1, 4, 7], [2, 5, 8], [0, 4, 8], [2, 4, 6]]) if (l.every(i => this.board[i] === p)) return l; return null; }
    c4Line(p, cell) {
      const r0 = Math.floor(cell / 7), c0 = cell % 7;
      for (const [dr, dc] of [[0, 1], [1, 0], [1, 1], [1, -1]]) {
        const cells = [cell];
        for (const s of [-1, 1]) { let r = r0 + dr * s, c = c0 + dc * s; while (r >= 0 && r < 6 && c >= 0 && c < 7 && this.board[r * 7 + c] === p) { cells.push(r * 7 + c); r += dr * s; c += dc * s; } }
        if (cells.length >= 4) return cells;
      }
      return null;
    }
    onRemote(a, args) { if (a === "move") this.move(false, parseInt(args[0], 10), parseInt(args[1], 10)); else if (a === "quit") this.quit(false); }
    status(opp) { return this.isOver() ? this.endText(opp) : this.isMyTurn() ? "Tocca a te" : "Tocca a " + opp; }
  }

  // ---- Sasso, carta, forbici al meglio di 3 (con impegno crittografico: nessuno puo' barare)
  class Rps extends Base {
    constructor(id, mine) { super("rps", id, mine); this.round = 1; this.my = 0; this.their = 0; this.myChoice = -1; this.theirChoice = -1; this.theirCommit = null; this.salt = null; this.revealed = false; this.lastText = ""; }
    isMyTurn() { return !this.isOver() && this.myChoice < 0; }
    async choose(ch) {
      if (this.isOver() || this.myChoice >= 0 || ch < 0 || ch > 2) return;
      this.myChoice = ch; this.salt = randHex(16); this.revealed = false;
      const round = this.round; this.send("commit", round, await sha256hex(ch + ":" + this.salt));
      this.maybeReveal();
    }
    maybeReveal() { if (this.myChoice >= 0 && this.theirCommit && !this.revealed) { this.revealed = true; this.send("reveal", this.round, this.myChoice, this.salt); } }
    async onRemote(a, args) {
      if (a === "quit") return this.quit(false);
      const r = parseInt(args[0], 10);
      if (a === "commit") { if (this.isOver() || r !== this.round || this.theirCommit || !/^[0-9a-f]{64}$/.test(args[1] || "")) return; this.theirCommit = args[1]; this.maybeReveal(); }
      else if (a === "reveal") {
        const ch = parseInt(args[1], 10), salt = args[2] || "";
        if (r !== this.round || !this.theirCommit || ch < 0 || ch > 2) return;
        if (await sha256hex(ch + ":" + salt) !== this.theirCommit) { this.note = "⚠ La mossa rivelata non corrisponde: l'altro ha barato!"; return; }
        this.theirChoice = ch; this.finishRound();
      }
    }
    finishRound() {
      if (this.myChoice < 0 || this.theirChoice < 0) return;
      const diff = (this.myChoice - this.theirChoice + 3) % 3;
      const pair = `${RPS_EMOJI[this.myChoice]} ${RPS_NAMES[this.myChoice]} contro ${RPS_EMOJI[this.theirChoice]} ${RPS_NAMES[this.theirChoice]}`;
      if (diff === 0) this.lastText = `Round ${this.round}: pareggio (${pair})`;
      else if (diff === 1) { this.my++; this.lastText = `Round ${this.round}: hai vinto (${pair})`; }
      else { this.their++; this.lastText = `Round ${this.round}: hai perso (${pair})`; }
      if (this.my >= 2) this.outcome = "I_WON"; else if (this.their >= 2) this.outcome = "THEY_WON";
      else { this.round++; this.myChoice = -1; this.theirChoice = -1; this.theirCommit = null; this.salt = null; this.revealed = false; }
    }
    status(opp) {
      if (this.isOver()) return this.endText(opp);
      if (this.myChoice < 0) return `Round ${this.round}: scegli!` + (this.theirCommit ? ` (${opp} ha già scelto)` : "");
      return `Round ${this.round}: in attesa di ${opp}...`;
    }
  }

  // ---- Impiccato
  const normWord = raw => { const w = String(raw || "").trim().normalize("NFD").replace(/\p{M}/gu, "").toUpperCase(); return /^[A-Z]{3,16}$/.test(w) ? w : null; };
  const cleanHint = s => String(s || "").replace(/[\x00-\x1f|]/g, " ").trim().slice(0, 40);
  class Hangman extends Base {
    constructor(id, mine, word, salt, length, hash, hint) { super("hm", id, mine); this.word = word; this.salt = salt; this.length = length; this.hash = hash; this.hint = hint || ""; this.revealed = new Array(length).fill(""); this.tried = []; this.misses = 0; this.waiting = false; }
    static async challenger(id, raw, hint) { const w = normWord(raw); if (!w) return null; const s = randHex(12); return new Hangman(id, true, w, s, w.length, await sha256hex(w + "|" + s), cleanHint(hint)); }
    static received(id, args) { const len = parseInt(args[0], 10); if (!(len >= 3 && len <= 16) || (args[1] || "").trim().length < 16) return null; return new Hangman(id, false, null, null, len, args[1].trim(), cleanHint(args[2])); }
    newArgs() { return [this.length, this.hash, this.hint]; }
    canGuess() { return !this.mine && !this.isOver() && !this.waiting; }
    isMyTurn() { return this.canGuess(); }
    guess(l) { l = l.toUpperCase(); if (!this.canGuess() || l < "A" || l > "Z" || this.tried.includes(l)) return false; this.waiting = true; this.send("g", l); return true; }
    apply(l, positions) {
      this.tried.push(l); let hit = false;
      for (const p of String(positions || "").split(",")) { const i = parseInt(p, 10); if (i >= 0 && i < this.length) { this.revealed[i] = l; hit = true; } }
      if (!hit) this.misses++;
      if (this.revealed.every(Boolean)) this.outcome = this.mine ? "THEY_WON" : "I_WON";
      else if (this.misses >= 6) this.outcome = this.mine ? "I_WON" : "THEY_WON";
    }
    async onRemote(a, args) {
      if (a === "g") {
        if (!this.mine || this.isOver() || (args[0] || "").length !== 1) return;
        const l = args[0].toUpperCase(); if (l < "A" || l > "Z" || this.tried.includes(l)) return;
        const pos = []; for (let i = 0; i < this.length; i++) if (this.word[i] === l) pos.push(i);
        this.apply(l, pos.join(",")); this.send("r", l, pos.join(","));
        if (this.isOver()) this.send("reveal", this.word, this.salt);
      } else if (a === "r") {
        if (this.mine || this.isOver() || !args[0]) return;
        const l = args[0][0].toUpperCase(); this.waiting = false; if (this.tried.includes(l)) return; this.apply(l, args[1] || "");
      } else if (a === "reveal") {
        if (this.mine || args.length < 2) return;
        const w = args[0].trim().toUpperCase();
        let ok = w.length === this.length && await sha256hex(w + "|" + args[1].trim()) === this.hash;
        for (let i = 0; ok && i < this.length; i++) ok = !this.revealed[i] || this.revealed[i] === w[i];
        for (const t of this.tried) { const said = this.revealed.includes(t); ok = ok && said === w.includes(t); }
        this.word = w; this.salt = args[1].trim();
        this.note = ok ? "✔ Parola verificata" : "⚠ La parola rivelata non corrisponde: l'altro ha barato!";
      } else if (a === "quit") this.quit(false);
    }
    quit(byMe) { const was = this.isOver(); super.quit(byMe); if (!was && this.mine && this.word) this.send("reveal", this.word, this.salt); }
    status(opp) {
      if (this.isOver()) return this.endText(opp) + (this.mine || !this.word ? "" : " · era " + this.word);
      if (this.mine) return `${opp} sta indovinando… (${this.misses}/6 errori)`;
      return this.waiting ? "Controllo della lettera…" : `Scegli una lettera (${this.misses}/6 errori)`;
    }
  }

  // ---- Quiz (5 domande, stesso elenco del computer)
  class Quiz extends Base {
    constructor(id, mine, qs) { super("qz", id, mine); this.qs = qs; this.myAns = [-1, -1, -1, -1, -1]; this.cur = 0; this.started = 0; this.myMs = -1; this.theirAns = null; this.theirMs = -1; }
    static challenger(id) { const all = QUIZ_BANK.map((_, i) => i); for (let i = all.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [all[i], all[j]] = [all[j], all[i]]; } return new Quiz(id, true, all.slice(0, 5)); }
    static received(id, args) { const p = String(args[0] || "").split(","); if (p.length !== 5) return null; const q = p.map(x => parseInt(x, 10)); if (q.some(x => !(x >= 0 && x < QUIZ_BANK.length))) return null; return new Quiz(id, false, q); }
    newArgs() { return [this.qs.join(",")]; }
    isMyTurn() { return !this.isOver() && this.myMs < 0; }
    answer(ch) {
      if (this.myMs >= 0 || this.isOver() || ch < 0 || ch > 3) return;
      if (!this.started) this.started = Date.now();
      this.myAns[this.cur] = ch; this.cur++;
      if (this.cur >= 5) { this.myMs = Date.now() - this.started; this.send("done", this.myAns.join(","), this.myMs); this.decide(); }
    }
    score(a) { return a ? a.reduce((s, x, i) => s + (x === QUIZ_BANK[this.qs[i]][2] ? 1 : 0), 0) : 0; }
    decide() {
      if (this.myMs < 0 || this.theirMs < 0 || this.isOver()) return;
      const a = this.score(this.myAns), b = this.score(this.theirAns);
      this.outcome = a !== b ? (a > b ? "I_WON" : "THEY_WON") : this.myMs !== this.theirMs ? (this.myMs < this.theirMs ? "I_WON" : "THEY_WON") : "DRAW";
    }
    onRemote(a, args) {
      if (a === "quit") return this.quit(false);
      if (a !== "done" || this.theirMs >= 0 || args.length < 2) return;
      const p = args[0].split(","); if (p.length !== 5) return;
      this.theirAns = p.map(x => parseInt(x, 10)); const ms = parseInt(args[1], 10); this.theirMs = ms >= 0 ? ms : Number.MAX_SAFE_INTEGER; this.decide();
    }
    status(opp) {
      if (this.isOver()) return this.endText(opp) + ` · ${this.score(this.myAns)} a ${this.score(this.theirAns)}`;
      if (this.myMs < 0) return `Domanda ${this.cur + 1} di 5`;
      return `Hai finito: ${this.score(this.myAns)}/5 · in attesa di ${opp}…`;
    }
  }

  // ---- Dama italiana-semplificata (come sul computer: presa obbligatoria, catene, la pedina non mangia la dama)
  const inB = (r, c) => r >= 0 && r < 8 && c >= 0 && c < 8;
  class Checkers extends Base {
    constructor(id, mine) { super("dm", id, mine); this.board = new Array(64).fill(0); this.turn = 1; for (let r = 0; r < 8; r++) for (let c = 0; c < 8; c++) if ((r + c) % 2 === 1) { if (r < 3) this.board[r * 8 + c] = -1; else if (r > 4) this.board[r * 8 + c] = 1; } }
    me() { return this.mine ? 1 : -1; }
    isMyTurn() { return !this.isOver() && this.turn === this.me(); }
    static dirs(king, side) { return king ? [[-1, -1], [-1, 1], [1, -1], [1, 1]] : side === 1 ? [[-1, -1], [-1, 1]] : [[1, -1], [1, 1]]; }
    static legal(b, side) {
      const caps = [], quiet = [];
      for (let sq = 0; sq < 64; sq++) {
        if (b[sq] * side <= 0) continue;
        const king = Math.abs(b[sq]) === 2;
        Checkers.captures(b, sq, side, king, [sq], caps);
        const r = sq >> 3, c = sq & 7;
        for (const [dr, dc] of Checkers.dirs(king, side)) { const nr = r + dr, nc = c + dc; if (inB(nr, nc) && b[nr * 8 + nc] === 0) quiet.push([sq, nr * 8 + nc]); }
      }
      return caps.length ? caps : quiet;
    }
    static captures(b, sq, side, king, path, out) {
      const r = sq >> 3, c = sq & 7; let more = false;
      for (const [dr, dc] of Checkers.dirs(king, side)) {
        const lr = r + 2 * dr, lc = c + 2 * dc; if (!inB(lr, lc)) continue;
        const mid = (r + dr) * 8 + c + dc, land = lr * 8 + lc;
        if (b[mid] * side >= 0 || b[land] !== 0) continue;
        if (!king && Math.abs(b[mid]) === 2) continue;
        more = true;
        const nb = b.slice(); nb[land] = nb[sq]; nb[sq] = 0; nb[mid] = 0; path.push(land);
        if (!king && (side === 1 ? lr === 0 : lr === 7)) out.push(path.slice()); else Checkers.captures(nb, land, side, king, path, out);
        path.pop();
      }
      if (!more && path.length > 1) out.push(path.slice());
    }
    legalMoves() { return Checkers.legal(this.board, this.turn); }
    apply(path) {
      if (!this.legalMoves().some(m => m.length === path.length && m.every((x, i) => x === path[i]))) return false;
      let piece = this.board[path[0]]; this.board[path[0]] = 0;
      for (let i = 1; i < path.length; i++) { const a = path[i - 1], z = path[i]; if (Math.abs((a >> 3) - (z >> 3)) === 2) this.board[(((a >> 3) + (z >> 3)) / 2) * 8 + ((a & 7) + (z & 7)) / 2] = 0; }
      const end = path[path.length - 1];
      if (Math.abs(piece) === 1 && (piece === 1 ? end >> 3 === 0 : end >> 3 === 7)) piece *= 2;
      this.board[end] = piece; this.last = path.slice(); this.turn = -this.turn;
      if (!Checkers.legal(this.board, this.turn).length) this.outcome = this.turn === this.me() ? "THEY_WON" : "I_WON";
      return true;
    }
    play(path) { if (!this.isMyTurn() || !this.apply(path)) return false; this.send("m", path.join(",")); return true; }
    onRemote(a, args) {
      if (a === "quit") return this.quit(false);
      if (a !== "m" || !args[0] || this.isOver() || this.turn === this.me()) return;
      const p = args[0].split(",").map(x => parseInt(x, 10)); if (p.some(x => !(x >= 0 && x <= 63))) return; this.apply(p);
    }
    count(side) { return this.board.filter(v => v * side > 0).length; }
    status(opp) {
      if (this.isOver()) return this.endText(opp);
      const must = this.legalMoves().some(m => Math.abs((m[0] >> 3) - (m[1] >> 3)) === 2);
      return (this.isMyTurn() ? "Tocca a te" : "Tocca a " + opp) + (this.isMyTurn() && must ? " · presa obbligatoria" : "");
    }
  }

  // ---- Battaglia navale (flotta 5,4,3,3,2 · navi che non si toccano · flotta verificata a fine partita)
  const N = 10, FLEET = [5, 4, 3, 3, 2];
  class Battleship extends Base {
    constructor(id, mine) { super("bn", id, mine); this.layout = []; this.hitOnMe = new Array(100).fill(false); this.shotOnMe = new Array(100).fill(false); this.enemy = new Array(100).fill(0); this.meReady = false; this.themReady = false; this.theirHash = null; this.turn = 1; this.waiting = false; this.lastShotOnMe = -1; this.lastMyShot = -1; this.shuffle(); }
    me() { return this.mine ? 1 : -1; }
    isSetup() { return !(this.meReady && this.themReady) && !this.isOver(); }
    isMyTurn() { if (this.isOver()) return false; if (!this.meReady) return true; return this.themReady && this.turn === this.me() && !this.waiting; }
    shuffle() {
      if (this.meReady) return;
      for (;;) {
        const l = new Array(100).fill(0); let ok = true;
        for (let s = 0; s < FLEET.length && ok; s++) {
          let placed = false;
          for (let t = 0; t < 200 && !placed; t++) {
            const horiz = Math.random() < .5, len = FLEET[s];
            const r = Math.floor(Math.random() * (horiz ? N : N - len + 1)), c = Math.floor(Math.random() * (horiz ? N - len + 1 : N));
            let free = true;
            for (let k = 0; k < len && free; k++) { const rr = r + (horiz ? 0 : k), cc = c + (horiz ? k : 0); for (let dr = -1; dr <= 1 && free; dr++) for (let dc = -1; dc <= 1 && free; dc++) { const ar = rr + dr, ac = cc + dc; if (ar >= 0 && ar < N && ac >= 0 && ac < N && l[ar * N + ac]) free = false; } }
            if (free) { for (let k = 0; k < len; k++) l[(r + (horiz ? 0 : k)) * N + c + (horiz ? k : 0)] = s + 1; placed = true; }
          }
          ok = placed;
        }
        if (ok) { this.layout = l; this.salt = randHex(12); return; }
      }
    }
    async ready() { if (this.meReady || this.isOver()) return; this.meReady = true; this.send("ready", await sha256hex(this.layout.join("") + "|" + this.salt)); }
    shoot(cell) { if (!this.isMyTurn() || !this.meReady || cell < 0 || cell >= 100 || this.enemy[cell]) return false; this.waiting = true; this.lastMyShot = cell; this.send("s", cell); return true; }
    allSunk() { return this.layout.every((v, i) => !v || this.hitOnMe[i]); }
    async onRemote(a, args) {
      if (a === "ready") { if (!this.themReady && args.length) { this.themReady = true; this.theirHash = args[0].trim(); } }
      else if (a === "s") {
        const cell = parseInt(args[0], 10);
        if (this.isOver() || !this.meReady || !this.themReady || this.turn === this.me() || !(cell >= 0 && cell < 100) || this.shotOnMe[cell]) return;
        this.shotOnMe[cell] = true; this.lastShotOnMe = cell;
        const ship = this.layout[cell]; let code = 0; const sunk = [];
        if (ship) { this.hitOnMe[cell] = true; code = 1; if (this.layout.every((v, i) => v !== ship || this.hitOnMe[i])) { code = 2; this.layout.forEach((v, i) => { if (v === ship) sunk.push(i); }); } }
        const all = this.allSunk();
        this.send("res", cell, code, sunk.join(","), all ? "1" : "0");
        this.turn = this.me();
        if (all) { this.outcome = "THEY_WON"; this.send("lay", this.layout.join(""), this.salt); }
      } else if (a === "res") {
        const cell = parseInt(args[0], 10); if (!this.waiting || cell !== this.lastMyShot || cell < 0) return;
        this.waiting = false; const code = parseInt(args[1], 10) || 0;
        this.enemy[cell] = code === 0 ? 1 : 2;
        if (code === 2 && args[2]) for (const p of args[2].split(",")) { const i = parseInt(p, 10); if (i >= 0 && i < 100) this.enemy[i] = 3; }
        this.turn = -this.me();
        if ((args[3] || "").trim() === "1") { this.outcome = "I_WON"; this.send("lay", this.layout.join(""), this.salt); }
      } else if (a === "lay") {
        if (args.length < 2 || !this.theirHash) return;
        const l = args[0].trim(); let ok = l.length === 100 && await sha256hex(l + "|" + args[1].trim()) === this.theirHash;
        for (let i = 0; ok && i < 100; i++) { const v = l.charCodeAt(i) - 48; if (this.enemy[i] === 1 && v !== 0) ok = false; if (this.enemy[i] >= 2 && v === 0) ok = false; }
        this.note = ok ? "✔ Flotta dell'avversario verificata" : "⚠ La flotta rivelata non corrisponde: l'altro ha barato!";
      } else if (a === "quit") this.quit(false);
    }
    sunkShips() { const cells = this.enemy.filter(v => v === 3).length; let n = 0, acc = 0; for (const len of FLEET) { acc += len; if (cells >= acc) n++; } return n; }
    status(opp) {
      if (this.isOver()) return this.endText(opp);
      if (!this.meReady) return "Disponi la flotta e premi Pronto";
      if (!this.themReady) return `In attesa che ${opp} sia pronto…`;
      if (this.waiting) return "Fuoco!…";
      return this.turn === this.me() ? "Tocca a te: spara sulla griglia dell'avversario" : "Tocca a " + opp;
    }
  }

  // ---- Scacchi (regole complete: arrocco, en passant, promozione, scacco matto, stallo, 50 mosse, patta)
  const P = 1, KN = 2, B = 3, R = 4, Q = 5, K = 6;
  const sqName = s => String.fromCharCode(97 + (s & 7)) + (8 - (s >> 3));
  const parseSq = s => { if (!s || s.length !== 2) return -1; const c = s.charCodeAt(0) - 97, r = 56 - s.charCodeAt(1); return inB(r, c) ? r * 8 + c : -1; };
  class Chess extends Base {
    constructor(id, mine) {
      super("ch", id, mine); this.board = new Array(64).fill(0); this.turn = 1; this.wk = this.wq = this.bk = this.bq = true; this.ep = -1; this.half = 0; this.last = null; this.san = ""; this.drawThem = false; this.drawMe = false; this.reason = "";
      const back = [R, KN, B, Q, K, B, KN, R]; for (let c = 0; c < 8; c++) { this.board[c] = -back[c]; this.board[8 + c] = -P; this.board[48 + c] = P; this.board[56 + c] = back[c]; }
    }
    me() { return this.mine ? 1 : -1; }
    isMyTurn() { return !this.isOver() && this.turn === this.me(); }
    inCheck() { return Chess.inCheck(this.board, this.turn); }
    legalMoves() { return this.pseudo(this.turn).filter(m => { const b = this.board.slice(); Chess.make(b, m, this.turn, this.ep); return !Chess.inCheck(b, this.turn); }); }
    pseudo(side) {
      const out = [], b = this.board;
      for (let sq = 0; sq < 64; sq++) {
        const p = b[sq] * side; if (p <= 0) continue; const r = sq >> 3, c = sq & 7;
        if (p === P) {
          const dir = side === 1 ? -1 : 1, start = side === 1 ? 6 : 1, last = side === 1 ? 0 : 7, nr = r + dir;
          const addP = (to, promo) => { if (promo) for (const x of [Q, R, B, KN]) out.push([sq, to, x]); else out.push([sq, to, 0]); };
          if (inB(nr, c) && b[nr * 8 + c] === 0) { addP(nr * 8 + c, nr === last); if (r === start && b[(r + 2 * dir) * 8 + c] === 0) out.push([sq, (r + 2 * dir) * 8 + c, 0]); }
          for (const dc of [-1, 1]) { const nc = c + dc; if (!inB(nr, nc)) continue; const t = nr * 8 + nc; if (b[t] * side < 0 || t === this.ep) addP(t, nr === last); }
        } else if (p === KN) this.jumps(out, sq, side, [[1, 2], [2, 1], [-1, 2], [-2, 1], [1, -2], [2, -1], [-1, -2], [-2, -1]]);
        else if (p === B) this.slides(out, sq, side, [[1, 1], [1, -1], [-1, 1], [-1, -1]]);
        else if (p === R) this.slides(out, sq, side, [[1, 0], [-1, 0], [0, 1], [0, -1]]);
        else if (p === Q) this.slides(out, sq, side, [[1, 1], [1, -1], [-1, 1], [-1, -1], [1, 0], [-1, 0], [0, 1], [0, -1]]);
        else if (p === K) {
          this.jumps(out, sq, side, [[1, 1], [1, -1], [-1, 1], [-1, -1], [1, 0], [-1, 0], [0, 1], [0, -1]]);
          const home = side === 1 ? 60 : 4;
          if (sq === home && !Chess.attacked(b, home, -side)) {
            const ks = side === 1 ? this.wk : this.bk, qs = side === 1 ? this.wq : this.bq;
            if (ks && !b[home + 1] && !b[home + 2] && b[home + 3] === R * side && !Chess.attacked(b, home + 1, -side) && !Chess.attacked(b, home + 2, -side)) out.push([home, home + 2, 0]);
            if (qs && !b[home - 1] && !b[home - 2] && !b[home - 3] && b[home - 4] === R * side && !Chess.attacked(b, home - 1, -side) && !Chess.attacked(b, home - 2, -side)) out.push([home, home - 2, 0]);
          }
        }
      }
      return out;
    }
    jumps(out, sq, side, d) { const r = sq >> 3, c = sq & 7; for (const [dr, dc] of d) { const nr = r + dr, nc = c + dc; if (inB(nr, nc) && this.board[nr * 8 + nc] * side <= 0) out.push([sq, nr * 8 + nc, 0]); } }
    slides(out, sq, side, d) {
      const r = sq >> 3, c = sq & 7;
      for (const [dr, dc] of d) { let nr = r + dr, nc = c + dc; while (inB(nr, nc)) { const t = this.board[nr * 8 + nc]; if (t * side > 0) break; out.push([sq, nr * 8 + nc, 0]); if (t) break; nr += dr; nc += dc; } }
    }
    static attacked(b, sq, by) {
      const r = sq >> 3, c = sq & 7, pr = r - (by === 1 ? -1 : 1);
      for (const dc of [-1, 1]) if (inB(pr, c + dc) && b[pr * 8 + c + dc] === P * by) return true;
      for (const [dr, dc] of [[1, 2], [2, 1], [-1, 2], [-2, 1], [1, -2], [2, -1], [-1, -2], [-2, -1]]) if (inB(r + dr, c + dc) && b[(r + dr) * 8 + c + dc] === KN * by) return true;
      for (const [dr, dc] of [[1, 1], [1, -1], [-1, 1], [-1, -1], [1, 0], [-1, 0], [0, 1], [0, -1]]) {
        if (inB(r + dr, c + dc) && b[(r + dr) * 8 + c + dc] === K * by) return true;
        const diag = dr !== 0 && dc !== 0; let nr = r + dr, nc = c + dc;
        while (inB(nr, nc)) { const t = b[nr * 8 + nc]; if (t) { if (t === Q * by || t === (diag ? B : R) * by) return true; break; } nr += dr; nc += dc; }
      }
      return false;
    }
    static inCheck(b, side) { const k = b.indexOf(K * side); return k < 0 ? true : Chess.attacked(b, k, -side); }
    static make(b, m, side, ep) {
      const piece = b[m[0]]; b[m[0]] = 0;
      if (Math.abs(piece) === P && m[1] === ep) b[m[1] + (side === 1 ? 8 : -8)] = 0;
      if (Math.abs(piece) === K && Math.abs(m[1] - m[0]) === 2) { if (m[1] > m[0]) { b[m[0] + 1] = b[m[0] + 3]; b[m[0] + 3] = 0; } else { b[m[0] - 1] = b[m[0] - 4]; b[m[0] - 4] = 0; } }
      b[m[1]] = m[2] ? m[2] * side : piece;
    }
    isPromotion(from, to) { return this.legalMoves().some(m => m[0] === from && m[1] === to && m[2]); }
    play(from, to, promo) {
      if (!this.isMyTurn()) return false;
      const m = this.legalMoves().find(x => x[0] === from && x[1] === to && (x[2] === promo || (!promo && (x[2] === Q || !x[2]))));
      if (!m) return false;
      this.apply(m); this.send("m", sqName(from) + sqName(to) + (m[2] ? " pnbrqk"[m[2]] : "")); return true;
    }
    apply(m) {
      const piece = this.board[m[0]]; const capture = this.board[m[1]] !== 0 || (Math.abs(piece) === P && m[1] === this.ep);
      this.san = this.sanOf(m, piece, capture);
      Chess.make(this.board, m, this.turn, this.ep);
      if (piece === K) this.wk = this.wq = false; else if (piece === -K) this.bk = this.bq = false;
      for (const sq of [m[0], m[1]]) { if (sq === 63) this.wk = false; else if (sq === 56) this.wq = false; else if (sq === 7) this.bk = false; else if (sq === 0) this.bq = false; }
      this.ep = Math.abs(piece) === P && Math.abs(m[1] - m[0]) === 16 ? (m[0] + m[1]) / 2 : -1;
      this.half = Math.abs(piece) === P || capture ? 0 : this.half + 1;
      this.last = [m[0], m[1]]; this.turn = -this.turn; this.drawMe = this.drawThem = false;
      const next = this.legalMoves();
      if (!next.length) { if (Chess.inCheck(this.board, this.turn)) { this.outcome = this.turn === this.me() ? "THEY_WON" : "I_WON"; this.reason = "scacco matto"; this.san += "#"; } else { this.outcome = "DRAW"; this.reason = "stallo"; } }
      else if (this.insufficient()) { this.outcome = "DRAW"; this.reason = "materiale insufficiente"; }
      else if (this.half >= 100) { this.outcome = "DRAW"; this.reason = "regola delle 50 mosse"; }
      else if (Chess.inCheck(this.board, this.turn)) this.san += "+";
    }
    sanOf(m, piece, capture) {
      const p = Math.abs(piece);
      if (p === K && Math.abs(m[1] - m[0]) === 2) return m[1] > m[0] ? "O-O" : "O-O-O";
      const L = " PCATDR";
      let s = p === P ? (capture ? sqName(m[0])[0] : "") : L[p];
      s += (capture ? "x" : "") + sqName(m[1]); if (m[2]) s += "=" + L[m[2]]; return s;
    }
    insufficient() { let minor = 0; for (const v of this.board) { const p = Math.abs(v); if (p === P || p === R || p === Q) return false; if (p === KN || p === B) minor++; } return minor <= 1; }
    offerDraw() { if (this.isOver() || this.drawMe) return; if (this.drawThem) { this.outcome = "DRAW"; this.reason = "patta concordata"; this.send("draw!"); return; } this.drawMe = true; this.send("draw?"); }
    onRemote(a, args) {
      if (a === "m") {
        if (this.isOver() || this.turn === this.me() || !args[0]) return;
        const s = args[0].trim().toLowerCase(); if (s.length < 4) return;
        const from = parseSq(s.slice(0, 2)), to = parseSq(s.slice(2, 4)), promo = s.length > 4 ? " pnbrqk".indexOf(s[4]) : 0;
        if (from < 0 || to < 0 || promo < 0) return;
        const m = this.legalMoves().find(x => x[0] === from && x[1] === to && x[2] === promo); if (m) this.apply(m);
      } else if (a === "draw?") { if (!this.isOver()) this.drawThem = true; }
      else if (a === "draw!") { if (this.drawMe && !this.isOver()) { this.outcome = "DRAW"; this.reason = "patta concordata"; } }
      else if (a === "quit") { this.quit(false); this.reason = "abbandono"; }
    }
    quit(byMe) { super.quit(byMe); this.reason = "abbandono"; }
    status(opp) {
      if (this.isOver()) return this.endText(opp) + (this.reason ? ` (${this.reason})` : "");
      return (this.isMyTurn() ? "Tocca a te" : "Tocca a " + opp) + (this.inCheck() ? " · SCACCO!" : "") + " · sei il " + (this.mine ? "bianco" : "nero") + (this.san ? " · ultima: " + this.san : "");
    }
  }

  function create(code, id, mine) {
    if (code === "ttt" || code === "c4") return new Grid(code, id, mine);
    if (code === "rps") return new Rps(id, mine);
    if (code === "dm") return new Checkers(id, mine);
    if (code === "bn") return new Battleship(id, mine);
    if (code === "ch") return new Chess(id, mine);
    return null;
  }

  // ============================================================ invio e ricezione
  function wire(c, m) {
    const g = m.game;
    g.out = a => { if (!Net.send(["GAME", destOf(c), g.id, g.code, ...a.map(x => String(x))].join("|"))) toast("Non sei connesso al server: mossa non inviata", true); };
  }
  async function challenge(c, code) {
    if (c.group || c.bc) return toast("I giochi si fanno nelle chat a due", true);
    if (!(await checkSend(c))) return;
    const id = newId(); let g;
    if (code === "hm") {
      const word = await ask("Impiccato", `Scegli la parola segreta (3-16 lettere, senza spazi né numeri): ${c.name} dovrà indovinarla una lettera alla volta.`, "Parola segreta", "", "Avanti");
      if (word == null) return; if (!normWord(word)) return toast("La parola deve avere da 3 a 16 lettere (A-Z)", true);
      const hint = await ask("Impiccato", "Un indizio facoltativo (es. \"animale\", \"film\").", "Indizio (facoltativo)", "", "Lancia la sfida"); if (hint == null) return;
      g = await Hangman.challenger(id, word, hint);
    } else if (code === "qz") g = Quiz.challenger(id);
    else g = create(code, id, true);
    if (!g) return;
    const args = code === "ttt" || code === "c4" || code === "rps" ? [""] : g.newArgs();
    if (!Net.send(["GAME", destOf(c), id, code, "new", ...args.map(String)].join("|"))) return toast("Non sei connesso al server", true);
    const m = { id, dir: "out", time: Date.now(), game: g, state: "sent" }; wire(c, m);
    addMsg(c, m);
  }
  Net.on("GAME", async p => {
    const f = p.split("|"); const o = origin(f[0]); if (!o.chat || o.group) return;
    const c = o.chat, id = (f[1] || "").trim(), code = (f[2] || "").trim(), action = (f[3] || "").trim(), args = f.slice(4);
    if (!id || !NAMES[code]) return;
    let m = findMsg(c, id);
    if (action === "new") {
      if (m) return;
      let g; try { g = code === "hm" ? Hangman.received(id, args) : code === "qz" ? Quiz.received(id, args) : create(code, id, false); } catch (e) { g = null; }
      if (!g) return;
      m = { id, dir: "in", time: Date.now(), game: g }; wire(c, m);
      addMsg(c, m); Net.send(`ACK|${o.nick}|${id}|D|${Date.now()}`);
      return;
    }
    if (!m || !m.game || m.game.code !== code) return;
    const g = m.game; const was = g.isMyTurn();
    await g.onRemote(action, args);
    c.last = Date.now();
    refreshMsg(c, m);
    if (App.active !== c && g.isMyTurn() && !was) { c.unread++; renderChats(); updateBadges(); }
  });

  // ============================================================ disegno delle partite
  function render(c, m) {
    const g = m.game; const opp = c.name;
    const box = h("div", { class: "game g-" + g.code, onclick: e => e.stopPropagation() });
    const redraw = () => refreshMsg(c, m);
    box.append(h("div", { class: "g-title" }, ICONS[g.code] + " " + g.title, h("small", {}, g.mine ? " · hai sfidato " + opp : " · sfida di " + opp)));
    const body = h("div", { class: "g-body" }); box.append(body);
    try { DRAW[g.code](g, body, redraw, opp); } catch (e) { body.append(h("div", { class: "muted" }, "Partita non disponibile")); console.error(e); }
    box.append(h("div", { class: "g-status" + (g.isMyTurn() ? " myturn" : "") }, g.status(opp)));
    if (g.note) box.append(h("div", { class: "g-note" }, g.note));
    if (!g.isOver()) box.append(h("div", { class: "g-tools" },
      g.code === "ch" ? h("button", { class: "btn small", disabled: g.drawMe, onclick: () => { g.offerDraw(); redraw(); } }, g.drawThem ? "Accetta la patta" : g.drawMe ? "Patta proposta" : "Proponi patta") : null,
      h("button", { class: "btn small", onclick: async () => { if (await confirmBox("Abbandona", "Vuoi abbandonare la partita?", "Abbandona", true)) { g.quit(true); redraw(); } } }, "Abbandona")));
    return box;
  }
  const cellBtn = (cls, content, onclick, extra) => h("button", Object.assign({ class: cls, onclick }, extra || {}), content);
  const DRAW = {
    ttt(g, body, redraw) {
      const grid = h("div", { class: "ttt" });
      g.board.forEach((v, i) => grid.append(cellBtn("tc" + (g.win && g.win.includes(i) ? " win" : "") + (g.last === i ? " last" : ""), v === 0 ? "" : (v === 1 ? "✕" : "◯"),
        () => { if (g.isMyTurn() && !v && g.play(i)) redraw(); }, { disabled: !g.isMyTurn() || !!v })));
      body.append(grid, h("small", { class: "muted" }, `Tu sei ${g.me() === 1 ? "✕" : "◯"}`));
    },
    c4(g, body, redraw) {
      const grid = h("div", { class: "c4" });
      for (let r = 0; r < 6; r++) for (let c = 0; c < 7; c++) { const i = r * 7 + c, v = g.board[i];
        grid.append(h("div", { class: "c4c" + (v === 1 ? " p1" : v === 2 ? " p2" : "") + (g.win && g.win.includes(i) ? " win" : "") + (g.last === i ? " last" : ""), onclick: () => { if (g.isMyTurn() && g.play(c)) redraw(); } })); }
      body.append(grid, h("small", { class: "muted" }, `Le tue pedine: ${g.me() === 1 ? "🔴" : "🟡"} · tocca una colonna`));
    },
    rps(g, body, redraw) {
      body.append(h("div", { class: "rps-score" }, h("b", {}, g.my), " a ", h("b", {}, g.their), h("small", {}, " · al meglio di 3")));
      if (g.lastText) body.append(h("div", { class: "muted", style: "font-size:.85em" }, g.lastText));
      if (!g.isOver()) body.append(h("div", { class: "rps" }, ...[0, 1, 2].map(i => cellBtn("rpsb" + (g.myChoice === i ? " on" : ""), h("span", {}, RPS_EMOJI[i], h("small", {}, RPS_NAMES[i])),
        async () => { if (g.myChoice < 0) { await g.choose(i); redraw(); } }, { disabled: g.myChoice >= 0 }))));
    },
    hm(g, body, redraw) {
      const stage = Math.min(6, g.misses);
      body.append(h("div", { class: "hm-pic", html: hangSvg(stage) }));
      if (g.hint) body.append(h("div", { class: "muted", style: "font-size:.85em" }, "Indizio: " + g.hint));
      const w = h("div", { class: "hm-word" });
      for (let i = 0; i < g.length; i++) { const ch = g.revealed[i] || ((g.mine || g.isOver()) && g.word ? g.word[i] : ""); w.append(h("span", { class: g.revealed[i] ? "ok" : "" }, ch || "_")); }
      body.append(w);
      if (g.tried.length) body.append(h("div", { class: "muted", style: "font-size:.8em" }, "Lettere provate: " + g.tried.join(" ")));
      if (g.canGuess()) { const kb = h("div", { class: "hm-kb" }); for (let i = 0; i < 26; i++) { const l = String.fromCharCode(65 + i); kb.append(cellBtn("k", l, () => { if (g.guess(l)) redraw(); }, { disabled: g.tried.includes(l) })); } body.append(kb); }
    },
    qz(g, body, redraw) {
      if (g.myMs < 0 && !g.isOver()) {
        if (!g.started) { body.append(h("p", {}, "5 domande di cultura generale: vince chi ne indovina di più (a parità, il più veloce)."), h("button", { class: "btn primary", onclick: () => { g.started = Date.now(); redraw(); } }, "Inizia il quiz")); return; }
        const q = QUIZ_BANK[g.qs[g.cur]];
        body.append(h("div", { class: "qz-q" }, `${g.cur + 1}/5 · ${q[0]}`), h("div", { class: "qz-opts" }, ...q[1].map((o, i) => cellBtn("btn small", o, () => { g.answer(i); redraw(); }))));
        return;
      }
      const rows = h("div", { class: "qz-res" });
      g.qs.forEach((qi, i) => { const q = QUIZ_BANK[qi]; const mine = g.myAns[i], th = g.theirAns ? g.theirAns[i] : -1;
        rows.append(h("div", {}, h("b", {}, q[0]), h("div", { class: "sub" }, `Giusta: ${q[1][q[2]]} · tu: ${mine >= 0 ? q[1][mine] + (mine === q[2] ? " ✔" : " ✘") : "-"}` + (g.theirAns ? ` · l'altro: ${th >= 0 ? q[1][th] + (th === q[2] ? " ✔" : " ✘") : "-"}` : ""))));
      });
      body.append(h("div", {}, `Tu: ${g.score(g.myAns)}/5 in ${(g.myMs / 1000).toFixed(1)} s` + (g.theirMs >= 0 ? ` · avversario: ${g.score(g.theirAns)}/5 in ${(g.theirMs / 1000).toFixed(1)} s` : "")), rows);
    },
    dm(g, body, redraw) {
      const flip = !g.mine; const sel = g._sel || [];
      const legal = g.isMyTurn() ? g.legalMoves() : [];
      const options = legal.filter(m => sel.every((x, i) => m[i] === x));
      const targets = new Set(sel.length ? options.map(m => m[sel.length]).filter(x => x != null) : legal.map(m => m[0]));
      const board = h("div", { class: "board8" });
      for (let vr = 0; vr < 8; vr++) for (let vc = 0; vc < 8; vc++) {
        const r = flip ? 7 - vr : vr, c = flip ? 7 - vc : vc, sq = r * 8 + c, v = g.board[sq];
        const dark = (r + c) % 2 === 1;
        const cell = h("div", { class: "sq " + (dark ? "dark" : "light") + (sel.includes(sq) ? " sel" : "") + (targets.has(sq) ? " tgt" : "") + (g.last && g.last.includes(sq) ? " last" : ""), onclick: () => {
          if (!g.isMyTurn()) return;
          if (!sel.length) { if (legal.some(m => m[0] === sq)) { g._sel = [sq]; redraw(); } return; }
          if (sq === sel[0] && sel.length === 1) { g._sel = []; redraw(); return; }
          if (!sel.length || !targets.has(sq)) { if (legal.some(m => m[0] === sq)) { g._sel = [sq]; redraw(); } return; }
          const next = [...sel, sq]; const full = options.filter(m => m.length === next.length && m.every((x, i) => x === next[i]));
          const longer = options.filter(m => m.length > next.length && next.every((x, i) => m[i] === x));
          if (full.length && !longer.length) { g._sel = []; g.play(next); } else g._sel = next;
          redraw();
        } });
        if (v) cell.append(h("span", { class: "piece " + (v > 0 ? "w" : "b") + (Math.abs(v) === 2 ? " king" : "") }, Math.abs(v) === 2 ? "♛" : ""));
        board.append(cell);
      }
      body.append(board, h("small", { class: "muted" }, `Tu hai le ${g.mine ? "bianche" : "nere"} · pezzi: ${g.count(g.me())} contro ${g.count(-g.me())}`));
    },
    bn(g, body, redraw) {
      const mk = (fn, cls) => { const grid = h("div", { class: "bn " + cls }); for (let i = 0; i < 100; i++) grid.append(fn(i)); return grid; };
      if (!g.meReady) {
        body.append(h("small", { class: "muted" }, "La tua flotta (5, 4, 3, 3, 2): mescola finché ti piace, poi premi Pronto."),
          mk(i => h("div", { class: "bc" + (g.layout[i] ? " ship" : "") }), "mine big"),
          h("div", { class: "row", style: "margin-top:6px" }, h("button", { class: "btn small", onclick: () => { g.shuffle(); redraw(); } }, "🔀 Mescola"), h("button", { class: "btn small primary", onclick: async () => { await g.ready(); redraw(); } }, "✅ Pronto")));
        return;
      }
      body.append(h("small", { class: "muted" }, `Avversario · navi affondate ${g.sunkShips()}/5`),
        mk(i => h("div", { class: "bc" + (g.enemy[i] === 1 ? " miss" : g.enemy[i] === 2 ? " hit" : g.enemy[i] === 3 ? " sunk" : "") + (g.lastMyShot === i ? " last" : ""), onclick: () => { if (g.shoot(i)) redraw(); } }), "enemy big" + (g.isMyTurn() && g.themReady ? " aim" : "")),
        h("small", { class: "muted" }, "La tua flotta"),
        mk(i => h("div", { class: "bc" + (g.layout[i] ? " ship" : "") + (g.shotOnMe[i] ? (g.hitOnMe[i] ? " hit" : " miss") : "") + (g.lastShotOnMe === i ? " last" : "") }), "mine small"));
    },
    ch(g, body, redraw) {
      const flip = !g.mine; const sel = g._sel ?? -1;
      const legal = g.isMyTurn() ? g.legalMoves() : [];
      const targets = new Set(legal.filter(m => m[0] === sel).map(m => m[1]));
      const GL = { 1: "♟", 2: "♞", 3: "♝", 4: "♜", 5: "♛", 6: "♚" };
      const board = h("div", { class: "board8 chess" });
      const kingSq = g.inCheck() ? g.board.indexOf(K * g.turn) : -1;
      for (let vr = 0; vr < 8; vr++) for (let vc = 0; vc < 8; vc++) {
        const r = flip ? 7 - vr : vr, c = flip ? 7 - vc : vc, sq = r * 8 + c, v = g.board[sq];
        const cell = h("div", { class: "sq " + ((r + c) % 2 ? "dark" : "light") + (sq === sel ? " sel" : "") + (targets.has(sq) ? (v ? " cap" : " tgt") : "") + (g.last && g.last.includes(sq) ? " last" : "") + (sq === kingSq ? " check" : ""), onclick: async () => {
          if (!g.isMyTurn()) return;
          if (targets.has(sq)) {
            let promo = 0;
            if (g.isPromotion(sel, sq)) promo = await new Promise(res => { const s = sheet("Promozione", h("div", { class: "row", style: "justify-content:center" }, ...[[Q, "♛ Donna"], [R, "♜ Torre"], [B, "♝ Alfiere"], [KN, "♞ Cavallo"]].map(([p, t]) => h("button", { class: "btn", onclick: () => { s.close(); res(p); } }, t)))); s.onclose = () => res(Q); });
            g._sel = -1; g.play(sel, sq, promo); redraw(); return;
          }
          g._sel = v * g.me() > 0 && sq !== sel ? sq : -1; redraw();
        } });
        if (v) cell.append(h("span", { class: "cp " + (v > 0 ? "w" : "b") }, GL[Math.abs(v)]));
        if (vc === 0) cell.append(h("i", { class: "rk" }, 8 - r)); if (vr === 7) cell.append(h("i", { class: "fl" }, String.fromCharCode(97 + c)));
        board.append(cell);
      }
      body.append(board);
      if (g.drawThem && !g.isOver()) body.append(h("div", { class: "g-note" }, "🤝 L'avversario propone la patta"));
    }
  };
  function hangSvg(n) {
    const parts = ['<circle cx="70" cy="30" r="9"/>', '<path d="M70 39v26"/>', '<path d="M70 46l-12 10"/>', '<path d="M70 46l12 10"/>', '<path d="M70 65l-10 16"/>', '<path d="M70 65l10 16"/>'];
    return `<svg viewBox="0 0 100 100" fill="none" stroke="currentColor" stroke-width="4" stroke-linecap="round"><path d="M10 95h50M25 95V8h45v13"/>${parts.slice(0, n).join("")}</svg>`;
  }
  function picker(c) {
    const s = sheet("🎮 Sfida " + c.name, h("p", { class: "muted" }, "Scegli un gioco: la sfida arriva in chat e si gioca a turni, anche con chi usa Ghost-chat sul computer."),
      h("div", { class: "attach-grid" }, ...Object.keys(NAMES).map(code => h("button", { class: "att", onclick: () => { s.close(); challenge(c, code); } }, h("span", { class: "ai", style: "background:var(--accent)" }, ICONS[code]), h("small", {}, NAMES[code])))));
  }

  // ============================================================ lavagna condivisa (1000 x 700 punti)
  const W = 1000, H = 700;
  const PALETTE = ["#22182B", "#6A1B9A", "#E53935", "#FB8C00", "#FDD835", "#43A047", "#1E88E5", "#00ACC1", "#8D6E63", "#FFFFFF"];
  async function newWhiteboard(c) {
    if (c.bc) return toast("La lavagna non si può aprire in una lista broadcast", true);
    if (!(await checkSend(c))) return;
    const id = newId();
    if (!Net.send(`WB|${destOf(c)}|${id}|new`)) return toast("Non sei connesso al server", true);
    const m = { id, dir: "out", time: Date.now(), wb: { strokes: [] }, state: "sent" };
    addMsg(c, m); openBoard(c, m);
  }
  function drawStrokes(ctx, strokes, k) {
    ctx.lineCap = ctx.lineJoin = "round";
    for (const s of strokes) {
      ctx.strokeStyle = "#" + (s.color & 0xFFFFFF).toString(16).padStart(6, "0"); ctx.lineWidth = Math.max(1, s.width * k);
      ctx.beginPath(); ctx.moveTo(s.pts[0] * k, s.pts[1] * k);
      if (s.pts.length === 2) ctx.lineTo(s.pts[0] * k + .1, s.pts[1] * k);
      for (let i = 2; i < s.pts.length; i += 2) ctx.lineTo(s.pts[i] * k, s.pts[i + 1] * k);
      ctx.stroke();
    }
  }
  function renderWb(c, m) {
    const cv = h("canvas", { width: 240, height: 168, class: "wb-thumb" });
    const ctx = cv.getContext("2d"); ctx.fillStyle = "#fff"; ctx.fillRect(0, 0, 240, 168); drawStrokes(ctx, m.wb.strokes, .24);
    const who = new Set(m.wb.strokes.map(s => s.who));
    return h("div", { class: "wb", onclick: e => { e.stopPropagation(); openBoard(c, m); } }, h("b", {}, "🖍 Lavagna condivisa"), cv,
      h("small", { class: "muted-in" }, m.wb.strokes.length ? `${m.wb.strokes.length} tratti · ${[...who].map(n => isMe(n) ? "tu" : n).join(", ")}` : "Ancora vuota · tocca per disegnare"));
  }
  let openWb = null;
  function openBoard(c, m) {
    let color = 0x6A1B9A, width = 5;
    const cv = h("canvas", { class: "wb-canvas" }); const ctx = cv.getContext("2d");
    const tools = h("div", { class: "wb-tools" });
    const paint = () => { const k = cv.width / W; ctx.fillStyle = "#fff"; ctx.fillRect(0, 0, cv.width, cv.height); drawStrokes(ctx, m.wb.strokes, k); };
    const fit = () => { const maxW = Math.min(window.innerWidth - 16, 1000), maxH = window.innerHeight - 150; const k = Math.min(maxW / W, maxH / H); cv.width = Math.round(W * k); cv.height = Math.round(H * k); paint(); };
    PALETTE.forEach(col => tools.append(h("button", { class: "wb-col", style: `background:${col}`, onclick: e => { color = parseInt(col.slice(1), 16); tools.querySelectorAll(".wb-col").forEach(b => b.classList.remove("on")); e.target.classList.add("on"); } })));
    tools.firstChild.nextSibling.classList.add("on");
    const ws = select([[2, "Fine"], [5, "Medio"], [10, "Spesso"], [22, "Pennarello"]], 5, v => width = +v);
    tools.append(ws,
      h("button", { class: "btn small", onclick: () => { const mine = [...m.wb.strokes].reverse().find(s => isMe(s.who)); if (!mine) return; m.wb.strokes = m.wb.strokes.filter(s => s !== mine); Net.send(`WB|${destOf(c)}|${m.id}|u|${mine.id}`); paint(); refreshMsg(c, m); } }, "↶ Annulla"),
      h("button", { class: "btn small", onclick: async () => { if (!(await confirmBox("Cancella tutto", "Cancellare la lavagna per tutti?", "Cancella", true))) return; m.wb.strokes = []; Net.send(`WB|${destOf(c)}|${m.id}|c`); paint(); refreshMsg(c, m); } }, "🧽 Pulisci"));
    let cur = null;
    const pt = e => { const r = cv.getBoundingClientRect(); return [Math.round(Math.max(0, Math.min(W, (e.clientX - r.left) * W / r.width))), Math.round(Math.max(0, Math.min(H, (e.clientY - r.top) * H / r.height)))]; };
    cv.addEventListener("pointerdown", e => { if (canSendReason(c)) return toast(canSendReason(c), true); cv.setPointerCapture(e.pointerId); cur = { id: newId(), who: App.me, color, width, pts: pt(e) }; m.wb.strokes.push(cur); paint(); });
    cv.addEventListener("pointermove", e => { if (!cur) return; const [x, y] = pt(e); const n = cur.pts.length; if (Math.abs(cur.pts[n - 2] - x) + Math.abs(cur.pts[n - 1] - y) < 3) return; cur.pts.push(x, y); paint(); if (cur.pts.length >= 3800) end(); });
    const end = () => { if (!cur) return; const s = cur; cur = null; Net.send(`WB|${destOf(c)}|${m.id}|s|${s.id}|${s.color}|${s.width}|${s.pts.join(",")}`); refreshMsg(c, m); };
    cv.addEventListener("pointerup", end); cv.addEventListener("pointercancel", end);
    const wrap = h("div", { class: "wb-full" }, h("div", { class: "wb-head" }, h("b", {}, "🖍 Lavagna · " + c.name), h("button", { class: "iconbtn", style: "color:#fff", onclick: () => close(), html: svg("close") })), cv, tools);
    function close() { wrap.remove(); openWb = null; window.removeEventListener("resize", fit); }
    document.body.append(wrap); fit(); window.addEventListener("resize", fit);
    openWb = { id: m.id, paint };
  }
  Net.on("WB", p => {
    const f = p.split("|"); const o = origin(f[0]); const c = o.chat; if (!c) return;
    const id = (f[1] || "").trim(), action = (f[2] || "").trim(); if (!id) return;
    let m = findMsg(c, id);
    if (!m) {
      if (action !== "new" && action !== "s") return;
      m = { id, dir: "in", who: o.group ? o.nick : null, time: Date.now(), wb: { strokes: [] } };
      addMsg(c, m, action === "new"); Net.send(`ACK|${o.group ? c.id : o.nick}|${id}|D|${Date.now()}`);
    }
    if (!m.wb) return;
    if (action === "s" && f.length >= 7) {
      const pts = f[6].split(",").map(x => parseInt(x, 10)); if (pts.length < 2 || pts.length % 2 || pts.length > 8000 || pts.some(isNaN)) return;
      for (let i = 0; i < pts.length; i++) pts[i] = Math.max(0, Math.min(i % 2 ? H : W, pts[i]));
      const w = Math.max(1, Math.min(40, parseFloat(f[5]) || 3)); const col = (parseInt(f[4], 10) || 0) & 0xFFFFFF;
      m.wb.strokes.push({ id: f[3].trim(), who: o.nick, color: col, width: w, pts });
    } else if (action === "u" && f[3]) m.wb.strokes = m.wb.strokes.filter(s => s.id !== f[3].trim());
    else if (action === "c") m.wb.strokes = [];
    refreshMsg(c, m);
    if (openWb && openWb.id === id) openWb.paint();
  });

  return { render, renderWb, picker, challenge, newWhiteboard, NAMES, QUIZ_BANK };
})();
