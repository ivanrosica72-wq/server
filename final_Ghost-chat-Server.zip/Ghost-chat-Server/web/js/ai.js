/* Ghost-chat mobile · Ghost-AI (stessa piccola IA a regole del computer) + voce del telefono */
"use strict";
const AI = (() => {
  let name = null, turns = 0, riddle = -1, msgs = [];
  const pick = (...o) => o[Math.floor(Math.random() * o.length)];
  const norm = s => s.toLowerCase().normalize("NFD").replace(/\p{M}/gu, "").replace(/[^a-z0-9%.,+\-*/^()?' ]/g, " ").replace(/'/g, " ").replace(/\s+/g, " ").trim();
  const has = (t, ...w) => { const p = " " + t.replace(/[?!.,]/g, " ") + " "; return w.some(x => p.includes(" " + x + " ") || (x.length > 5 && t.includes(x))); };
  const fmt = v => !isFinite(v) ? "impossibile" : Number.isInteger(v) ? String(v) : String(+v.toFixed(6)).replace(".", ",");
  const JOKES = ["Perché i fantasmi sono pessimi bugiardi? Perché si vede attraverso di loro! 👻", "Cosa dice un fantasma quando entra in un bar? \"Un Bu-rbon, grazie!\" 🥃",
    "Qual è il piatto preferito dei fantasmi? Gli spaghetti allo spettro! 🍝", "Perché il fantasma ha chiamato l'idraulico? Aveva una perdita... di memoria! 🔧"];
  const RIDDLES = [["Più ne togli, più diventa grande. Cos'è?", "un buco"], ["Ha le chiavi ma non apre porte. Cos'è?", "una tastiera"], ["Si rompe se lo nomini. Cos'è?", "il silenzio"]];
  const HELP = "Ecco cosa so fare 👻\n• calcoli: \"quanto fa (3+4)*2^3\", \"radice di 81\", \"15% di 80\"\n• conversioni: \"10 km in miglia\", \"30 celsius in fahrenheit\"\n• data e ora, \"quanto manca a Natale\"\n• dado, moneta, \"scegli tra pizza o sushi\"\n• barzellette e indovinelli\n• usare l'app al posto tuo: \"scrivi a Marco ciao\", \"chiama Marco\", \"videochiama Sara\", \"sfida Luca a scacchi\", \"silenzia/archivia/fissa/blocca X\", \"manda la mia posizione a X\", \"pubblica uno stato: ...\", \"nascondi il mio stato online\", \"crea un sondaggio\", \"aggiungi X ai contatti\"\n• aiuto su Ghost-chat: InstaGhost, giochi di carte, temi, accessibilità, account";

  function calc(expr) {
    let i = 0; const s = expr.replace(/\s/g, "");
    const num = () => { if (s[i] === "-") { i++; return -num(); } if (s[i] === "(") { i++; const v = add(); if (s[i++] !== ")") throw 0; return v; } const m = /^[0-9.]+/.exec(s.slice(i)); if (!m) throw 0; i += m[0].length; return parseFloat(m[0]); };
    const pow = () => { const b = num(); if (s[i] === "^") { i++; return Math.pow(b, pow()); } return b; };
    const mul = () => { let v = pow(); while (s[i] === "*" || s[i] === "/") { const o = s[i++]; const r = pow(); if (o === "/" && r === 0) throw 0; v = o === "*" ? v * r : v / r; } return v; };
    const add = () => { let v = mul(); while (s[i] === "+" || s[i] === "-") { const o = s[i++]; const r = mul(); v = o === "+" ? v + r : v - r; } return v; };
    const v = add(); if (i !== s.length) throw 0; return v;
  }
  // final: Ghost-AI usa l'app al posto tuo (stessi comandi della versione per computer, in piccolo)
  function findChat(who) {
    const w = norm(who).replace(/^(il gruppo|gruppo|con|a|di) /, "").trim();
    if (!w) return null;
    const all = [...App.chats.values()];
    return all.find(c => norm(c.name) === w || norm(c.id) === w) || all.find(c => norm(c.name).startsWith(w) || norm(c.id).startsWith(w)) || null;
  }
  function act(raw) {
    const t = norm(raw);
    let m = /^(?:scrivi|manda|invia|rispondi)(?: un)?(?: messaggio)? (?:a|al|alla|ad|al gruppo|nel gruppo) (.+)$/i.exec(raw.trim()) || /^(?:di'|dì|di|dici) (?:a|al|alla) (.+)$/i.exec(raw.trim());
    if (m) {
      const rest = m[1]; const all = [...App.chats.values()].sort((a, b) => b.name.length - a.name.length);
      const c = all.find(c => norm(rest).startsWith(norm(c.name) + " ") || norm(rest).startsWith(norm(c.name) + ":") || norm(rest) === norm(c.name));
      if (!c) return "Non trovo quella chat 🤔";
      let body = rest.slice(c.name.length).replace(/^\s*(:|,|che|dicendo)\s*/i, "").trim();
      if (!body) { openChat(c); showTab("chat"); return `Ecco la chat con ${c.name}: cosa scrivo?`; }
      if (!c.group && !isContact(c.id)) return `${c.name} non è ancora tra i tuoi contatti 🔒 Dimmi "aggiungi ${c.id} ai contatti".`;
      send(c, body); return `📨 Inviato a ${c.name}: "${body}"`;
    }
    if (/chi e online|chi c e|chi e connesso/.test(t)) { const on = [...App.users]; return on.length ? "🟢 Online adesso: " + on.join(", ") + "." : "Al momento nessuno dei tuoi contatti è online 🌙"; }
    if (/messaggi non letti|ho messaggi|nuovi messaggi/.test(t)) { const r = [...App.chats.values()].filter(c => c.unread); return r.length ? "📬 Non letti: " + r.map(c => `${c.name} (${c.unread})`).join(", ") : "Nessun messaggio non letto 📭"; }
    m = /^(?:aggiungi|manda una richiesta a|chiedi il contatto a) @?([\w.\-]+)(?: ai (?:miei )?contatti)?$/.exec(t);
    if (m && /contatt|richiesta|chiedi/.test(t)) { Net.send(`CREQ|${m[1]}`); return `📨 Ho chiesto a ${m[1]} di diventare tuo contatto: potrete scrivervi quando accetta.`; }
    m = /^(accetta|rifiuta) (?:la richiesta di )?@?([\w.\-]+)$/.exec(t);
    if (m) { const n = [...App.incoming.values()].find(x => x.toLowerCase() === m[2]); if (!n) return `Non hai richieste da "${m[2]}".`; Net.send(`CANSWER|${n}|${m[1] === "accetta" ? 1 : 0}`); return m[1] === "accetta" ? `🤝 Ora tu e ${n} potete scrivervi!` : `Hai rifiutato ${n}.`; }
    if (/chi vuole scrivermi|richieste di contatto|chi mi ha chiesto/.test(t)) { const r = [...App.incoming.values()]; return r.length ? "🙋 Vogliono scriverti: " + r.join(", ") + ". Dimmi \"accetta ...\"." : "Nessuna richiesta in attesa."; }
    if (/^(apri|mostra|vai)\b.*\b(contatti|rubrica)\b/.test(t)) { showTab("chat"); contactsSheet(); return "📇 Ecco i contatti."; }
    if (/^(apri|mostra|vai)\b.*\b(instaghost|insta|ghost tube|ghost-tube|reel)\b/.test(t)) { showTab("insta"); return "Eccoti su InstaGhost 🪦✨"; }
    if (/^(apri|mostra|vai)\b.*\b(impostazioni|opzioni)\b/.test(t)) { showTab("settings"); return "⚙️ Ecco le impostazioni."; }
    m = /^(?:apri|vai) (?:la )?(?:chat )?(?:con |da )?(.+)$/.exec(t);
    if (m) { const c = findChat(m[1]); if (c) { showTab("chat"); openChat(c); return `Ecco la chat con ${c.name} 💬`; } }
    m = /^(video ?chiama|videochiamata a|chiama|telefona a) (.+)$/.exec(t);
    if (m) { const c = findChat(m[2]); if (!c) return "Non trovo quella chat 🤔"; showTab("chat"); openChat(c); Calls.start(c, /video/.test(m[1])); return `${/video/.test(m[1]) ? "📹 Videochiamo" : "📞 Chiamo"} ${c.name}…`; }
    m = /^sfida (.+?) a (tris|forza 4|forza quattro|sasso carta forbici|morra|impiccato|quiz|dama|battaglia navale|scacchi)$/.exec(t);
    if (m) { const c = findChat(m[1]); if (!c || c.group) return "Posso lanciare sfide solo nelle chat a due 🎮"; const code = { tris: "ttt", "forza 4": "c4", "forza quattro": "c4", "sasso carta forbici": "rps", morra: "rps", impiccato: "hm", quiz: "qz", dama: "dm", "battaglia navale": "bn", scacchi: "ch" }[m[2]]; showTab("chat"); openChat(c); Games.challenge(c, code); return `🎮 Sfida a ${Games.NAMES[code]} lanciata a ${c.name}!`; }
    m = /^(silenzia|riattiva|archivia|fissa|blocca|sblocca)(?: la chat(?: con| di)?)? (.+)$/.exec(t);
    if (m) { const c = findChat(m[2]); if (!c) return "Non trovo quella chat 🤔";
      if (m[1] === "silenzia" || m[1] === "riattiva") { setPref(c.id, "mute", m[1] === "silenzia"); renderChats(); return m[1] === "silenzia" ? `🔕 ${c.name} silenziata.` : `🔔 Notifiche di ${c.name} riattivate.`; }
      if (m[1] === "archivia") { setPref(c.id, "arch", true); renderChats(); return `🗄 ${c.name} archiviata.`; }
      if (m[1] === "fissa") { setPref(c.id, "pin", true); renderChats(); return `📌 ${c.name} fissata in alto.`; }
      if (c.group) return "Si possono bloccare solo le persone, non i gruppi.";
      setBlocked(c.id, m[1] === "blocca"); renderChats(); return m[1] === "blocca" ? `🚫 ${c.name} bloccato.` : `✅ ${c.name} sbloccato.`; }
    if (/nascondi.*(online|stato|presenza)/.test(t)) { setPriv("hidePresence", true); Net.send("PRESENCE|1"); return "🙈 Ora nessuno vede quando sei online."; }
    if (/mostra.*(online|presenza)/.test(t)) { setPriv("hidePresence", false); Net.send("PRESENCE|0"); return "👀 I tuoi contatti vedono di nuovo quando sei online."; }
    if (/(disattiva|togli).*(conferme di lettura|spunte blu)/.test(t)) { setPriv("readReceipts", false); return "Spunte blu disattivate ✓✓"; }
    if (/(attiva|rimetti).*(conferme di lettura|spunte blu)/.test(t)) { setPriv("readReceipts", true); return "Spunte blu attivate 💙"; }
    m = /^pubblica (?:uno |lo )?stato:? (.+)$/i.exec(raw.trim());
    if (m) { Net.send(`SPOST|${newId().replace(/[^A-Za-z0-9]/g, "").slice(0, 24)}|T|0|bg=#6A1B9A|${Net.escField(m[1])}`); return "✨ Stato pubblicato per 24 ore."; }
    if (/^(apri|mostra) (gli )?stati$/.test(t)) { showTab("chat"); Status.openList(); return "🟢 Ecco gli stati dei tuoi contatti."; }
    m = /^(?:manda|invia|condividi) (?:la )?(?:mia )?posizione (?:a|al|alla|nel gruppo) (.+)$/.exec(t);
    if (m) { const c = findChat(m[1]); if (!c) return "Non trovo quella chat 🤔"; showTab("chat"); openChat(c); Media.shareLocation(c, false); return `📍 Preparo la posizione per ${c.name}…`; }
    if (/^(crea|fai|nuovo) (un )?sondaggio/.test(t)) { if (!App.active) return "Apri prima una chat, poi chiedimi il sondaggio 📊"; showTab("chat"); pollComposer(App.active, false); return "📊 Ecco il sondaggio da compilare."; }
    if (/^(lancia|tira) (un )?dado/.test(t)) { if (!App.active) return "🎲 Ti è uscito " + (1 + Math.floor(Math.random() * 6)) + "!"; send(App.active, "/dado"); return "🎲 Dado lanciato in " + App.active.name; }
    if (/^(apri|mostra).*(lavagna)/.test(t)) { if (!App.active) return "Apri prima una chat 🖍"; Games.newWhiteboard(App.active); return "🖍 Lavagna aperta."; }
    if (/(tema|modalita) (scur|notte)/.test(t)) { Store.set("theme", "notte"); Theme.apply(); return "🌙 Tema scuro attivato."; }
    if (/(tema|modalita) (chiar|viola|normale)/.test(t)) { Store.set("theme", "viola"); Theme.apply(); return "☀️ Tema Viola fantasma attivato."; }
    return null;
  }

  function reply(raw) {
    turns++; raw = raw.trim(); const t = norm(raw);
    if (!/^(come|cos e|cosa e|perche|spiega)\b/.test(t)) { const r = act(raw); if (r) return r; }
    let m = /(?:mi chiamo|il mio nome e|chiamami)\s+([a-z]{2,20})$/.exec(t);
    if (m) { name = m[1][0].toUpperCase() + m[1].slice(1); return `Piacere di conoscerti, ${name}! 👻 Me lo ricorderò.`; }
    if (/come mi chiamo|sai il mio nome/.test(t)) return name ? `Ti chiami ${name}, ovvio! 😄` : "Non me l'hai ancora detto!";
    let e = raw.toLowerCase().replace(/^(quanto fa|calcola|quanto e|quant'è|risolvi)\s*/, "").replace(/per/g, "*").replace(/diviso/g, "/").replace(/più|piu/g, "+").replace(/meno/g, "-").replace(/[x×]/g, "*").replace(/÷/g, "/").replace(/,/g, ".").replace(/[?=]/g, "").trim();
    m = /radice(?: quadrata)? di ([0-9.]+)/.exec(e); if (m) return `√${m[1]} = ${fmt(Math.sqrt(+m[1]))}`;
    m = /([0-9.]+)\s*%\s*di\s*([0-9.]+)/.exec(e); if (m) return `${m[1]}% di ${m[2]} = ${fmt(m[1] * m[2] / 100)}`;
    if (/^[0-9.+\-*/^() ]+$/.test(e) && /[0-9].*[+\-*/^].*[0-9]/.test(e)) { try { return `${e} = ${fmt(calc(e))} 🧮`; } catch (x) { return "Quel calcolo mi confonde: controlla le parentesi!"; } }
    m = /([0-9]+(?:[.,][0-9]+)?)\s*(km|miglia|kg|libbre|celsius|fahrenheit|metri|piedi)\s+(?:in|a)\s+(km|miglia|kg|libbre|celsius|fahrenheit|metri|piedi)/.exec(t);
    if (m) { const v = +m[1].replace(",", "."), f = m[2], to = m[3]; const conv = { "km>miglia": v * .621371, "miglia>km": v / .621371, "kg>libbre": v * 2.20462, "libbre>kg": v / 2.20462, "celsius>fahrenheit": v * 9 / 5 + 32, "fahrenheit>celsius": (v - 32) * 5 / 9, "metri>piedi": v * 3.28084, "piedi>metri": v / 3.28084 }[f + ">" + to]; return conv === undefined ? "Questa conversione non la so fare 😅" : `${m[1]} ${f} = ${fmt(Math.round(conv * 100) / 100)} ${to}`; }
    if (has(t, "dado")) return "🎲 È uscito " + (1 + Math.floor(Math.random() * 6)) + "!";
    if (has(t, "moneta", "testa o croce")) return "🪙 " + pick("Testa!", "Croce!");
    m = /(?:scegli|meglio)\s+(?:tra|fra)?\s*(.+)/.exec(t); if (m && / o |,/.test(t)) { const o = m[1].split(/\s+o\s+|,\s*|\s+oppure\s+/).filter(Boolean); if (o.length > 1) return "Il mio sesto senso spettrale dice: " + pick(...o) + " 🔮"; }
    if (has(t, "che ore sono", "ore sono")) return "Sono le " + new Date().toLocaleTimeString("it-IT", { hour: "2-digit", minute: "2-digit" }) + " ⏰";
    if (has(t, "che giorno e", "data di oggi", "che giorno siamo")) return "Oggi è " + new Date().toLocaleDateString("it-IT", { weekday: "long", day: "numeric", month: "long", year: "numeric" }) + ".";
    if (/quanto manca|quanti giorni/.test(t)) {
      const ev = { natale: [11, 25], capodanno: [0, 1], halloween: [9, 31], "san valentino": [1, 14], ferragosto: [7, 15] };
      for (const k in ev) if (t.includes(k)) { const now = new Date(); now.setHours(0, 0, 0, 0); let d = new Date(now.getFullYear(), ev[k][0], ev[k][1]); if (d < now) d = new Date(now.getFullYear() + 1, ev[k][0], ev[k][1]); const n = Math.round((d - now) / 864e5); return n ? `Mancano ${n} giorni a ${k[0].toUpperCase() + k.slice(1)} 🎉` : "È oggi! 🎉"; }
    }
    if (has(t, "instaghost", "ghost tube", "ghost-tube")) return "📸 InstaGhost è la parte social di Ghost-chat: tocca la bara 🪦 in basso. Pubblica foto e Ghost-tube con +, metti Mi piace o Non mi piace, commenta con testo, sticker e GIF, condividi nelle chat e salva tra i Preferiti.";
    if (has(t, "briscola")) return "🃏 Briscola: in 2 o 4. Vince la mano la briscola più alta o la carta più alta del primo seme. Asso 11, Tre 10, Re 4, Cavallo 3, Fante 2: servono più di 60 punti.";
    if (has(t, "scopa")) return "🃏 Scopa: prendi la carta uguale alla tua o più carte che la sommano. Svuoti il tavolo? SCOPA! Contano carte, Bare (denari), settebello e primiera.";
    if (has(t, "carte", "giochi")) return "🃏 Nei gruppi: Briscola, Scopa, Rubamazzo e Sette e mezzo, con il mazzo Ghost (Fantasmi, Bare, Fumetti, Stelle). Tocca l'icona delle carte nella chat del gruppo.";
    if (has(t, "tema", "colori")) return "🎨 Impostazioni → Tema: scegli due colori esadecimali e premi \"Usa il mio tema\".";
    if (has(t, "accessibil", "daltonic", "dislessi", "contrasto")) return "♿ Impostazioni → Accessibilità: testo più grande, contrasto, daltonismo, meno animazioni e trasparenze, font per la dislessia, avvisi visivi e lettura ad alta voce.";
    if (has(t, "voce", "clonazione", "clonare")) return "🔊 Sul telefono uso le voci del sistema (maschile o femminile). La clonazione vocale con OmniVoice è nella versione per computer, nel pannello Ghost-AI.";
    if (has(t, "ciao", "salve", "buongiorno", "buonasera", "hey", "ehi")) return pick(`Ciao${name ? " " + name : ""}! Sono Ghost-AI 👻 Come posso aiutarti?`, "Bu! 👻 Ah no, ciao! Di cosa parliamo?");
    if (has(t, "come stai", "come va")) return pick("Benissimo, fluttuo leggero! E tu?", "Spettralmente bene, grazie! 😄");
    if (has(t, "chi sei", "come ti chiami")) return "Sono Ghost-AI, la piccola IA di Ghost-chat 👻: funziono tutta sul tuo telefono, senza Internet.";
    if (has(t, "grazie")) return pick("Figurati! 👻", "Di niente!");
    if (has(t, "barzelletta", "battuta", "fammi ridere")) return pick(...JOKES);
    if (has(t, "indovinello")) { riddle = Math.floor(Math.random() * RIDDLES.length); return RIDDLES[riddle][0] + " (scrivi \"soluzione\" se ti arrendi)"; }
    if (riddle >= 0 && has(t, "soluzione", "mi arrendo")) { const r = RIDDLES[riddle][1]; riddle = -1; return "La soluzione è: " + r + "!"; }
    if (riddle >= 0 && t.includes(RIDDLES[riddle][1])) { riddle = -1; return "Esatto! 🎉"; }
    if (has(t, "aiuto", "cosa sai fare", "help")) return HELP;
    m = /(?:mi sento|sono)\s+(triste|felice|stanc[oa]|annoiat[oa]|arrabbiat[oa]|content[oa]|sol[oa])/.exec(t);
    if (m) return /felice|content/.test(m[1]) ? `Che bello! 🎉 Cosa ti ha reso ${m[1]}?` : /annoiat/.test(m[1]) ? "Noia? Vuoi una barzelletta o una partita a briscola nel gruppo?" : `Mi dispiace che tu sia ${m[1]}. Vuoi raccontarmi cosa è successo?`;
    if (raw.endsWith("?")) return "Non sono sicura di saperlo 🤔 Scrivi \"aiuto\" per vedere cosa so fare!";
    return pick("Capisco. Dimmi di più!", "Ah sì? Interessante 👻", "Raccontami di più 👀");
  }

  // ---- voce (sintesi del telefono: voce femminile o maschile)
  function voices() { return (window.speechSynthesis && speechSynthesis.getVoices()) || []; }
  function speak(text) {
    if (!window.speechSynthesis) { toast("La sintesi vocale non è disponibile su questo dispositivo", true); return; }
    const u = new SpeechSynthesisUtterance(text.replace(/[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}]/gu, ""));
    u.lang = "it-IT"; u.rate = Store.get("aiRate", 1);
    const want = Store.get("aiVoice", "female");
    const it = voices().filter(v => v.lang && v.lang.toLowerCase().startsWith("it"));
    const male = /luca|cosimo|diego|giorgio|male|uomo|paolo|roberto/i, female = /alice|elsa|federica|paola|female|donna|carla|giulia/i;
    u.voice = it.find(v => (want === "male" ? male : female).test(v.name)) || it[want === "male" ? it.length - 1 : 0] || null;
    if (want === "male" && !male.test(u.voice?.name || "")) u.pitch = .75; else u.pitch = 1.1;
    speechSynthesis.cancel(); speechSynthesis.speak(u);
  }
  if (window.speechSynthesis) speechSynthesis.onvoiceschanged = () => { };

  function show() {
    const pane = $("#pane-ai"); pane.innerHTML = "";
    pane.append(h("div", { class: "ai-head glass", html: AI_SVG + '<div style="flex:1"><div class="t">Ghost-AI</div><div class="muted">Piccola IA · offline · voce del telefono</div></div>' }));
    const head = pane.firstChild;
    head.append(h("button", { class: "btn small", onclick: voiceSheet }, "Voce"));
    const box = h("div", { class: "msgs", id: "ai-msgs" }); pane.append(box);
    if (!msgs.length) msgs.push({ dir: "in", text: `Ciao${App.me ? " " + App.me : ""}! Sono Ghost-AI 👻 Posso usare l'app per te ("scrivi a Luca: arrivo", "aggiungi giulia ai contatti", "chi è online?", "metti il tema scuro"), fare calcoli e raccontare barzellette.` });
    const chips = h("div", { style: "padding:0 12px;white-space:nowrap;overflow-x:auto" }, ["Cosa sai fare?", "Barzelletta", "Quanto fa (12+8)*3?", "Come si gioca a scopa?"].map(q => h("span", { class: "chip", onclick: () => ask(q) }, q)));
    const ta = h("textarea", { rows: 1, placeholder: "Scrivi a Ghost-AI..." });
    ta.addEventListener("keydown", e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); go(); } });
    const go = () => { const t = ta.value.trim(); if (t) { ta.value = ""; ask(t); } };
    pane.append(chips, h("div", { class: "composer glass" }, ta, h("button", { class: "iconbtn fill", onclick: go, html: svg("send") })));
    draw();
  }
  function draw() {
    const box = $("#ai-msgs"); if (!box) return; box.innerHTML = "";
    for (const m of msgs) {
      const b = h("div", { class: "bubble " + m.dir }, m.typing ? h("span", { class: "typing", html: "<span></span><span></span><span></span>" }) : m.text);
      if (m.dir === "in" && !m.typing) b.prepend(h("button", { class: "speak", onclick: () => speak(m.text), html: svg("speaker", 'width="18"') }));
      box.append(b);
    }
    box.scrollTop = box.scrollHeight;
  }
  function ask(q) {
    msgs.push({ dir: "out", text: q }); const typing = { dir: "in", typing: true }; msgs.push(typing); draw();
    const a = reply(q);
    setTimeout(() => { msgs.splice(msgs.indexOf(typing), 1); msgs.push({ dir: "in", text: a }); draw(); if (Store.get("aiAuto", false)) speak(a); }, 350 + Math.min(900, a.length * 6));
  }
  function voiceSheet() {
    sheet("Voce di Ghost-AI",
      check("Ghostina · femminile", Store.get("aiVoice", "female") === "female", v => v && Store.set("aiVoice", "female"), true, "v"),
      check("Ghostino · maschile", Store.get("aiVoice", "female") === "male", v => v && Store.set("aiVoice", "male"), true, "v"),
      check("Leggi ad alta voce ogni risposta", Store.get("aiAuto", false), v => Store.set("aiAuto", v)),
      h("label", { class: "lbl" }, "Velocità"), (() => { const r = h("input", { type: "range", min: 60, max: 150, value: Store.get("aiRate", 1) * 100 }); r.oninput = () => Store.set("aiRate", r.value / 100); return r; })(),
      h("p", { class: "muted" }, "La voce OmniVoice e la clonazione vocale sono disponibili nella versione per computer (pannello laterale di Ghost-AI)."),
      h("button", { class: "btn primary", onclick: () => speak("Ciao! Sono Ghost-AI, ti piace la mia voce?") }, "Prova la voce"));
  }
  return { show, speak, reply };
})();
