/* Ghost-chat mobile · conversazione: messaggi, risposte, reazioni, spunte, modifica, eliminazione,
 * inoltro, fissati, importanti, messaggi a tempo, sondaggi, ricerca, info di gruppi e contatti. */
"use strict";

// ================================================================ testo formattato
function fmtText(s) {
  const parts = String(s || "").split(/(https?:\/\/[^\s<]+|ghostchat:\/\/instaghost\/[A-Za-z0-9]+)/g);
  return parts.map((p, i) => {
    if (i % 2 === 1) {
      if (p.startsWith("ghostchat://")) return `<a href="#" data-ig="${esc(p.split("/").pop())}">📸 Apri in InstaGhost</a>`;
      return `<a href="${esc(p)}" target="_blank" rel="noopener">${esc(p)}</a>`;
    }
    let t = esc(p);
    t = t.replace(/`([^`\n]+)`/g, "<code>$1</code>")
      .replace(/(^|[\s(])\*([^*\n]+)\*(?=$|[\s.,!?:;)])/g, "$1<b>$2</b>")
      .replace(/(^|[\s(])_([^_\n]+)_(?=$|[\s.,!?:;)])/g, "$1<i>$2</i>")
      .replace(/(^|[\s(])~([^~\n]+)~(?=$|[\s.,!?:;)])/g, "$1<s>$2</s>")
      .replace(/(^|\s)@([\w.\-]{1,20})/g, (m, a, n) => `${a}<span class="mention${isMe(n) ? " me" : ""}">@${n}</span>`);
    return t;
  }).join("");
}
const onlyEmoji = s => /^(\p{Extended_Pictographic}|\p{Emoji_Component}|‍|️|\s){1,24}$/u.test(s || "") && /\p{Extended_Pictographic}/u.test(s) && [...(s || "").replace(/\s/g, "")].length <= 8;
const nameColor = n => { let x = 0; for (const ch of n || "") x = (x * 31 + ch.charCodeAt(0)) | 0; return `hsl(${Math.abs(x) % 360} 55% 45%)`; };

function ticks(m) {
  if (m.dir !== "out") return "";
  if (m.state === "failed") return "⚠";
  if (m.state === "R") return "✓✓";
  if (m.state === "D") return "✓✓";
  return "✓";
}
function ticksEl(c, m) {
  if (m.dir !== "out") return null;
  let st = m.state;
  if ((c.group || c.bc) && m.receipts) {
    const total = c.bc ? (bcList(c.id)?.members.length || 1) : Math.max(1, (App.groups.get(c.id.slice(1))?.members.length || 2) - 1);
    const v = Object.values(m.receipts); const r = v.filter(x => x === "R").length;
    st = r >= total ? "R" : v.length ? "D" : st;
  }
  const t = st === "failed" ? "⚠" : st === "R" || st === "D" ? "✓✓" : st === "sending" ? "🕓" : "✓";
  return h("span", { class: "ticks" + (st === "R" ? " read" : "") + (st === "failed" ? " fail" : ""), title: m.error || "" }, t);
}

// ================================================================ apertura della chat
function openChat(c, focusId) {
  App.active = c; c.unread = 0; c.mentioned = false; setPref(c.id, "markUnread", false);
  App.replyTo = null; App.editing = null; App.chatSearch = "";
  updateBadges(); if (App.tab !== "chat") showTab("chat"); else renderConversation();
  sendReadReceipts(c);
  if (focusId) setTimeout(() => scrollToMsg(focusId), 60);
}
function closeChat() {
  const c = App.active; if (c) sendTyping(c, "0");
  App.active = null; renderChats();
}
function sendReadReceipts(c) {
  if (!c || document.visibilityState !== "visible" || App.tab !== "chat" || App.active !== c) return;
  const by = new Map();
  for (const m of c.msgs) if (m.dir === "in" && !m.readSent && !m.deleted) {
    m.readSent = true;
    if (!Priv().readReceipts) continue;
    const dest = c.group ? c.id : c.id;
    (by.get(dest) || by.set(dest, []).get(dest)).push(m.id);
  }
  for (const [dest, ids] of by) for (let i = 0; i < ids.length; i += 40) Net.send(`ACK|${dest}|${ids.slice(i, i + 40).join(",")}|R|${Date.now()}`);
}
document.addEventListener("visibilitychange", () => { if (document.visibilityState === "visible" && App.active) { App.active.unread = 0; updateBadges(); sendReadReceipts(App.active); } });

function canSendReason(c) {
  if (c.bc) return (bcList(c.id)?.members || []).length ? null : "La lista è vuota";
  if (c.group) {
    if (c.alive === false) return "Non fai più parte di questo gruppo";
    const g = App.groups.get(c.id.slice(1));
    if (g && g.onlyAdmins && !g.admins.some(isMe)) return "Solo gli amministratori possono scrivere in questo gruppo";
    return null;
  }
  if (isBlocked(c.id)) return `Hai bloccato ${c.name}: sbloccalo per scrivergli`;
  return null;
}
async function checkSend(c) {
  const r = canSendReason(c); if (r) { toast(r, true); return false; }
  if (!c.group && !c.bc && !isContact(c.id)) {
    if (App.outgoing.has(kc(c.id))) { toast(`${c.id} non ha ancora accettato la tua richiesta`, true); return false; }
    if (await confirmBox("Non è un contatto", `${c.id} non è ancora tra i tuoi contatti. Vuoi mandargli una richiesta? Potrete scrivervi quando la accetta.`, "Invia richiesta")) Net.send(`CREQ|${c.id}`);
    return false;
  }
  if (!Net.isOnline()) { toast("Non sei connesso al server", true); return false; }
  return true;
}
/** Invia una riga per la chat (nelle liste broadcast una per ogni destinatario). */
function dispatch(c, mk) {
  if (c.bc) { let ok = false; for (const n of bcList(c.id)?.members || []) ok = Net.send(mk(n)) || ok; return ok; }
  return Net.send(mk(destOf(c)));
}
function timerOf(c) { return prefs(c.id).timer || 0; }
function trackOut(c, m) {
  m.state = m.state || "sent";
  const t = timerOf(c); if (t && !m.game && !m.wb) { m.timer = t; m.expiresAt = Date.now() + t * 1000; }
  if (c.bc) App.bcSent.set(m.id, [c, m]);
  App.lastSent = Date.now();
}
App.bcSent = new Map();

// ================================================================ invio testo
function send(c, text, opts = {}) {
  text = String(text || "").replace(/\r/g, "").trim(); if (!text) return;
  if (text.length > 8000) { toast("Messaggio troppo lungo (max 8000 caratteri)", true); return; }
  if (!opts.fwd && text.startsWith("/") && runCommand(c, text)) return;
  (async () => {
    if (!(await checkSend(c))) return;
    const id = newId(); const t = timerOf(c);
    const meta = buildMeta({ r: opts.replyTo, q: opts.quote ? b64url(opts.quote) : null, t: t || null, f: opts.fwd ? "1" : null });
    const m = { id, dir: "out", text, time: Date.now(), replyTo: opts.replyTo || null, quote: opts.quote || null, fwd: !!opts.fwd };
    trackOut(c, m);
    if (!dispatch(c, d => `MSG|${d}|${id}|${meta}|${Net.escape(text)}`)) { m.state = "failed"; toast("Non sei connesso", true); }
    sendTyping(c, "0");
    addMsg(c, m);
  })();
}
function runCommand(c, text) {
  const [cmd, ...rest] = text.trim().split(/\s+/); const arg = rest.join(" ").trim();
  const R = n => Math.floor(Math.random() * n);
  switch (cmd.toLowerCase()) {
    case "/dado": { const f = Math.max(2, Math.min(1000, parseInt(arg.replace(/\D/g, ""), 10) || 6)); send(c, `🎲 *Dado* (d${f}): *${1 + R(f)}*`, { fwd: false, raw: true, noCmd: true }); return true; }
    case "/moneta": send(c, `🪙 *Moneta*: *${R(2) ? "Testa" : "Croce"}*`, { noCmd: true }); return true;
    case "/sorteggio": {
      const o = (arg.includes(",") ? arg.split(",") : arg.split(/\s+/)).map(x => x.trim()).filter(Boolean);
      if (o.length < 2) { toast("Scrivi almeno due opzioni: /sorteggio pizza, sushi, kebab", true); return true; }
      send(c, `🎯 *Sorteggio* tra ${o.join(", ")}: *${o[R(o.length)]}*`, { noCmd: true }); return true;
    }
    case "/timer": {
      const m = /^(\d+(?:[.,]\d+)?)\s*(s|sec|secondi|m|min|minuti|h|ora|ore)?\b\s*(.*)$/i.exec(arg);
      if (!m) { toast("Esempio: /timer 5m pasta (s = secondi, m = minuti, h = ore)", true); return true; }
      const u = (m[2] || "m").toLowerCase(); const ms = parseFloat(m[1].replace(",", ".")) * (u.startsWith("s") ? 1000 : u.startsWith("h") || u.startsWith("or") ? 3600000 : 60000);
      if (ms < 1000 || ms > 86400000) { toast("Il timer va da 1 secondo a 24 ore", true); return true; }
      const label = m[3] || "Timer";
      system(c, `⏲ Timer "${label}" avviato: ${fmtDur(ms)}`);
      setTimeout(() => { system(c, `⏰ Tempo scaduto: ${label}`); vibrate([300, 100, 300]); Sound.beep(660, .4, .1); toast("⏰ " + label); }, ms);
      return true;
    }
    case "/lavagna": Games.newWhiteboard(c); return true;
    case "/sondaggio": pollComposer(c, false); return true;
    case "/quiz": pollComposer(c, true); return true;
    case "/posizione": Media.shareLocation(c, false); return true;
    case "/aiuto": case "/help": case "/comandi":
      sheet("Comandi rapidi", ...[["/dado [facce]", "lancia un dado"], ["/moneta", "testa o croce"], ["/sorteggio a, b, c", "sceglie a caso"], ["/timer 5m pasta", "promemoria"],
        ["/lavagna", "lavagna condivisa"], ["/sondaggio", "nuovo sondaggio"], ["/quiz", "nuovo quiz"], ["/posizione", "invia la posizione"]].map(([a, b]) => h("div", { class: "item" }, h("code", {}, a), h("span", { class: "muted" }, b))),
        h("p", { class: "muted" }, "Formattazione: *grassetto*, _corsivo_, ~barrato~, `codice`, @nome per menzionare."));
      return true;
    default: return false;
  }
}

// ================================================================ "sta scrivendo"
let typingSent = { chat: null, at: 0, state: "0" };
function sendTyping(c, st) {
  if (!c || c.bc || !Priv().typing || !Net.isOnline()) return;
  if (!c.group && !isContact(c.id)) return;
  const now = Date.now();
  if (st === typingSent.state && typingSent.chat === c && now - typingSent.at < 4000) return;
  if (st === "0" && typingSent.state === "0") return;
  typingSent = { chat: c, at: now, state: st };
  Net.send(`TYPING|${destOf(c)}|${st}`);
}

// ================================================================ intestazione e schermata della chat
function renderConvHead() {
  const c = App.active; const head = $("#conv-head"); if (!head || !c) return;
  head.innerHTML = "";
  let sub;
  const typing = Object.entries(c.typing || {}).filter(([, v]) => v.until > Date.now());
  if (typing.length) sub = (c.group ? typing.map(([n]) => n).join(", ") + " " : "") + (typing[0][1].s === "r" ? "sta registrando un vocale…" : "sta scrivendo…");
  else if (c.bc) sub = (bcList(c.id)?.members || []).join(", ");
  else if (c.group) { const g = App.groups.get(c.id.slice(1)); sub = c.alive === false ? "Non fai più parte del gruppo" : (g?.members || []).map(n => isMe(n) ? "Tu" : n).join(", "); }
  else sub = isBlocked(c.id) ? "Bloccato" : !isContact(c.id) ? "Non è ancora un contatto" : App.users.has(kc(c.id)) ? "Online" : "Offline";
  const callable = !c.bc && (c.group ? c.alive !== false : isContact(c.id) && !isBlocked(c.id));
  head.append(
    h("button", { class: "back", onclick: closeChat, html: svg("back") }),
    chatAvatar(c, 40),
    h("div", { class: "main", style: "flex:1;min-width:0", onclick: () => chatInfo(c) }, h("div", { class: "name" }, c.name, prefs(c.id).mute ? " 🔕" : "", timerOf(c) ? " ⏱" : ""),
      h("div", { class: "sub muted" + (typing.length ? " typing-now" : "") }, sub)),
    callable ? h("button", { class: "iconbtn", title: "Chiamata", onclick: () => Calls.start(c, false), html: svg("phone") }) : null,
    callable ? h("button", { class: "iconbtn", title: "Videochiamata", onclick: () => Calls.start(c, true), html: svg("video") }) : null,
    h("button", { class: "iconbtn", title: "Altro", onclick: () => convMenu(c), html: svg("more") }));
  renderPinned();
  Calls.renderBanner(c);
}
function renderConversation() {
  const c = App.active; const pane = $("#pane-chat"); pane.innerHTML = "";
  if (!c) { renderChats(); return; }
  pane.append(h("div", { id: "conv-head", class: "conv-head glass" }), h("div", { id: "pinned-bar" }), h("div", { id: "call-banner" }));
  renderConvHead();
  const box = h("div", { id: "msgs", class: "msgs" });
  Media.applyWallpaper(box, c.id);
  pane.append(box);
  pane.append(h("div", { id: "composer-wrap" }));
  renderComposer();
  renderMessages();
}

// ---- barra dei messaggi fissati
let pinIdx = 0;
function renderPinned() {
  const c = App.active; const bar = $("#pinned-bar"); if (!bar || !c) return;
  bar.innerHTML = "";
  const pins = c.msgs.filter(m => m.pinned && !m.deleted);
  if (!pins.length) return;
  const m = pins[pinIdx % pins.length] || pins[pins.length - 1];
  bar.append(h("div", { class: "pinned glass", onclick: () => { scrollToMsg(m.id); pinIdx++; renderPinned(); } },
    h("span", { html: svg("pin", 'style="width:18px"') }), h("div", { class: "main" }, h("b", {}, `Messaggio fissato${pins.length > 1 ? ` ${(pinIdx % pins.length) + 1}/${pins.length}` : ""}`), h("div", { class: "sub" }, preview(m)))));
}

// ---- composer
function renderComposer() {
  const c = App.active; const wrap = $("#composer-wrap"); if (!wrap || !c) return;
  wrap.innerHTML = "";
  const reason = canSendReason(c);
  if (reason) { wrap.append(h("div", { class: "composer glass notice" }, h("span", { class: "muted", style: "padding:10px;flex:1;text-align:center" }, reason))); return; }
  if (App.replyTo || App.editing) {
    const r = App.editing || App.replyTo;
    wrap.append(h("div", { class: "replybar glass" }, h("div", { class: "main" }, h("b", {}, App.editing ? "✏️ Modifica messaggio" : "↩ Rispondi a " + (r.dir === "out" ? "te stesso" : r.who || c.name)),
      h("div", { class: "sub" }, App.replyQuote ? "“" + App.replyQuote + "”" : preview(r))),
      h("button", { class: "iconbtn", onclick: () => { App.replyTo = null; App.editing = null; App.replyQuote = null; renderComposer(); }, html: svg("close") })));
  }
  const ta = h("textarea", { rows: 1, placeholder: c.bc ? "Messaggio a tutta la lista" : "Scrivi un messaggio", id: "composer-ta" });
  if (App.editing) ta.value = App.editing.text || "";
  else ta.value = App.drafts?.[c.id] || "";
  const sendBtn = h("button", { class: "iconbtn fill", title: "Invia", html: svg(ta.value.trim() || App.editing ? "send" : "mic") });
  const upd = () => { ta.style.height = "auto"; ta.style.height = Math.min(120, ta.scrollHeight) + "px"; sendBtn.innerHTML = svg(ta.value.trim() || App.editing ? "send" : "mic"); (App.drafts = App.drafts || {})[c.id] = App.editing ? "" : ta.value; };
  ta.addEventListener("input", () => { upd(); sendTyping(c, ta.value.trim() ? "t" : "0"); mentionSuggest(ta, c); });
  ta.addEventListener("keydown", e => { if (e.key === "Enter" && !e.shiftKey && !/Android|iPhone|iPad/i.test(navigator.userAgent)) { e.preventDefault(); go(); } });
  ta.addEventListener("blur", () => sendTyping(c, "0"));
  sendBtn.onclick = () => { if (ta.value.trim() || App.editing) go(); else Media.recordVoice(c); };
  function go() {
    const t = ta.value.trim(); if (!t) return;
    if (App.editing) { editMessage(c, App.editing, t); App.editing = null; ta.value = ""; renderComposer(); return; }
    const opts = App.replyTo ? { replyTo: App.replyTo.id, quote: App.replyQuote || null } : {};
    App.replyTo = null; App.replyQuote = null; ta.value = ""; if (App.drafts) App.drafts[c.id] = "";
    send(c, t, opts); renderComposer();
  }
  wrap.append(h("div", { class: "composer glass" },
    h("button", { class: "iconbtn", title: "Allega", onclick: () => attachMenu(c), html: svg("plus") }),
    h("button", { class: "iconbtn", title: "Emoji", onclick: () => Media.emojiPicker(e => { ta.value += e; upd(); ta.focus(); }), html: svg("smile") }),
    ta, h("button", { class: "iconbtn", title: "Risposte rapide", onclick: () => quickReplies(c) }, "⚡"), sendBtn));
  upd();
  if (App.editing) setTimeout(() => ta.focus(), 50);
}
function mentionSuggest(ta, c) {
  document.querySelectorAll(".mention-pop").forEach(e => e.remove());
  if (!c.group) return;
  const m = /@([\w.\-]*)$/.exec(ta.value.slice(0, ta.selectionStart)); if (!m) return;
  const g = App.groups.get(c.id.slice(1)); if (!g) return;
  const opts = g.members.filter(n => !isMe(n) && kc(n).startsWith(kc(m[1]))).slice(0, 6); if (!opts.length) return;
  const pop = h("div", { class: "mention-pop glass" }, ...opts.map(n => h("div", { class: "item", onclick: () => {
    const pos = ta.selectionStart; ta.value = ta.value.slice(0, pos - m[1].length) + n + " " + ta.value.slice(pos); pop.remove(); ta.focus();
  } }, avatar(n), n)));
  $("#composer-wrap").prepend(pop);
}
function quickReplies(c) {
  const list = quickList();
  const s = sheet("Risposte rapide · si inviano subito", ...list.map(r => h("div", { class: "item", onclick: () => { send(c, r); s.close(); } }, "⚡ " + r)),
    h("button", { class: "btn small", onclick: () => { s.close(); manageQuick(); } }, "Gestisci"));
}
function attachMenu(c) {
  const grid = h("div", { class: "attach-grid" });
  const add = (ic, t, fn, col) => grid.append(h("button", { class: "att", onclick: () => { s.close(); fn(); } }, h("span", { class: "ai", style: `background:${col}` }, ic), h("small", {}, t)));
  add("🖼", "Foto e video", () => Media.pickFiles(c, "image/*,video/*", false), "#7E57C2");
  add("📸", "Fotocamera", () => Media.pickFiles(c, "image/*", false, true), "#EC407A");
  add("📄", "Documento", () => Media.pickFiles(c, "*/*", false), "#5C6BC0");
  add("👁", "Visualizza 1 volta", () => Media.pickFiles(c, "image/*", true), "#26A69A");
  add("🎞", "GIF", () => Media.gifPicker(c), "#FF7043");
  add("🌟", "Sticker", () => Media.stickerPicker(c), "#FFB300");
  add("🎤", "Vocale", () => Media.recordVoice(c), "#EF5350");
  add("📍", "Posizione", () => Media.shareLocation(c, false), "#43A047");
  add("📡", "Tempo reale", () => Media.shareLocation(c, true), "#00897B");
  add("📊", "Sondaggio", () => pollComposer(c, false), "#FFA000");
  add("🧠", "Quiz", () => pollComposer(c, true), "#8D6E63");
  if (!c.bc) add("🖍", "Lavagna", () => Games.newWhiteboard(c), "#29B6F6");
  if (!c.group && !c.bc) add("🎮", "Giochi", () => Games.picker(c), "#AB47BC");
  if (c.group) add("🃏", "Carte", () => Cards.newGame(c.id.slice(1)), "#6D4C41");
  add("⏱", "A tempo", () => timerSheet(c), "#546E7A");
  add("🕒", "Programma", () => scheduleSheet(c), "#3949AB");
  const s = sheet("Condividi", grid);
}
function timerSheet(c) {
  const cur = timerOf(c);
  const opts = [[0, "Disattivati"], [30, "30 secondi"], [300, "5 minuti"], [3600, "1 ora"], [86400, "24 ore"], [604800, "7 giorni"], [7776000 / 3, "30 giorni"]];
  const s = sheet("Messaggi a tempo", h("p", { class: "muted" }, "I nuovi messaggi spariscono da tutti i dispositivi dopo il tempo scelto."),
    ...opts.map(([v, t]) => h("div", { class: "item", onclick: () => { setPref(c.id, "timer", v || null); s.close(); system(c, v ? `⏱ Hai attivato i messaggi a tempo: ${t}` : "⏱ Hai disattivato i messaggi a tempo"); renderConvHead(); } },
      h("span", { class: "mi" }, cur === v ? "🔘" : "⚪"), h("div", { class: "main" }, t))));
}
function convMenu(c) {
  const pr = prefs(c.id);
  menu(c.name, [
    ["ℹ️", c.group ? "Info del gruppo" : c.bc ? "Modifica la lista" : "Info del contatto", () => c.bc ? editBroadcast(c.id.slice(1)) : chatInfo(c)],
    ["🔍", "Cerca nella chat", () => searchInChat(c)],
    ["🖼", "Media, link e documenti", () => mediaSheet(c)],
    ["⭐", "Messaggi importanti", () => starredSheet()],
    ["⏱", "Messaggi a tempo" + (timerOf(c) ? " (attivi)" : ""), () => timerSheet(c)],
    ["🎨", "Sfondo della chat", () => Media.wallpaperSheet(c)],
    ["🔕", pr.mute ? "Riattiva le notifiche" : "Silenzia", () => { setPref(c.id, "mute", !pr.mute); renderConvHead(); }],
    !c.bc ? ["🖍", "Lavagna condivisa", () => Games.newWhiteboard(c)] : null,
    !c.group && !c.bc ? ["🎮", "Sfida a un gioco", () => Games.picker(c)] : null,
    c.group ? ["🃏", "Giochi di carte", () => Cards.newGame(c.id.slice(1))] : null,
    !c.group && !c.bc ? ["🚫", isBlocked(c.id) ? "Sblocca" : "Blocca", () => toggleBlock(c)] : null,
    ["🕒", "Programma un messaggio", () => scheduleSheet(c)],
    ["📤", "Esporta la chat", () => exportChat(c)],
    ["🧹", "Svuota la chat", async () => { if (await confirmBox("Svuota chat", "Cancellare tutti i messaggi di questa chat da questo telefono?", "Svuota", true)) { c.msgs = []; renderMessages(); renderPinned(); } }],
    c.group && c.alive !== false ? ["🚪", "Esci dal gruppo", () => leaveGroup(c), true] : null
  ]);
}

// ================================================================ messaggi
let renderedDay = null;
function renderMessages() {
  const c = App.active; const box = $("#msgs"); if (!box || !c) return;
  box.innerHTML = ""; renderedDay = null;
  const list = c.msgs.filter(m => !m.hiddenForMe);
  if (!list.length) box.append(h("div", { class: "system" }, c.bc ? "📢 I messaggi di questa lista arrivano a ognuno in privato." : c.group ? "👻 Inizia la conversazione del gruppo" : "👻 Ancora nessun messaggio. I messaggi vivono solo finché l'app è aperta."));
  for (const m of list) box.append(...bubbleWithDay(c, m));
  box.scrollTop = box.scrollHeight;
  renderPinned();
}
function bubbleWithDay(c, m) {
  const out = []; const d = new Date(m.time || Date.now()).toDateString();
  if (d !== renderedDay) { renderedDay = d; out.push(h("div", { class: "system day" }, dayLabel(m.time || Date.now()))); }
  out.push(renderBubble(c, m)); return out;
}
function appendBubble(c, m) {
  const box = $("#msgs"); if (!box || App.active !== c) return;
  if (box.querySelector(".system:only-child")) box.innerHTML = "", renderedDay = null;
  const near = box.scrollHeight - box.scrollTop - box.clientHeight < 160;
  box.append(...bubbleWithDay(c, m));
  if (near || m.dir === "out") box.scrollTop = box.scrollHeight;
  if (m.dir === "in" && document.visibilityState === "visible" && App.tab === "chat") { c.unread = 0; updateBadges(); sendReadReceipts(c); }
}
function refreshMsg(c, m) {
  if (App.active !== c) { renderChats(); return; }
  const box = $("#msgs"); if (!box) return;
  const old = box.querySelector(`[data-id="${CSS.escape(m.id)}"]`);
  if (old) old.replaceWith(renderBubble(c, m)); else if (!m.hiddenForMe) appendBubble(c, m);
  if (m.pinned !== undefined) renderPinned();
}
function scrollToMsg(id) {
  const el = document.querySelector(`#msgs [data-id="${CSS.escape(id)}"]`);
  if (el) { el.scrollIntoView({ block: "center", behavior: "smooth" }); el.classList.add("flashmsg"); setTimeout(() => el.classList.remove("flashmsg"), 1500); }
  else toast("Messaggio non più disponibile", true);
}
function renderBubble(c, m) {
  if (m.dir === "sys") return h("div", { class: "system", "data-id": m.id }, m.text);
  const wide = m.game || m.wb || m.poll || m.loc;
  const b = h("div", { class: "bubble " + m.dir + (m.file && m.file.sticker && !m.deleted ? " sticker" : "") + (wide && !m.deleted ? " wide" : "") + (m.state === "failed" ? " failed" : ""), "data-id": m.id });
  if (m.who && c.group && m.dir === "in") b.append(h("div", { class: "who", style: `color:${nameColor(m.who)}` }, m.who));
  if (m.deleted) {
    b.append(h("i", { class: "muted-in" }, m.dir === "out" ? "🚫 Hai eliminato questo messaggio" : "🚫 Questo messaggio è stato eliminato"));
    b.append(h("div", { class: "time" }, time(m.time)));
    longPress(b, () => menu("Messaggio eliminato", [["🗑", "Elimina per me", () => { m.hiddenForMe = true; renderMessages(); }]]));
    return b;
  }
  if (m.fwd) b.append(h("div", { class: "fwd" }, "↪ Inoltrato"));
  if (m.replyTo) {
    const r = findMsg(c, m.replyTo);
    b.append(h("div", { class: "reply", onclick: e => { e.stopPropagation(); scrollToMsg(m.replyTo); } },
      h("b", {}, r ? (r.dir === "out" ? "Tu" : r.who || c.name) : "Messaggio"), h("div", {}, m.quote ? "“" + m.quote + "”" : r ? preview(r) : "non più disponibile")));
  }
  if (m.file) b.append(Media.renderFile(c, m));
  else if (m.poll) b.append(renderPoll(c, m));
  else if (m.loc) b.append(Media.renderLoc(c, m));
  else if (m.game) b.append(Games.render(c, m));
  else if (m.wb) b.append(Games.renderWb(c, m));
  else {
    const span = h("div", { class: "text" + (onlyEmoji(m.text) ? " jumbo" : "") }); span.innerHTML = fmtText(m.text);
    if (App.chatSearch) span.innerHTML = span.innerHTML.replace(new RegExp("(" + App.chatSearch.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + ")(?![^<]*>)", "ig"), "<mark>$1</mark>");
    span.querySelectorAll("a[data-ig]").forEach(a => a.addEventListener("click", e => { e.preventDefault(); showTab("insta"); Insta.openPost(a.dataset.ig); }));
    b.append(span);
    if (m.link) b.append(h("a", { class: "linkprev", href: m.link.url, target: "_blank", rel: "noopener" },
      m.link.img ? h("img", { src: "data:image/jpeg;base64," + m.link.img, alt: "" }) : null,
      h("div", {}, h("b", {}, m.link.title || m.link.url), m.link.desc ? h("div", { class: "sub" }, m.link.desc) : null, h("small", {}, m.link.site || ""))));
  }
  const reacts = Object.entries(m.reacts || {});
  if (reacts.length) {
    const counts = {}; for (const [, e] of reacts) counts[e] = (counts[e] || 0) + 1;
    b.append(h("div", { class: "reacts", onclick: e => { e.stopPropagation(); reactionsSheet(c, m); } }, ...Object.entries(counts).map(([e, n]) => h("span", {}, e, n > 1 ? h("small", {}, n) : null))));
  }
  b.append(h("div", { class: "time" }, m.starred ? "⭐ " : "", m.pinned ? "📌 " : "", m.expiresAt ? "⏱ " : "", m.edited ? "modificato · " : "", time(m.time), " ", ticksEl(c, m)));
  longPress(b, () => msgActions(c, m));
  return b;
}
function reactionsSheet(c, m) {
  const s = sheet("Reazioni", ...Object.entries(m.reacts || {}).map(([n, e]) => h("div", { class: "item", onclick: () => { if (isMe(n)) { react(c, m, e); s.close(); } } },
    avatar(n), h("div", { class: "main" }, h("div", { class: "name" }, isMe(n) ? "Tu" : n), isMe(n) ? h("div", { class: "sub" }, "Tocca per togliere") : null), h("span", { style: "font-size:1.6em" }, e))));
}

// ================================================================ azioni sui messaggi
const QUICK_REACTS = ["👍", "❤️", "😂", "😮", "😢", "🙏"];
function msgActions(c, m) {
  const mine = m.dir === "out";
  const reactRow = h("div", { class: "react-row" }, ...QUICK_REACTS.map(e => h("button", { class: (m.reacts || {})[App.me] === e ? "on" : "", onclick: () => { react(c, m, e); s.close(); } }, e)),
    h("button", { onclick: () => { s.close(); Media.emojiPicker(e => react(c, m, e)); } }, "➕"));
  const isText = !m.file && !m.poll && !m.loc && !m.game && !m.wb;
  const items = [
    ["↩", "Rispondi", () => { App.replyTo = m; App.replyQuote = null; App.editing = null; renderComposer(); $("#composer-ta")?.focus(); }],
    isText ? ["❝", "Cita una parte", async () => { const q = await ask("Cita una parte", "Lascia solo la frase a cui vuoi rispondere.", "", (m.text || "").slice(0, 300), "Cita"); if (q && q.trim()) { App.replyTo = m; App.replyQuote = q.trim().slice(0, 300); renderComposer(); $("#composer-ta")?.focus(); } }] : null,
    isText ? ["📋", "Copia", () => { copyText(m.text); }] : null,
    !m.game && !m.wb && !(m.file && m.file.once) ? ["↪", "Inoltra", () => forwardSheet(c, m)] : null,
    mine && isText && !c.bc ? ["✏️", "Modifica", () => { App.editing = m; App.replyTo = null; renderComposer(); }] : null,
    !c.bc ? ["📌", m.pinned ? "Togli dai fissati" : "Fissa", () => togglePin(c, m)] : null,
    ["⭐", m.starred ? "Non più importante" : "Importante", () => { m.starred = !m.starred; refreshMsg(c, m); }],
    m.file && m.file.url && (m.file.kind === "IMAGE" || m.file.kind === "GIF") && !m.file.once ? ["🌟", "Aggiungi ai miei sticker", () => Media.saveSticker(m.file.url)] : null,
    m.file && m.file.url && !m.file.once ? ["💾", "Salva sul telefono", () => Media.download(m.file.url, m.file.name || "file")] : null,
    mine ? ["ℹ️", "Info (consegna e lettura)", () => msgInfo(c, m)] : null,
    mine && !c.bc ? ["🗑", "Elimina per tutti", async () => { if (await confirmBox("Elimina per tutti", "Il messaggio sparirà anche per gli altri.", "Elimina", true)) deleteForAll(c, m); }, true] : null,
    ["🗑", "Elimina per me", () => { m.hiddenForMe = true; if (m.loc && m.loc.liveTimer) Media.stopLive(c, m); renderMessages(); renderChats(); }, true]
  ];
  const s = sheet(null, reactRow, ...items.filter(Boolean).map(([ic, t, fn, danger]) => h("div", { class: "item" + (danger ? " danger" : ""), onclick: () => { s.close(); fn(); } }, h("span", { class: "mi" }, ic), h("div", { class: "main" }, t))));
}
function copyText(t) {
  (navigator.clipboard ? navigator.clipboard.writeText(t) : Promise.reject()).then(() => toast("Copiato"), () => {
    const ta = h("textarea", {}, t); document.body.append(ta); ta.select(); try { document.execCommand("copy"); toast("Copiato"); } catch (e) { toast("Copia non riuscita", true); } ta.remove();
  });
}
function react(c, m, e) {
  m.reacts = m.reacts || {};
  const now = m.reacts[App.me] === e ? "" : e;
  if (now) m.reacts[App.me] = now; else delete m.reacts[App.me];
  dispatch(c, d => `REACT|${d}|${m.id}|${now}`);
  refreshMsg(c, m);
}
function togglePin(c, m) {
  const pin = !m.pinned;
  if (pin) { const pins = c.msgs.filter(x => x.pinned && !x.deleted); if (pins.length >= 3) { pins[0].pinned = false; refreshMsg(c, pins[0]); } }
  m.pinned = pin; Net.send(`PIN|${destOf(c)}|${m.id}|${pin ? 1 : 0}`);
  system(c, pin ? "📌 Hai fissato un messaggio" : "Hai tolto un messaggio fissato");
  refreshMsg(c, m); renderPinned();
}
function editMessage(c, m, text) {
  if (text === m.text) return;
  if (!Net.send(`EDIT|${destOf(c)}|${m.id}|${Net.escape(text)}`)) return toast("Non sei connesso", true);
  m.text = text; m.edited = true; m.link = null; refreshMsg(c, m);
}
function deleteForAll(c, m) {
  Net.send(`DEL|${destOf(c)}|${m.id}`);
  if (m.loc && m.loc.liveTimer) Media.stopLive(c, m);
  m.deleted = true; m.pinned = false; refreshMsg(c, m); renderPinned(); renderChats();
}
function msgInfo(c, m) {
  const rows = [];
  if (c.group || c.bc) {
    const members = c.bc ? bcList(c.id)?.members || [] : (App.groups.get(c.id.slice(1))?.members || []).filter(n => !isMe(n));
    for (const n of members) { const st = (m.receipts || {})[n] || (m.receipts || {})[kc(n)]; rows.push(h("div", { class: "item" }, avatar(n), h("div", { class: "main" }, n), h("span", { class: "muted" }, st === "R" ? "✓✓ letto" : st === "D" ? "✓✓ consegnato" : "✓ inviato"))); }
  } else rows.push(h("p", {}, "Inviato: " + new Date(m.time).toLocaleString("it-IT")), h("p", {}, m.state === "R" ? "✓✓ Letto" + (m.readAt ? ": " + new Date(m.readAt).toLocaleString("it-IT") : "") : m.state === "D" ? "✓✓ Consegnato" + (m.deliveredAt ? ": " + new Date(m.deliveredAt).toLocaleString("it-IT") : "") : m.state === "failed" ? "⚠ Non consegnato: " + (m.error || "") : "✓ Inviato al server"));
  if (m.file && m.file.once) rows.push(h("p", {}, m.file.opened ? "👁 Già aperta" : "👁 Non ancora aperta"));
  sheet("Info messaggio", ...rows);
}
function forwardSheet(c, m) {
  const targets = visibleChats().filter(x => (x.group ? x.alive !== false : x.bc || isContact(x.id)) && !canSendReason(x));
  const picks = targets.map(x => ({ x, el: check((x.group ? "👥 " : x.bc ? "📢 " : "💬 ") + x.name, false, () => {}) }));
  const s = sheet("Inoltra a…", ...picks.map(p => p.el), h("button", { class: "btn primary block", style: "margin-top:10px", onclick: () => {
    const chosen = picks.filter(p => p.el.querySelector("input").checked).map(p => p.x);
    if (!chosen.length) return toast("Scegli almeno una chat", true);
    s.close();
    for (const t of chosen) {
      if (m.file && m.file.blob) Media.sendBlob(t, m.file.blob, m.file.kind, m.file.name, { sticker: m.file.sticker, dur: m.file.dur, fwd: true });
      else if (m.loc) Media.sendLocation(t, m.loc.lat, m.loc.lon, m.loc.acc, 0, m.loc.label);
      else if (m.poll) toast("I sondaggi non si inoltrano", true);
      else send(t, m.text, { fwd: true });
    }
    toast("Inoltrato a " + chosen.map(x => x.name).join(", "));
  } }, "Inoltra"));
}
function searchInChat(c) {
  const f = h("input", { class: "field", placeholder: "Cerca nei messaggi", value: App.chatSearch || "" });
  const res = h("div", {});
  const run = () => {
    App.chatSearch = f.value.trim(); res.innerHTML = "";
    if (!App.chatSearch) return;
    const q = kc(App.chatSearch);
    const found = c.msgs.filter(m => !m.deleted && !m.hiddenForMe && kc(m.text || (m.file && m.file.name) || (m.poll && m.poll.q) || "").includes(q));
    res.append(h("div", { class: "label" }, found.length + " RISULTATI"));
    found.slice(-50).reverse().forEach(m => res.append(h("div", { class: "item", onclick: () => { s.close(); renderMessages(); setTimeout(() => scrollToMsg(m.id), 50); } },
      h("div", { class: "main" }, h("div", { class: "name" }, m.dir === "out" ? "Tu" : m.who || c.name), h("div", { class: "sub" }, preview(m))), h("span", { class: "muted" }, time(m.time)))));
  };
  let t; f.addEventListener("input", () => { clearTimeout(t); t = setTimeout(run, 200); });
  const s = sheet("Cerca nella chat", f, res);
  s.onclose = () => { if (!App.chatSearch) return; setTimeout(() => { App.chatSearch = ""; }, 4000); };
  run(); setTimeout(() => f.focus(), 100);
}
function mediaSheet(c) {
  const media = c.msgs.filter(m => m.file && m.file.url && !m.deleted && !m.file.once && (m.file.kind === "IMAGE" || m.file.kind === "GIF" || m.file.kind === "VIDEO"));
  const docs = c.msgs.filter(m => m.file && !m.deleted && (m.file.kind === "FILE" || m.file.kind === "VOICE"));
  const links = c.msgs.filter(m => !m.deleted && /https?:\/\//.test(m.text || ""));
  const grid = h("div", { class: "grid3" }, ...media.map(m => h("div", { class: "cell", style: m.file.kind === "VIDEO" ? "" : `background-image:url(${m.file.url})`, onclick: () => { s.close(); scrollToMsg(m.id); } }, m.file.kind === "VIDEO" ? "🎬" : null)));
  const s = sheet("Media, link e documenti", h("div", { class: "label" }, `FOTO E VIDEO (${media.length})`), media.length ? grid : h("p", { class: "muted" }, "Nessuno"),
    h("div", { class: "label" }, `DOCUMENTI E VOCALI (${docs.length})`), ...docs.map(m => h("div", { class: "item", onclick: () => { s.close(); scrollToMsg(m.id); } }, preview(m))),
    h("div", { class: "label" }, `LINK (${links.length})`), ...links.map(m => h("div", { class: "item", onclick: () => { s.close(); scrollToMsg(m.id); } }, h("div", { class: "sub" }, (m.text.match(/https?:\/\/\S+/) || [""])[0]))));
}

// ================================================================ info di contatti e gruppi
function chatInfo(c) {
  if (c.bc) return editBroadcast(c.id.slice(1));
  if (c.group) return groupInfo(c.id.slice(1));
  const n = c.id; const on = App.users.has(kc(n));
  const groups = [...App.groups.values()].filter(g => g.members.some(x => kc(x) === kc(n)));
  const big = avatar(n, isContact(n) ? on : null); big.classList.add("big");
  const s = sheet(null, h("div", { style: "text-align:center" }, big, h("h2", { style: "margin:8px 0 0" }, n), h("div", { class: "muted" }, !isContact(n) ? "Non è un contatto" : on ? "Online" : "Offline")),
    h("div", { class: "row", style: "justify-content:center;margin:12px 0" },
      isContact(n) ? h("button", { class: "btn small", onclick: () => { s.close(); Calls.start(c, false); } }, "📞 Chiama") : null,
      isContact(n) ? h("button", { class: "btn small", onclick: () => { s.close(); Calls.start(c, true); } }, "📹 Video") : null,
      !isContact(n) && !App.outgoing.has(kc(n)) ? h("button", { class: "btn small primary", onclick: () => { Net.send(`CREQ|${n}`); s.close(); } }, "Chiedi il contatto") : null),
    h("div", { class: "item", onclick: () => { s.close(); mediaSheet(c); } }, h("span", { class: "mi" }, "🖼"), h("div", { class: "main" }, "Media, link e documenti")),
    h("div", { class: "item", onclick: () => { s.close(); timerSheet(c); } }, h("span", { class: "mi" }, "⏱"), h("div", { class: "main" }, "Messaggi a tempo"), h("span", { class: "muted" }, timerOf(c) ? "attivi" : "no")),
    h("div", { class: "item", onclick: () => { s.close(); Media.wallpaperSheet(c); } }, h("span", { class: "mi" }, "🎨"), h("div", { class: "main" }, "Sfondo della chat")),
    groups.length ? h("div", { class: "label" }, `GRUPPI IN COMUNE (${groups.length})`) : null,
    ...groups.map(g => h("div", { class: "item", onclick: () => { s.close(); openChat(chatOf("#" + g.id, true)); } }, h("span", { class: "mi" }, "👥"), h("div", { class: "main" }, g.name))),
    h("div", { class: "item danger", onclick: () => { s.close(); toggleBlock(c); } }, h("span", { class: "mi" }, "🚫"), h("div", { class: "main" }, isBlocked(n) ? "Sblocca " + n : "Blocca " + n)),
    isContact(n) ? h("div", { class: "item danger", onclick: async () => { s.close(); if (await confirmBox("Rimuovi contatto", `Rimuovere ${n} dai contatti?`, "Rimuovi", true)) Net.send(`CREMOVE|${n}`); } }, h("span", { class: "mi" }, "➖"), h("div", { class: "main" }, "Rimuovi dai contatti")) : null);
}
function groupInfo(gid) {
  const content = h("div", {});
  const s = sheet(null, content);
  App.groupSheet = { gid, redraw: draw };
  s.onclose = () => { App.groupSheet = null; };
  const photoIn = h("input", { type: "file", accept: "image/*", style: "display:none", onchange: async () => {
    const f = photoIn.files[0]; photoIn.value = ""; if (!f) return;
    const b64 = await Media.squareJpegB64(f, 256, 90 * 1024); if (!b64) return toast("Foto non valida", true);
    Net.send(`GPHOTO|${gid}|${b64}`);
  } });
  function draw() {
    const g = App.groups.get(gid); content.innerHTML = ""; if (!g) { content.append(h("p", {}, "Gruppo non più disponibile")); return; }
    const c = chatOf("#" + gid, true);
    const admin = g.admins.some(isMe), canEdit = admin || !g.onlyAdmins, member = c.alive !== false;
    const pic = g.photo ? avatar(g.name, null, g.photo) : h("div", { class: "avatar", html: svg("group", 'style="width:40px"') }); pic.classList.add("big");
    content.append(photoIn, h("div", { style: "text-align:center" }, h("div", { onclick: () => member && canEdit && photoIn.click(), style: "display:inline-block" }, pic),
      h("h2", { style: "margin:8px 0 0" }, g.name, member && canEdit ? h("button", { class: "iconbtn", style: "display:inline-grid;width:30px;height:30px", onclick: async () => { const n = await ask("Nome del gruppo", "", "Nome", g.name, "Salva"); if (n && n.trim()) Net.send(`GNAME|${gid}|${n.trim().replace(/\|/g, " ").slice(0, 40)}`); } }, "✏️") : null),
      h("div", { class: "muted" }, `Gruppo · ${g.members.length} membri`)),
      h("div", { class: "label" }, "DESCRIZIONE"),
      h("div", { class: "item", onclick: async () => { if (!member || !canEdit) return; const d = await ask("Descrizione del gruppo", "", "Descrizione", g.desc || "", "Salva"); if (d !== null) Net.send(`GDESC|${gid}|${Net.escField(d.slice(0, 500))}`); } },
        h("div", { class: "main" }, g.desc ? h("div", { style: "white-space:pre-wrap" }, g.desc) : h("span", { class: "muted" }, member && canEdit ? "Aggiungi una descrizione" : "Nessuna descrizione"))));
    if (admin && member) {
      content.append(h("div", { class: "label" }, "AMMINISTRAZIONE"),
        check("Solo gli amministratori possono scrivere e cambiare le info", g.onlyAdmins, v => Net.send(`GPERM|${gid}|${v ? 1 : 0}`)),
        h("div", { class: "item", onclick: () => inviteLink(g) }, h("span", { class: "mi" }, "🔗"), h("div", { class: "main" }, h("div", { class: "name" }, "Link d'invito"), h("div", { class: "sub" }, g.invite ? "Codice: " + g.invite : "Crea un codice per far entrare chi vuoi"))),
        h("div", { class: "item", onclick: () => addMembers(g) }, h("span", { class: "mi" }, "➕"), h("div", { class: "main" }, "Aggiungi persone")));
    }
    content.append(h("div", { class: "label" }, `MEMBRI (${g.members.length})`));
    for (const n of [...g.members].sort((a, b) => (isMe(b) - isMe(a)) || ((g.admins.includes(b)) - (g.admins.includes(a))) || a.localeCompare(b))) {
      const isAdm = g.admins.some(a => kc(a) === kc(n));
      content.append(h("div", { class: "item", onclick: () => memberMenu(g, n, admin && member) }, avatar(n, isMe(n) ? null : isContact(n) ? App.users.has(kc(n)) : null),
        h("div", { class: "main" }, h("div", { class: "name" }, isMe(n) ? "Tu" : n), !isContact(n) && !isMe(n) ? h("div", { class: "sub" }, "Non è un tuo contatto") : null),
        isAdm ? h("span", { class: "chip" }, "Admin") : null));
    }
    if (g.pending.length) { content.append(h("div", { class: "label" }, "INVITI IN ATTESA")); for (const n of g.pending) content.append(h("div", { class: "item" }, avatar(n), h("div", { class: "main" }, n), admin ? h("button", { class: "btn small", onclick: () => Net.send(`GINVCANCEL|${gid}|${n}`) }, "Annulla") : h("span", { class: "muted" }, "in attesa"))); }
    if (member) content.append(h("div", { style: "height:10px" }), h("div", { class: "item danger", onclick: () => { s.close(); leaveGroup(c); } }, h("span", { class: "mi" }, "🚪"), h("div", { class: "main" }, "Esci dal gruppo")));
  }
  draw();
}
function memberMenu(g, n, admin) {
  if (isMe(n)) return;
  const isAdm = g.admins.some(a => kc(a) === kc(n));
  menu(n, [
    isContact(n) ? ["💬", "Scrivi a " + n, () => { App.groupSheet = null; document.querySelectorAll(".sheet-wrap").forEach(w => w.remove()); openChat(chatOf(App.contacts.get(kc(n)), true)); }] :
      ["➕", "Chiedi il contatto", () => Net.send(`CREQ|${n}`)],
    admin ? ["⭐", isAdm ? "Togli da amministratore" : "Nomina amministratore", () => Net.send(`GADMIN|${g.id}|${n}|${isAdm ? 0 : 1}`)] : null,
    admin ? ["🚫", "Rimuovi dal gruppo", async () => { if (await confirmBox("Rimuovi", `Rimuovere ${n} dal gruppo?`, "Rimuovi", true)) Net.send(`GKICK|${g.id}|${n}`); }, true] : null
  ]);
}
function addMembers(g) {
  const picks = [...App.contacts.values()].filter(n => !g.members.some(m => kc(m) === kc(n)) && !g.pending.some(m => kc(m) === kc(n))).map(u => ({ u, el: check(u, false, () => {}) }));
  const s = sheet("Aggiungi persone", h("p", { class: "muted" }, "Riceveranno un invito e dovranno accettare."), ...picks.map(p => p.el),
    picks.length ? null : h("p", { class: "muted" }, "Tutti i tuoi contatti sono già nel gruppo."),
    h("button", { class: "btn primary block", onclick: () => { const who = picks.filter(p => p.el.querySelector("input").checked).map(p => p.u); if (!who.length) return; Net.send(`GADD|${g.id}|${who.join(",")}`); s.close(); } }, "Invita"));
}
function inviteLink(g) {
  if (g.invite === undefined) Net.send(`GINVITE|${g.id}|get`);
  const box = h("div", {});
  const draw = () => {
    box.innerHTML = "";
    const code = g.invite;
    box.append(h("p", { class: "muted" }, "Chi ha il codice entra nel gruppo senza bisogno di invito. Puoi revocarlo quando vuoi."),
      code ? h("div", { class: "invite-code", onclick: () => copyText(code) }, code) : h("p", {}, code === undefined ? "Caricamento…" : "Nessun codice attivo."),
      h("div", { class: "row", style: "flex-wrap:wrap" },
        h("button", { class: "btn small primary", onclick: () => Net.send(`GINVITE|${g.id}|new`) }, code ? "Nuovo codice" : "Crea codice"),
        code ? h("button", { class: "btn small", onclick: () => copyText(code) }, "Copia") : null,
        code ? h("button", { class: "btn small", onclick: () => { s.close(); shareToChat(`👥 Entra nel gruppo "${g.name}" su Ghost-chat con il codice: ${code}`); } }, "Condividi") : null,
        code ? h("button", { class: "btn small", onclick: () => Net.send(`GINVITE|${g.id}|revoke`) }, "Revoca") : null));
  };
  const s = sheet("Link d'invito", box);
  const old = App.groupSheet; App.groupSheet = { gid: g.id, redraw: () => { draw(); if (old) old.redraw(); } };
  s.onclose = () => { App.groupSheet = old; };
  draw();
}
function shareToChat(text) {
  const targets = visibleChats().filter(x => !canSendReason(x) && (x.group || x.bc || isContact(x.id)));
  const s = sheet("Condividi con…", ...targets.map(x => h("div", { class: "item", onclick: () => { s.close(); send(x, text); toast("Inviato a " + x.name); } }, chatAvatar(x, 38), x.name)));
}

// ================================================================ sondaggi e quiz
function pollComposer(c, quiz) {
  const q = h("input", { class: "field", placeholder: quiz ? "Domanda del quiz" : "Fai una domanda", maxlength: 255 });
  const opts = h("div", {}); let correct = 0;
  const addOpt = v => {
    if (opts.children.length >= 12) return;
    const i = h("input", { class: "field", placeholder: "Opzione " + (opts.children.length + 1), maxlength: 100, value: v || "", style: "margin-top:6px" });
    const row = h("div", { class: "row" }, i);
    if (quiz) { const idx = opts.children.length; const r = h("input", { type: "radio", name: "quizok", title: "Risposta giusta" }); if (idx === correct) r.checked = true; r.onchange = () => { correct = [...opts.children].indexOf(row); }; row.prepend(r); }
    opts.append(row);
  };
  addOpt(); addOpt();
  let multi = false, anon = false;
  const s = sheet(quiz ? "🧠 Nuovo quiz" : "📊 Nuovo sondaggio", q, h("label", { class: "lbl" }, quiz ? "Risposte (segna quella giusta)" : "Opzioni"), opts,
    h("button", { class: "btn small", style: "margin-top:6px", onclick: () => addOpt() }, "+ Aggiungi opzione"),
    !quiz ? check("Più risposte consentite", false, v => multi = v) : null,
    check("Voto anonimo (non si vede chi ha votato cosa)", false, v => anon = v),
    h("button", { class: "btn primary block", style: "margin-top:10px", onclick: async () => {
      const question = q.value.trim(); const list = [...opts.querySelectorAll("input.field")].map(i => i.value.trim()).filter(Boolean);
      if (!question || list.length < 2) return toast("Scrivi la domanda e almeno due opzioni", true);
      if (!(await checkSend(c))) return;
      const real = [...opts.children].map(r => r.querySelector("input.field").value.trim());
      const ok = quiz ? list.indexOf(real[correct]) : -1;
      if (quiz && ok < 0) return toast("Segna la risposta giusta", true);
      s.close(); sendPoll(c, question, list, quiz ? false : multi, anon, ok);
    } }, "Invia"));
}
function pollFlags(p) { return (p.multi && p.correct < 0 ? "1" : "0") + (p.anon ? "a" : "") + (p.correct >= 0 ? "q" + p.correct : ""); }
function sendPoll(c, q, options, multi, anon, correct) {
  const id = newId();
  const poll = { q, opts: options, multi, anon, correct: correct ?? -1, votes: {} };
  const line = d => `POLL|${d}|${id}|${pollFlags(poll)}|${Net.escField(q)}|${options.map(o => Net.escField(o)).join("|")}`;
  const m = { id, dir: "out", poll, time: Date.now() }; trackOut(c, m);
  if (!dispatch(c, line)) m.state = "failed";
  addMsg(c, m);
}
function renderPoll(c, m) {
  const p = m.poll; const mine = p.votes[App.me] || [];
  const voters = Object.entries(p.votes).filter(([, v]) => v.length);
  const total = voters.length; const quiz = p.correct >= 0; const answered = mine.length > 0;
  const box = h("div", { class: "poll" }, h("div", { class: "pq" }, (quiz ? "🧠 " : "📊 ") + p.q),
    h("div", { class: "muted", style: "font-size:.75em" }, quiz ? "Quiz · una risposta" : p.multi ? "Scegli una o più risposte" : "Scegli una risposta", p.anon ? " · anonimo" : ""));
  p.opts.forEach((o, i) => {
    const n = voters.filter(([, v]) => v.includes(i)).length; const pct = total ? Math.round(n * 100 / total) : 0;
    const chosen = mine.includes(i);
    const cls = "popt" + (chosen ? " on" : "") + (quiz && answered ? (i === p.correct ? " right" : chosen ? " wrong" : "") : "");
    box.append(h("div", { class: cls, onclick: e => { e.stopPropagation(); vote(c, m, i); } },
      h("div", { class: "pbar", style: `width:${(answered || m.dir === "out") ? pct : 0}%` }),
      h("span", { class: "pbox" }, chosen ? "✔" : ""), h("span", { class: "ptxt" }, o), (answered || m.dir === "out") ? h("b", {}, n) : null));
  });
  box.append(h("div", { class: "muted", style: "font-size:.75em;margin-top:4px;cursor:pointer", onclick: e => { e.stopPropagation(); pollVoters(m); } }, total + (total === 1 ? " voto" : " voti") + (p.anon ? "" : " · vedi chi ha votato")));
  return box;
}
function vote(c, m, i) {
  const p = m.poll; let mine = [...(p.votes[App.me] || [])];
  if (p.correct >= 0 && mine.length) return toast("Al quiz si risponde una volta sola");
  if (p.multi) mine = mine.includes(i) ? mine.filter(x => x !== i) : [...mine, i].sort((a, b) => a - b);
  else mine = mine.includes(i) && p.correct < 0 ? [] : [i];
  p.votes[App.me] = mine;
  Net.send(`VOTE|${destOf(c)}|${m.id}|${mine.join(",")}`);
  if (p.correct >= 0) toast(i === p.correct ? "✅ Risposta giusta!" : "❌ Risposta sbagliata");
  refreshMsg(c, m);
}
function pollVoters(m) {
  const p = m.poll;
  if (p.anon) return toast("Sondaggio anonimo: i voti sono segreti");
  sheet("Voti: " + p.q, ...p.opts.map((o, i) => h("div", {}, h("div", { class: "label" }, o.toUpperCase()),
    ...Object.entries(p.votes).filter(([, v]) => v.includes(i)).map(([n]) => h("div", { class: "item" }, avatar(n), isMe(n) ? "Tu" : n)))));
}

// ================================================================ comandi ricevuti
function fromSender(o, m) { return m && m.dir === "in" && (!o.group || kc(m.who) === kc(o.nick)); }
function sendAck(o, id, type) { Net.send(`ACK|${o.group ? o.chat.id : o.nick}|${id}|${type}|${Date.now()}`); }

Net.on("MSG", p => {
  const f = p.split("|"); const from = f[0], id = f[1], meta = f[2];
  const text = Net.unescape(f.slice(3).join("|"));
  const o = origin(from); const c = o.chat; if (!c || findMsg(c, id)) return;
  const mt = parseMeta(meta);
  const m = { id, dir: "in", who: o.group ? o.nick : null, text, time: Date.now(), replyTo: mt.r || null, fwd: mt.f === "1" };
  if (mt.q && m.replyTo) m.quote = unb64url(mt.q);
  let t = parseInt(mt.t || "0", 10) || 0; t = Math.max(0, Math.min(30 * 86400, t));
  if (!o.group) syncTimer(c, t, o.nick);
  if (t) { m.timer = t; m.expiresAt = Date.now() + t * 1000; }
  if (c.typing) delete c.typing[o.nick];
  if (o.group && new RegExp("@" + (App.me || "").replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + "\\b", "i").test(text) && App.active !== c) c.mentioned = true;
  addMsg(c, m);
  sendAck(o, id, "D");
  const a11y = Store.get("a11y", {});
  if (a11y.readAloud && App.active === c) AI.speak((o.group ? o.nick + " dice: " : "") + text);
  if (App.active === c) renderConvHead();
});
function syncTimer(c, t, nick) {
  const cur = timerOf(c);
  if (cur === t) return;
  setPref(c.id, "timer", t || null);
  system(c, t ? `⏱ ${nick} ha attivato i messaggi a tempo` : `⏱ ${nick} ha disattivato i messaggi a tempo`);
  if (App.active === c) renderConvHead();
}
Net.on("EDIT", p => {
  const f = p.split("|"); const o = origin(f[0]); const m = findMsg(o.chat, f[1]);
  if (!fromSender(o, m) || m.deleted || m.file || m.poll || m.loc) return;
  const t = Net.unescape(f.slice(2).join("|")); if (!t.trim()) return;
  m.text = t; m.edited = true; m.link = null; refreshMsg(o.chat, m);
});
Net.on("DEL", p => {
  const f = p.split("|"); const o = origin(f[0]); const m = findMsg(o.chat, f[1]);
  if (!fromSender(o, m) || m.deleted) return;
  m.deleted = true; m.pinned = false; m.link = null; if (m.file && m.file.url) { try { URL.revokeObjectURL(m.file.url); } catch (e) { /* niente */ } }
  refreshMsg(o.chat, m); renderPinned(); renderChats();
});
Net.on("ACK", p => {
  const f = p.split("|"); const o = origin(f[0]); if (!o.chat) return;
  let type = (f[2] || "").trim().toUpperCase();
  if (type === "R" && !Priv().readReceipts) type = "D";
  for (const id of (f[1] || "").split(",")) {
    let c = o.chat, m = findMsg(c, id.trim());
    if (!m && !o.group) { const bc = App.bcSent.get(id.trim()); if (bc) { c = bc[0]; m = bc[1]; } }
    if (!m || m.dir !== "out") continue;
    if (type === "O") { if (m.file) m.file.opened = true; }
    else if (c.group || c.bc) { m.receipts = m.receipts || {}; if (m.receipts[o.nick] !== "R") m.receipts[o.nick] = type; }
    else if (type === "R") { m.state = "R"; m.readAt = Date.now(); }
    else if (m.state !== "R") { m.state = "D"; m.deliveredAt = Date.now(); }
    if (m.state === "failed") m.state = "D";
    refreshMsg(c, m);
  }
});
Net.on("REACT", p => {
  const f = p.split("|"); const o = origin(f[0]); const m = findMsg(o.chat, f[1]); if (!m || m.deleted) return;
  const e = (f[2] || "").trim(); m.reacts = m.reacts || {};
  if (!e || e.length > 16) delete m.reacts[o.nick]; else m.reacts[o.nick] = e;
  refreshMsg(o.chat, m);
  if (m.dir === "out" && e && App.active !== o.chat && !prefs(o.chat.id).mute) toast(`${o.nick} ha reagito con ${e} a: ${preview(m).slice(0, 40)}`);
});
Net.on("PIN", p => {
  const f = p.split("|"); const o = origin(f[0]); const c = o.chat; const m = findMsg(c, f[1]); if (!m || m.deleted) return;
  const pin = (f[2] || "").trim() === "1";
  if (pin) { const pins = c.msgs.filter(x => x.pinned && !x.deleted && x !== m); if (pins.length >= 3) pins[0].pinned = false; }
  m.pinned = pin; system(c, `${o.nick} ${pin ? "ha fissato un messaggio" : "ha tolto un messaggio fissato"}`);
  if (App.active === c) renderMessages();
});
Net.on("TYPING", p => {
  if (!Priv().typing) return;
  const f = p.split("|"); const o = origin(f[0]); const c = o.chat; if (!c) return;
  const st = (f[1] || "").trim();
  c.typing = c.typing || {};
  if (st.startsWith("t") || st.startsWith("r")) c.typing[o.nick] = { s: st[0], until: Date.now() + 7000 }; else delete c.typing[o.nick];
  if (App.active === c) renderConvHead(); else renderChats();
});
Net.on("POLL", p => {
  const f = p.split("|"); const o = origin(f[0]); const c = o.chat; if (!c) return;
  const id = f[1], flags = (f[2] || "").trim();
  if (!id || findMsg(c, id) || f.length < 6) return;
  const q = Net.unescape(f[3]).trim().slice(0, 255);
  const opts = f.slice(4).map(x => Net.unescape(x).trim().slice(0, 100)).filter(Boolean).slice(0, 12);
  if (!q || opts.length < 2) return;
  const qm = /q(\d+)/.exec(flags); let correct = qm ? parseInt(qm[1], 10) : -1; if (correct >= opts.length) correct = -1;
  const poll = { q, opts, multi: flags.startsWith("1") && correct < 0, anon: flags.includes("a"), correct, votes: {} };
  addMsg(c, { id, dir: "in", who: o.group ? o.nick : null, poll, time: Date.now() });
  sendAck(o, id, "D");
});
Net.on("VOTE", p => {
  const f = p.split("|"); const o = origin(f[0]); const m = findMsg(o.chat, f[1]); if (!m || !m.poll || m.deleted) return;
  let sel = (f[2] || "").split(",").map(x => parseInt(x, 10)).filter(i => i >= 0 && i < m.poll.opts.length);
  if (!m.poll.multi) sel = sel.slice(0, 1);
  m.poll.votes[o.nick] = [...new Set(sel)];
  refreshMsg(o.chat, m);
});
Net.on("LINK", p => {
  const f = p.split("|"); const o = origin(f[0]); const m = findMsg(o.chat, f[1]);
  if (!fromSender(o, m) || m.deleted || !m.text || f.length < 6) return;
  const url = Net.unescape(f[2]); if (!(m.text || "").includes(url.replace(/\/$/, "")) && !(m.text || "").includes(url)) return;
  const img = (f[6] || "").trim();
  m.link = { url, title: Net.unescape(f[3]), desc: Net.unescape(f[4]), site: Net.unescape(f[5]), img: img && img.length < 140000 && /^[A-Za-z0-9+/=]+$/.test(img) ? img : null };
  refreshMsg(o.chat, m);
});

// ================================================================ messaggi programmati ed esportazione
const scheduled = [];
function scheduleSheet(c) {
  const ta = h("textarea", { class: "area", rows: 3, placeholder: "Messaggio da inviare più tardi" });
  const d = new Date(Date.now() + 3600000); d.setSeconds(0, 0);
  const pad = n => String(n).padStart(2, "0");
  const when = h("input", { class: "field", type: "datetime-local", value: `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}` });
  const mine = scheduled.filter(x => x.c === c);
  const s = sheet("🕒 Programma un messaggio", ta, h("label", { class: "lbl" }, "Quando"), when,
    h("p", { class: "muted" }, "Il messaggio parte all'ora scelta se Ghost-chat è aperta."),
    h("button", { class: "btn primary block", onclick: () => {
      const t = ta.value.trim(); const at = new Date(when.value).getTime();
      if (!t) return toast("Scrivi il messaggio", true);
      if (!(at > Date.now() + 5000)) return toast("Scegli un orario nel futuro", true);
      if (at - Date.now() > 7 * 86400000) return toast("Al massimo fra 7 giorni", true);
      const job = { c, t, at, timer: setTimeout(() => { scheduled.splice(scheduled.indexOf(job), 1); if (canSendReason(c) || !Net.isOnline()) system(c, "Messaggio programmato non inviato: la chat non era raggiungibile"); else send(c, t); }, at - Date.now()) };
      scheduled.push(job); s.close();
      system(c, `🕒 Messaggio programmato per ${new Date(at).toLocaleString("it-IT", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" })}: "${t.slice(0, 60)}"`);
    } }, "Programma"),
    mine.length ? h("div", { class: "label" }, "GIÀ PROGRAMMATI") : null,
    ...mine.map(j => h("div", { class: "item" }, h("div", { class: "main" }, h("div", { class: "name" }, new Date(j.at).toLocaleString("it-IT")), h("div", { class: "sub" }, j.t)),
      h("button", { class: "btn small", onclick: () => { clearTimeout(j.timer); scheduled.splice(scheduled.indexOf(j), 1); s.close(); system(c, "Messaggio programmato annullato"); } }, "Annulla"))));
}
function exportChat(c) {
  const lines = [`Chat con ${c.name} · esportata da Ghost-chat il ${new Date().toLocaleString("it-IT")}`, ""];
  for (const m of c.msgs) {
    if (m.hiddenForMe) continue;
    const who = m.dir === "sys" ? "—" : m.dir === "out" ? App.me : (m.who || c.name);
    lines.push(`[${new Date(m.time).toLocaleString("it-IT")}] ${who}: ${m.deleted ? "(messaggio eliminato)" : m.dir === "sys" ? m.text : (m.text != null && !m.file && !m.poll && !m.loc && !m.game && !m.wb ? m.text : preview(m))}${m.edited ? " (modificato)" : ""}`);
  }
  const url = URL.createObjectURL(new Blob([lines.join("\n")], { type: "text/plain;charset=utf-8" }));
  Media.download(url, `Chat con ${c.name.replace(/[^\w\- ]/g, "")}.txt`);
  toast("Chat esportata");
  setTimeout(() => URL.revokeObjectURL(url), 30000);
}
