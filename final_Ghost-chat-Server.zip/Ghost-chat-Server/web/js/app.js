/* Ghost-chat mobile · app principale (accesso, contatti, eventi dal server, elenco chat, impostazioni).
 * La conversazione e' in chat.js; media, giochi, chiamate e stati nei rispettivi file. */
"use strict";

// ================================================================ utilita' DOM
// append/prepend ignorano null e false (altrimenti il browser scrive "null" sullo schermo)
for (const fn of ["append", "prepend"]) {
  const orig = Element.prototype[fn];
  Element.prototype[fn] = function (...a) { return orig.apply(this, a.filter(x => x != null && x !== false)); };
}
function h(tag, attrs, ...kids) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (k === "class") el.className = v;
    else if (k === "html") el.innerHTML = v;
    else if (k.startsWith("on")) el.addEventListener(k.slice(2), v);
    else if (v !== false && v != null) el.setAttribute(k, v === true ? "" : v);
  }
  for (const k of kids.flat()) if (k != null && k !== false) el.append(k instanceof Node ? k : document.createTextNode(String(k)));
  return el;
}
const $ = s => document.querySelector(s);
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
const ICON = {
  chat: '<path d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2z"/>',
  back: '<path d="M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z"/>',
  send: '<path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/>',
  attach: '<path d="M16.5 6v11.5c0 2.21-1.79 4-4 4s-4-1.79-4-4V5a2.5 2.5 0 015 0v10.5c0 .55-.45 1-1 1s-1-.45-1-1V6H10v9.5a2.5 2.5 0 005 0V5c0-2.21-1.79-4-4-4S7 2.79 7 5v12.5c0 3.04 2.46 5.5 5.5 5.5s5.5-2.46 5.5-5.5V6h-1.5z"/>',
  settings: '<path d="M19.14 12.94c.04-.3.06-.61.06-.94 0-.32-.02-.64-.07-.94l2.03-1.58a.5.5 0 00.12-.61l-1.92-3.32a.5.5 0 00-.59-.22l-2.39.96a7 7 0 00-1.62-.94l-.36-2.54A.48.48 0 0013.92 2h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96a.5.5 0 00-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.05.3-.09.63-.09.94s.02.64.07.94l-2.03 1.58a.5.5 0 00-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32a.5.5 0 00-.12-.61l-2.01-1.58zM12 15.6a3.6 3.6 0 110-7.2 3.6 3.6 0 010 7.2z"/>',
  group: '<path d="M16 11c1.66 0 3-1.34 3-3s-1.34-3-3-3-3 1.34-3 3 1.34 3 3 3zm-8 0c1.66 0 3-1.34 3-3S9.66 5 8 5 5 6.34 5 8s1.34 3 3 3zm0 2c-2.33 0-7 1.17-7 3.5V19h14v-2.5c0-2.33-4.67-3.5-7-3.5zm8 0c-.29 0-.62.02-.97.05 1.16.84 1.97 1.97 1.97 3.45V19h6v-2.5c0-2.33-4.67-3.5-7-3.5z"/>',
  cards: '<path d="M21.47 4.35l-1.34-.56v9.03l2.43-5.86c.41-1.02-.06-2.19-1.09-2.61zm-19.5 3.7L6.93 20a2 2 0 002.6 1.1l7.37-3.05a2 2 0 001.1-2.6L13 3.5a2 2 0 00-2.58-1.1L3.06 5.45a2 2 0 00-1.09 2.6z"/>',
  personadd: '<path d="M15 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm-9-2V7H4v3H1v2h3v3h2v-3h3v-2H6zm9 4c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/>',
  speaker: '<path d="M3 9v6h4l5 5V4L7 9H3zm13.5 3A4.5 4.5 0 0014 7.97v8.05c1.48-.73 2.5-2.25 2.5-4.02z"/>',
  phone: '<path d="M6.62 10.79a15.05 15.05 0 006.59 6.59l2.2-2.2a1 1 0 011.02-.24c1.12.37 2.33.57 3.57.57a1 1 0 011 1V20a1 1 0 01-1 1A17 17 0 013 4a1 1 0 011-1h3.5a1 1 0 011 1c0 1.25.2 2.45.57 3.57a1 1 0 01-.25 1.02l-2.2 2.2z"/>',
  video: '<path d="M17 10.5V7a1 1 0 00-1-1H4a1 1 0 00-1 1v10a1 1 0 001 1h12a1 1 0 001-1v-3.5l4 4v-11l-4 4z"/>',
  more: '<path d="M12 8a2 2 0 100-4 2 2 0 000 4zm0 2a2 2 0 100 4 2 2 0 000-4zm0 6a2 2 0 100 4 2 2 0 000-4z"/>',
  mic: '<path d="M12 14a3 3 0 003-3V5a3 3 0 00-6 0v6a3 3 0 003 3zm5.3-3c0 3-2.54 5.1-5.3 5.1S6.7 14 6.7 11H5c0 3.41 2.72 6.23 6 6.72V21h2v-3.28c3.28-.48 6-3.3 6-6.72h-1.7z"/>',
  smile: '<path d="M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20a8 8 0 110-16 8 8 0 010 16zm3.5-9a1.5 1.5 0 100-3 1.5 1.5 0 000 3zm-7 0a1.5 1.5 0 100-3 1.5 1.5 0 000 3zm3.5 6.5a5.5 5.5 0 005.11-3.5H6.89A5.5 5.5 0 0012 17.5z"/>',
  plus: '<path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"/>',
  close: '<path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/>',
  search: '<path d="M15.5 14h-.79l-.28-.27a6.5 6.5 0 10-.7.7l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0a4.5 4.5 0 110-9 4.5 4.5 0 010 9z"/>',
  pin: '<path d="M16 9V4h1V2H7v2h1v5c0 1.66-1.34 3-3 3v2h5.97v7l1 1 1-1v-7H19v-2c-1.66 0-3-1.34-3-3z"/>',
  star: '<path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"/>',
  lock: '<path d="M18 8h-1V6A5 5 0 007 6v2H6a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V10a2 2 0 00-2-2zm-6 9a2 2 0 110-4 2 2 0 010 4zm3.1-9H8.9V6a3.1 3.1 0 016.2 0v2z"/>',
  end: '<path d="M12 9c-1.6 0-3.15.25-4.6.72v3.1c0 .39-.23.74-.56.9-.98.49-1.87 1.12-2.66 1.85a1 1 0 01-1.41-.01L.29 13.08a1 1 0 010-1.41C3.34 8.78 7.46 7 12 7s8.66 1.78 11.71 4.67a1 1 0 010 1.41l-2.48 2.48a1 1 0 01-1.41.01 11.4 11.4 0 00-2.67-1.85 1 1 0 01-.56-.9v-3.1C15.15 9.25 13.6 9 12 9z"/>'
};
const svg = (name, extra = "") => `<svg viewBox="0 0 24 24" fill="currentColor" ${extra}>${ICON[name]}</svg>`;
function icon(name) { const s = h("span"); s.innerHTML = svg(name); return s.firstChild; }
const GHOST_SVG = (fill = "currentColor") => `<path fill="${fill}" d="M6 12a6 6 0 0112 0v8.5l-2-1.6-2 1.6-2-1.6-2 1.6-2-1.6-2 1.6z"/><circle cx="10" cy="12" r="1.3" fill="#fff"/><circle cx="14" cy="12" r="1.3" fill="#fff"/>`;
const COFFIN_SVG = `<svg viewBox="0 0 24 24" class="coffin"><g class="peek"><path fill="#fff" d="M9 13a3 3 0 016 0v6H9z"/><circle cx="11" cy="13" r=".8" fill="#4A126C"/><circle cx="13" cy="13" r=".8" fill="#4A126C"/></g><path fill="currentColor" opacity=".35" d="M8.5 2h7l3.5 5-3 15H8L5 7z"/><g class="lid"><path fill="currentColor" d="M8.5 2h7l3.5 5-3 15H8L5 7z"/><path stroke="var(--surface)" stroke-width="1.6" stroke-linecap="round" d="M12 6v6M9.8 8.2h4.4"/><circle cx="10.4" cy="15" r=".9" fill="var(--surface)"/><circle cx="13.6" cy="15" r=".9" fill="var(--surface)"/></g></svg>`;
const AI_SVG = `<svg viewBox="0 0 32 32" class="aighost"><g class="body"><path fill="currentColor" d="M9 16a7 7 0 0114 0v9l-2.3-1.8-2.3 1.8-2.4-1.8-2.3 1.8-2.4-1.8L9 25z"/><circle cx="13.6" cy="16" r="1.5" fill="var(--surface)"/><circle cx="18.4" cy="16" r="1.5" fill="var(--surface)"/></g><g class="orbit"><path class="spark" fill="#FFC107" d="M6 6q0 3 3 3q-3 0-3 3q0-3-3-3q3 0 3-3z"/><path class="spark" fill="var(--accent2)" d="M26 6q0 2 2 2q-2 0-2 2q0-2-2-2q2 0 2-2z"/><path class="spark" fill="#FFC107" d="M27 24q0 2 2 2q-2 0-2 2q0-2-2-2q2 0 2-2z"/></g></svg>`;

function toast(text, error) {
  const t = h("div", { class: "toast glass" + (error ? " error" : "") }, text);
  document.body.append(t); setTimeout(() => t.remove(), 3200);
}
function sheet(title, ...content) {
  const s = h("div", { class: "sheet glass" }, title ? h("h3", {}, title) : null, ...content);
  const wrap = h("div", { class: "sheet-wrap", onclick: e => { if (e.target === wrap) close(); } }, s);
  let closed = false;
  const res = { el: s, onclose: null, close: () => { if (closed) return; closed = true; wrap.remove(); if (res.onclose) res.onclose(); } };
  document.body.append(wrap);
  return res;
  function close() { res.close(); }
}
/** Elenco di azioni in un foglio: [icona/emoji, testo, funzione, pericolosa?] */
function menu(title, items) {
  const s = sheet(title, ...items.filter(Boolean).map(([ic, t, fn, danger]) => h("div", { class: "item" + (danger ? " danger" : ""), onclick: () => { s.close(); fn(); } },
    h("span", { class: "mi" }, ic), h("div", { class: "main" }, h("div", { class: "name" }, t)))));
  return s;
}
function ask(title, text, placeholder, value, okText) {
  return new Promise(res => {
    const f = h("input", { class: "field", placeholder: placeholder || "", value: value || "" });
    const s = sheet(title, text ? h("p", { class: "muted" }, text) : null, f,
      h("div", { class: "row", style: "margin-top:10px" }, h("button", { class: "btn", onclick: () => { s.close(); } }, "Annulla"),
        h("button", { class: "btn primary", onclick: () => { const v = f.value; done = true; s.close(); res(v); } }, okText || "OK")));
    let done = false; s.onclose = () => { if (!done) res(null); };
    f.addEventListener("keydown", e => { if (e.key === "Enter") { done = true; s.close(); res(f.value); } });
    setTimeout(() => f.focus(), 120);
  });
}
function confirmBox(title, text, okText, danger) {
  return new Promise(res => {
    let done = false;
    const s = sheet(title, h("p", {}, text), h("div", { class: "row", style: "margin-top:10px" },
      h("button", { class: "btn", onclick: () => s.close() }, "Annulla"),
      h("button", { class: "btn primary" + (danger ? " danger" : ""), onclick: () => { done = true; s.close(); res(true); } }, okText || "OK")));
    s.onclose = () => { if (!done) res(false); };
  });
}
function check(label, value, onChange, radio, name) {
  const inp = h("input", { type: radio ? "radio" : "checkbox", name: name || null });
  inp.checked = !!value; inp.addEventListener("change", () => onChange(inp.checked));
  return h("label", { class: "check" + (radio ? " radio" : "") }, inp, h("span", { class: "box" }), h("span", {}, label));
}
function select(options, value, onChange) {
  const s = h("select", { onchange: () => onChange(s.value) }, options.map(([v, t]) => { const o = h("option", { value: v }, t); if (String(v) === String(value)) o.selected = true; return o; }));
  return h("div", { class: "select" }, s);
}
function avatar(nick, online, img) {
  const a = h("div", { class: "avatar" });
  const pic = img || App.avatars[(nick || "").toLowerCase()];
  if (pic) a.append(h("img", { src: pic, alt: "" })); else a.append((nick || "?").replace(/^#/, "").slice(0, 1).toUpperCase());
  if (online !== undefined && online !== null) a.append(h("span", { class: "dot" + (online ? "" : " off") }));
  return a;
}
function chatAvatar(c, size) {
  let a;
  if (c.bc) a = h("div", { class: "avatar", html: "📢" });
  else if (c.group) { const g = App.groups.get(c.id.slice(1)); a = g && g.photo ? avatar(c.name, null, g.photo) : h("div", { class: "avatar", html: svg("group", 'style="width:26px"') }); }
  else a = avatar(c.id, App.users.has(kc(c.id)));
  if (size) { a.style.width = a.style.height = size + "px"; }
  return a;
}
const time = t => new Date(t).toLocaleTimeString("it-IT", { hour: "2-digit", minute: "2-digit" });
const dayLabel = t => { const d = new Date(t), n = new Date(); const y = new Date(n); y.setDate(n.getDate() - 1);
  if (d.toDateString() === n.toDateString()) return "Oggi"; if (d.toDateString() === y.toDateString()) return "Ieri";
  return d.toLocaleDateString("it-IT", { weekday: "long", day: "numeric", month: "long" }); };
let idCounter = 0;
const newId = () => Math.floor(Math.random() * 2 ** 40).toString(36) + Date.now().toString(36).slice(-4) + (++idCounter).toString(36);
const kc = n => (n || "").trim().toLowerCase();
const isMe = n => kc(n) === kc(App.me);
function vibrate(p) { try { if (navigator.vibrate) navigator.vibrate(p); } catch (e) { /* niente */ } }
function fmtDur(ms) { const s = Math.max(0, Math.round(ms / 1000)); return Math.floor(s / 60) + ":" + String(s % 60).padStart(2, "0"); }
async function sha256hex(s) {
  const d = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(s));
  return [...new Uint8Array(d)].map(b => b.toString(16).padStart(2, "0")).join("");
}
function randHex(n) { const b = new Uint8Array(n); crypto.getRandomValues(b); return [...b].map(x => x.toString(16).padStart(2, "0")).join(""); }
function b64url(s) { return btoa(unescape(encodeURIComponent(s))).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, ""); }
function unb64url(s) { try { s = s.replace(/-/g, "+").replace(/_/g, "/"); while (s.length % 4) s += "="; return decodeURIComponent(escape(atob(s))); } catch (e) { return null; } }
function parseMeta(meta) { const m = {}; for (const kv of String(meta || "").split(";")) { const i = kv.indexOf("="); if (i > 0) m[kv.slice(0, i).trim()] = kv.slice(i + 1).trim(); } return m; }
function buildMeta(o) { return Object.entries(o).filter(([, v]) => v != null && v !== "").map(([k, v]) => k + "=" + String(v).replace(/[|;=]/g, "")).join(";"); }
function longPress(el, fn) {
  let t = null, sx = 0, sy = 0, fired = false;
  el.addEventListener("pointerdown", e => { fired = false; sx = e.clientX; sy = e.clientY; clearTimeout(t); t = setTimeout(() => { fired = true; vibrate(15); fn(e); }, 480); });
  el.addEventListener("pointermove", e => { if (Math.abs(e.clientX - sx) > 10 || Math.abs(e.clientY - sy) > 10) clearTimeout(t); });
  ["pointerup", "pointercancel", "pointerleave"].forEach(ev => el.addEventListener(ev, () => clearTimeout(t)));
  el.addEventListener("contextmenu", e => { e.preventDefault(); clearTimeout(t); if (!fired) fn(e); });
  el.addEventListener("click", e => { if (fired) { e.stopPropagation(); e.preventDefault(); fired = false; } }, true);
}

// ================================================================ stato dell'app
const App = {
  me: null, email: "", verified: false, users: new Set(), chats: new Map(), groups: new Map(),
  active: null, avatars: {}, tab: "chat", transfers: new Map(),
  server: Store.get("server", { host: DEFAULT_SERVER.host, port: DEFAULT_SERVER.port, tls: false }),
  contacts: new Map(), incoming: new Map(), outgoing: new Map(), searches: new Map(),
  blocked: new Set(Store.get("blocked", [])), listFilter: "all", showArchived: false, listQuery: ""
};
// final: server online 24/7 (una sola porta per tutto). Si puo' cambiare dalla schermata di accesso.
if (!Store.get("onlineServer", false)) {
  Store.set("onlineServer", true);
  App.server = { host: DEFAULT_SERVER.host, port: DEFAULT_SERVER.port, tls: false };
  Store.set("server", App.server);
}
const Priv = () => Object.assign({ hidePresence: false, readReceipts: true, typing: true, sounds: true }, Store.get("priv", {}));
const setPriv = (k, v) => { const p = Priv(); p[k] = v; Store.set("priv", p); };
const isContact = n => App.contacts.has(kc(n));
const isBlocked = n => App.blocked.has(kc(n));
function setBlocked(n, b) { if (b) App.blocked.add(kc(n)); else App.blocked.delete(kc(n)); Store.set("blocked", [...App.blocked]); }

// preferenze locali delle chat (fissata, archiviata, silenziata, messaggi a tempo, sfondo)
function prefs(id) { const all = Store.get("cp", {}); return all[id] || {}; }
function setPref(id, k, v) { const all = Store.get("cp", {}); all[id] = Object.assign(all[id] || {}, { [k]: v }); if (v == null || v === false) delete all[id][k]; Store.set("cp", all); }

function chatOf(id, create) {
  let c = App.chats.get(id);
  if (!c && create) {
    const group = id.startsWith("#"), bc = id.startsWith("~");
    c = { id, group, bc, name: group ? (App.groups.get(id.slice(1))?.name || id) : bc ? (bcList(id)?.name || "Lista broadcast") : id,
      msgs: [], unread: 0, last: 0, typing: {}, alive: true };
    App.chats.set(id, c);
  }
  return c;
}
function findMsg(c, id) { if (!c) return null; for (let i = c.msgs.length - 1; i >= 0; i--) if (c.msgs[i].id === id) return c.msgs[i]; return null; }
function addMsg(c, m, notify) {
  c.msgs.push(m); c.last = m.time || Date.now();
  if (c.msgs.length > 2000) c.msgs.splice(0, c.msgs.length - 2000);
  const visible = App.active === c && App.tab === "chat" && document.visibilityState === "visible";
  if (m.dir === "in" && !visible) { c.unread++; if (notify !== false) incomingAlert(c, m); }
  if (App.active === c) appendBubble(c, m); else renderChats();
  updateBadges();
}
function system(c, text) { addMsg(c, { id: "s" + newId(), dir: "sys", text, time: Date.now() }, false); }
function incomingAlert(c, m) {
  if (prefs(c.id).mute) return;
  const a11y = Store.get("a11y", {});
  if (a11y.visualAlerts) { const f = h("div", { class: "flash" }); document.body.append(f); setTimeout(() => f.remove(), 1000); }
  if (Priv().sounds) { vibrate([30, 40, 30]); Sound.beep(); }
  if (App.active !== c) toast((c.group ? c.name + " · " + (m.who || "") : c.name) + ": " + preview(m).slice(0, 60));
}
const Sound = (() => {
  let ctx = null;
  function beep(freq = 880, dur = .09, vol = .05) {
    try { ctx = ctx || new (window.AudioContext || window.webkitAudioContext)(); const o = ctx.createOscillator(), g = ctx.createGain();
      o.frequency.value = freq; g.gain.value = vol; o.connect(g); g.connect(ctx.destination); o.start(); g.gain.exponentialRampToValueAtTime(.0001, ctx.currentTime + dur); o.stop(ctx.currentTime + dur + .02);
    } catch (e) { /* niente */ }
  }
  return { beep, ctx: () => (ctx = ctx || new (window.AudioContext || window.webkitAudioContext)()) };
})();

// liste broadcast (solo su questo telefono, come sul computer)
function bcLists() { return Store.get("bcs", []); }
function bcList(id) { return bcLists().find(b => "~" + b.id === id); }
function saveBc(list) { Store.set("bcs", list); }

// ================================================================ accesso
function showLogin(error) {
  App.me = null;
  setScreen("login");
  const s = App.server;
  const scr = $("#login");
  scr.innerHTML = "";
  let mode = "login";
  const host = h("input", { class: "field", placeholder: "Indirizzo del server (IP o nome)", value: s.host, autocapitalize: "off", autocorrect: "off" });
  const port = h("input", { class: "field", placeholder: "Porta", value: s.port, inputmode: "numeric", style: "max-width:110px" });
  const tls = check("Connessione cifrata (wss) · solo con un certificato valido", s.tls, () => {});
  const user = h("input", { class: "field", placeholder: "Nome utente", value: Store.get("user", ""), autocapitalize: "off", maxlength: 20 });
  const pass = h("input", { class: "field", type: "password", placeholder: "Password" });
  const regUser = h("input", { class: "field", placeholder: "Nome utente univoco", autocapitalize: "off", maxlength: 20 });
  const regPass = h("input", { class: "field", type: "password", placeholder: "Password" });
  const pass2 = h("input", { class: "field", type: "password", placeholder: "Ripeti la password" });
  const email = h("input", { class: "field", type: "email", placeholder: "Email (facoltativa)" });
  const codeMail = h("input", { class: "field", type: "email", placeholder: "Email dell'account" });
  const code = h("input", { class: "field", inputmode: "numeric", maxlength: 6, placeholder: "Codice di 6 cifre" });
  const msg = h("div", { class: "err" }, error || "");
  const go = h("button", { class: "btn primary block", onclick: submit }, "Accedi");
  const sendCode = h("button", { class: "btn small", onclick: requestCode }, "Invia codice");
  const panes = {
    login: h("div", {}, h("label", { class: "lbl" }, "Nome utente"), user, h("label", { class: "lbl" }, "Password"), pass),
    register: h("div", {}, h("label", { class: "lbl" }, "Nome utente"), regUser, h("label", { class: "lbl" }, "Password (almeno 6 caratteri)"),
      regPass, h("label", { class: "lbl" }, "Conferma"), pass2, h("label", { class: "lbl" }, "Email per l'accesso rapido"), email),
    code: h("div", {}, h("label", { class: "lbl" }, "Email dell'account"), h("div", { class: "row" }, codeMail, sendCode), h("label", { class: "lbl" }, "Codice ricevuto"), code)
  };
  const seg = h("div", { class: "seg" });
  const setMode = m => {
    mode = m;
    [...seg.children].forEach(b => b.classList.toggle("on", b.dataset.m === m));
    for (const k in panes) panes[k].style.display = k === m ? "" : "none";
    go.textContent = m === "login" ? "Accedi" : m === "register" ? "Crea account ed entra" : "Entra con il codice";
    msg.textContent = "";
  };
  [["login", "Accedi"], ["register", "Registrati"], ["code", "Codice email"]].forEach(([m, t]) => seg.append(h("button", { "data-m": m, onclick: () => setMode(m) }, t)));
  const auto = check("Resta collegato", Store.get("autoLogin", true), v => Store.set("autoLogin", v));
  const reset = h("button", { class: "btn small", style: "margin-top:6px", onclick: () => { host.value = DEFAULT_SERVER.host; port.value = DEFAULT_SERVER.port; } }, "Server predefinito");
  scr.append(h("div", { class: "login glass" },
    h("div", { html: `<svg class="ghost-hero" viewBox="0 0 24 24">${GHOST_SVG("var(--accent)")}</svg>` }),
    h("h2", {}, "Benvenuto su Ghost-chat"), seg, panes.login, panes.register, panes.code,
    h("label", { class: "lbl" }, "Server"), h("div", { class: "row" }, host, port), reset, tls, auto, msg, go,
    h("p", { class: "muted", style: "text-align:center" }, "I messaggi vivono solo finché l'app è aperta. La password protegge il tuo nome utente.")));
  [user, pass, regUser, regPass, pass2, code].forEach(i => i.addEventListener("keydown", e => { if (e.key === "Enter") submit(); }));
  setMode("login");

  function server() {
    const hst = host.value.trim(), p = parseInt(port.value, 10);
    if (!hst) { msg.textContent = "Scrivi l'indirizzo del server"; return null; }
    if (!(p > 0 && p < 65536)) { msg.textContent = "Porta non valida"; return null; }
    App.server = { host: hst, port: p, tls: tls.querySelector("input").checked };
    Store.set("server", App.server);
    return App.server;
  }
  async function requestCode() {
    const s2 = server(); if (!s2) return;
    const e = codeMail.value.trim();
    if (!/^[^@\s]+@[^@\s]+\.[a-z]{2,}$/i.test(e)) { msg.textContent = "Email non valida"; return; }
    msg.textContent = "Invio del codice..."; msg.className = "muted";
    const r = await Net.oneShot(s2.host, s2.port, s2.tls, "MAILCODE|" + e, "MAILCODE");
    const f = r.split("|");
    msg.className = f[0] === "ok" ? "ok" : "err";
    msg.textContent = f[0] === "ok" ? "Codice inviato a " + (f[1] || e) + ": controlla la posta" : (f[1] || "Invio non riuscito");
  }
  function submit() {
    msg.className = "err"; msg.textContent = "";
    let line;
    if (mode === "login") {
      const u = user.value.trim();
      if (!u || !pass.value) { msg.textContent = "Scrivi nome utente e password"; return; }
      line = `AUTH|login|${u}|${Net.b64(pass.value)}`;
    } else if (mode === "register") {
      const u = regUser.value.trim();
      if (!u || /[|;@\\#/,:\s~]/.test(u) || u.length > 20) { msg.textContent = "Nome utente non valido (max 20 caratteri, senza spazi né | ; @ \\ # / , : ~)"; return; }
      if (regPass.value.length < 6) { msg.textContent = "La password deve avere almeno 6 caratteri"; return; }
      if (regPass.value !== pass2.value) { msg.textContent = "Le password non coincidono"; return; }
      line = `AUTH|register|${u}|${Net.b64(regPass.value)}||${email.value.trim()}`;
    } else {
      if (!/^\d{6}$/.test(code.value.trim())) { msg.textContent = "Il codice ha 6 cifre"; return; }
      line = `AUTH|code|${codeMail.value.trim()}|${code.value.trim()}`;
    }
    const s2 = server(); if (!s2) return;
    go.disabled = true; go.textContent = "Connessione...";
    Net.connect(s2.host, s2.port, s2.tls, line);
  }
}

Net.on("WELCOME", p => {
  const f = p.split("|");
  if (App.lastUser && kc(App.lastUser) !== kc(f[0])) {
    App.contacts.clear(); App.incoming.clear(); App.outgoing.clear(); App.chats.clear(); App.groups.clear(); App.active = null; App.avatars = {};
    if ((typeof Status !== "undefined")) Status.reset();
  }
  App.lastUser = f[0];
  App.me = f[0]; App.email = f[3] || ""; App.verified = f[4] === "1";
  Store.set("user", App.me);
  if (f[2] && Store.get("autoLogin", true)) Store.set("token", f[2]);
  // stato online nascosto e foto profilo (il server non le ricorda tra una connessione e l'altra)
  if (Priv().hidePresence) Net.send("PRESENCE|1");
  const myPic = Store.get("myAvatar", "");
  if (myPic) { Net.send("AVATAR|" + myPic); App.avatars[kc(App.me)] = "data:image/jpeg;base64," + myPic; }
  const was = $("#main").classList.contains("active");
  setScreen("main"); if (!was) showTab(App.tab || "chat"); else if (App.tab === "chat") (App.active ? renderConversation() : renderChats());
});
Net.on("AUTHERR", p => { const r = p.split("|")[0]; if (r.startsWith("Sessione")) Store.set("token", ""); showLogin(r); });
Net.on("NICKERR", p => showLogin(p));
Net.on("_failed", r => { if (!App.me) showLogin(r); else toast(r, true); });
Net.on("_lost", d => { toast("Connessione persa: nuovo tentativo tra " + d + " s", true); App.users.clear(); renderChats(); if (App.active) renderConvHead(); });
Net.on("BYE", r => toast(r, true));

// ================================================================ eventi dal server
function computeOnline() {
  // nick@ip@nascosto. Solo i propri contatti (il server nuovo li filtra gia'; quello vecchio no).
  const on = new Set();
  for (const e of (App.lastList || "").split(";").filter(Boolean)) {
    const f = e.split("@"); const n = f[0];
    if (!n || isMe(n) || f[2] === "1") continue;
    if (isContact(n)) on.add(kc(n));
  }
  App.users = on;
}
Net.on("LIST", p => { App.lastList = p; computeOnline(); renderChats(); if (App.active) renderConvHead(); if (App.contactsSheet) App.contactsSheet.redraw(); });
function refreshContacts() {
  computeOnline();
  renderChats(); if (App.contactsSheet) App.contactsSheet.redraw(); updateBadges(); if (App.active) renderConvHead();
}
Net.on("CONTACTS", p => { App.contacts.clear(); for (const n of p.split(",").filter(Boolean)) { App.contacts.set(kc(n), n); chatOf(n, true); } refreshContacts(); });
Net.on("CONTACTADD", n => {
  const isNew = !App.contacts.has(kc(n));
  App.contacts.set(kc(n), n); App.incoming.delete(kc(n)); App.outgoing.delete(kc(n)); chatOf(n, true);
  if (isNew) toast(`Ora tu e ${n} siete contatti: potete scrivervi!`);
  refreshContacts();
});
Net.on("CONTACTDEL", n => { App.contacts.delete(kc(n)); App.users.delete(kc(n)); toast(`${n} non è più tra i tuoi contatti`, true); refreshContacts(); });
Net.on("CREQOUT", n => { App.outgoing.set(kc(n), n); refreshContacts(); });
Net.on("CREQGONE", n => { App.incoming.delete(kc(n)); App.outgoing.delete(kc(n)); refreshContacts(); });
Net.on("CREQNO", n => { App.outgoing.delete(kc(n)); toast(`${n} non ha accettato la tua richiesta di contatto`, true); refreshContacts(); });
Net.on("CREQERR", p => { const f = p.split("|"); toast(f[1] || "Richiesta non riuscita", true); });
Net.on("CREQIN", n => {
  App.incoming.set(kc(n), n); refreshContacts();
  if (isBlocked(n)) return;
  vibrate([40, 60, 40]);
  const s = sheet("Richiesta di contatto",
    h("div", { class: "item", style: "pointer-events:none" }, avatar(n), h("div", { class: "main" }, h("div", { class: "name" }, n), h("div", { class: "sub" }, "vuole scriverti su Ghost-chat"))),
    h("p", { class: "muted" }, "Se accetti potrete scambiarvi messaggi, file, chiamate e giochi. Se rifiuti non potrà scriverti."),
    h("div", { class: "row" }, h("button", { class: "btn", onclick: () => { Net.send(`CANSWER|${n}|0`); s.close(); } }, "Rifiuta"),
      h("button", { class: "btn", onclick: () => s.close() }, "Più tardi"),
      h("button", { class: "btn primary", onclick: () => { Net.send(`CANSWER|${n}|1`); s.close(); } }, "Accetta")));
});
Net.on("USEARCHR", p => {
  const i = p.indexOf("|"); const id = p.slice(0, i); const cb = App.searches.get(id); App.searches.delete(id);
  const res = p.slice(i + 1).split(";").filter(Boolean).map(r => r.split(":"));
  if (cb) cb(res);
});
let searchSeq = 0;
function searchUsers(q, cb) { const id = "m" + (++searchSeq); App.searches.set(id, cb); Net.send(`USEARCH|${id}|${q.replace(/[|\n]/g, "")}`); }
function contactsSheet() {
  const field = h("input", { class: "field", placeholder: "Cerca un nome utente...", autocapitalize: "off", autocorrect: "off" });
  const results = h("div", {}); const lists = h("div", {});
  let last = [], timer = null;
  const btn = (t, primary, fn) => h("button", { class: "btn" + (primary ? " primary" : ""), style: "padding:6px 12px;font-size:13px", onclick: e => { e.stopPropagation(); fn(); } }, t);
  const row = (n, sub, ...b) => h("div", { class: "item" }, avatar(n, isContact(n) ? App.users.has(kc(n)) : null), h("div", { class: "main" }, h("div", { class: "name" }, n), sub ? h("div", { class: "sub" }, sub) : null), ...b);
  const write = n => { s.close(); showTab("chat"); openChat(chatOf(n, true)); };
  function redraw() {
    results.innerHTML = ""; lists.innerHTML = "";
    if (field.value.trim()) {
      results.append(h("div", { class: "label" }, "RISULTATI"));
      if (!last.length) results.append(h("div", { class: "muted", style: "padding:6px" }, "Nessun utente con questo nome"));
      for (const [n, st, on] of last) {
        if (st === "c") results.append(row(n, on === "1" ? "Contatto · online" : "Contatto", btn("Scrivi", true, () => write(n))));
        else if (st === "o") results.append(row(n, "Richiesta inviata", btn("Annulla", false, () => Net.send(`CCANCEL|${n}`))));
        else if (st === "i") results.append(row(n, "Vuole scriverti", btn("Rifiuta", false, () => Net.send(`CANSWER|${n}|0`)), btn("Accetta", true, () => Net.send(`CANSWER|${n}|1`))));
        else results.append(row(n, "", btn("Chiedi di scriverti", true, () => Net.send(`CREQ|${n}`))));
      }
    }
    if (App.incoming.size) { lists.append(h("div", { class: "label" }, "RICHIESTE RICEVUTE")); for (const n of App.incoming.values()) lists.append(row(n, "Vuole scriverti", btn("Rifiuta", false, () => Net.send(`CANSWER|${n}|0`)), btn("Accetta", true, () => Net.send(`CANSWER|${n}|1`)))); }
    if (App.outgoing.size) { lists.append(h("div", { class: "label" }, "RICHIESTE INVIATE")); for (const n of App.outgoing.values()) lists.append(row(n, "In attesa di conferma", btn("Annulla", false, () => Net.send(`CCANCEL|${n}`)))); }
    lists.append(h("div", { class: "label" }, `I TUOI CONTATTI (${App.contacts.size})`));
    if (!App.contacts.size) lists.append(h("div", { class: "muted", style: "padding:6px" }, "Ancora nessun contatto: cerca un nome utente qui sopra."));
    for (const n of [...App.contacts.values()].sort((a, b) => a.localeCompare(b))) lists.append(row(n, (App.users.has(kc(n)) ? "Online" : "Offline") + (isBlocked(n) ? " · bloccato" : ""),
      btn("Rimuovi", false, async () => { if (await confirmBox("Rimuovi contatto", `Rimuovere ${n} dai contatti? Non potrete più scrivervi finché uno dei due non manda una nuova richiesta.`, "Rimuovi", true)) Net.send(`CREMOVE|${n}`); }),
      btn("Scrivi", true, () => write(n))));
  }
  function doSearch() { const q = field.value.trim(); if (!q) { last = []; redraw(); return; } searchUsers(q, r => { if (q === field.value.trim()) { last = r; redraw(); } }); }
  field.addEventListener("input", () => { clearTimeout(timer); timer = setTimeout(doSearch, 280); });
  const s = sheet("Contatti", h("p", { class: "muted" }, "Cerca qualcuno con il suo nome utente: potrete scrivervi solo dopo che avrà accettato la tua richiesta."), field, results, lists);
  s.onclose = () => { App.contactsSheet = null; };
  App.contactsSheet = { redraw: () => (field.value.trim() ? doSearch() : redraw()) };
  redraw(); setTimeout(() => field.focus(), 100);
}
Net.on("AVATAR", p => {
  const i = p.indexOf("|"); const n = kc(p.slice(0, i)); const b = p.slice(i + 1).trim();
  App.avatars[n] = b ? "data:image/jpeg;base64," + b : null; renderChats(); if (App.active && kc(App.active.id) === n) renderConvHead();
});

// ---- gruppi
Net.on("GROUP", p => {
  const f = p.split("|");
  const old = App.groups.get(f[0]);
  const g = { id: f[0], name: f[1], admins: (f[2] || "").split(",").filter(Boolean), members: (f[3] || "").split(",").filter(Boolean),
    desc: Net.unescape(f[4] || ""), onlyAdmins: (f[5] || "").includes("a"), pending: (f[6] || "").split(",").filter(Boolean),
    photo: old ? old.photo : null, call: old ? old.call : null, invite: old ? old.invite : undefined };
  const c = chatOf("#" + g.id, true);
  const before = App.active === c ? canSendReason(c) : null;
  App.groups.set(g.id, g); c.name = g.name; c.alive = true;
  renderChats(); if (App.active === c) { renderConvHead(); if (canSendReason(c) !== before) renderComposer(); }
  if (App.groupSheet && App.groupSheet.gid === g.id) App.groupSheet.redraw();
});
Net.on("GPHOTO", p => { const [gid, b] = p.split("|"); const g = App.groups.get(gid); if (g) { g.photo = b ? "data:image/jpeg;base64," + b : null; renderChats(); if (App.active && App.active.id === "#" + gid) renderConvHead(); if (App.groupSheet && App.groupSheet.gid === gid) App.groupSheet.redraw(); } });
Net.on("GROUPGONE", gid => { const c = chatOf("#" + gid); if (c && c.alive !== false) { c.alive = false; system(c, "Non fai più parte di questo gruppo"); if (App.active === c) renderConversation(); } });
Net.on("GEVENT", p => {
  const [gid, who, what, target] = p.split("|");
  const c = chatOf("#" + gid, true);
  const W = isMe(who) ? "Tu" : who, T = isMe(target) ? "te" : target;
  const t = { create: `${W} ha creato il gruppo`, invite: `${W} ha invitato ${T}: entrerà solo se accetta`, accept: `${isMe(target) ? "Sei entrato" : target + " è entrato"} nel gruppo`,
    decline: `${target} ha rifiutato l'invito`, leave: `${W} ${isMe(who) ? "sei uscito" : "è uscito"} dal gruppo`, kick: `${W} ha rimosso ${T}`, add: `${W} ha aggiunto ${T}`,
    name: `${W} ha cambiato il nome del gruppo`, join: `${W} ${isMe(who) ? "sei entrato" : "è entrato"} con il link d'invito`, admin: `${W} ha nominato amministratore ${T}`,
    unadmin: `${W} ha tolto ${T} dagli amministratori`, desc: `${W} ha cambiato la descrizione`, photo: `${W} ha cambiato la foto del gruppo`,
    perm: target === "1" ? `${W}: ora solo gli amministratori possono scrivere` : `${W}: ora tutti possono scrivere` }[what];
  if (t) system(c, t);
});
Net.on("GINVREQ", p => {
  const [gid, name, by, n] = p.split("|");
  vibrate([40, 60, 40]);
  const s = sheet("Invito a un gruppo",
    h("p", {}, h("b", {}, by), ` vuole aggiungerti al gruppo "${name}" (${n} membri). Entrerai solo se accetti.`),
    h("div", { class: "row" }, h("button", { class: "btn", onclick: () => { Net.send(`GCONSENT|${gid}|0`); s.close(); } }, "Rifiuta"),
      h("button", { class: "btn primary", onclick: () => { Net.send(`GCONSENT|${gid}|1`); s.close(); } }, "Entra nel gruppo")));
});
Net.on("GINVITE", p => {
  const [gid, code] = p.split("|"); const g = App.groups.get(gid); if (!g) return;
  g.invite = code || "";
  if (App.groupSheet && App.groupSheet.gid === gid) App.groupSheet.redraw();
});
Net.on("GCALL", p => { if ((typeof Calls !== "undefined")) Calls.onGroupCall(p); });

Net.on("ERR", p => {
  const f = p.split("|");
  const c = f[1] ? App.chats.get(f[1]) || App.chats.get((App.contacts.get(kc(f[1])) || f[1])) : null;
  const m = c && f[2] ? findMsg(c, f[2]) : null;
  if (m && m.dir === "out") { m.state = "failed"; m.error = f[0]; refreshMsg(c, m); }
  if (f[0]) toast(f[0], true);
});
Net.on("ACCOUNT", p => {
  const f = p.split("|");
  if (f[0] === "info" || f[0] === "verified") { App.email = f[1] || ""; App.verified = f[0] === "verified" || f[2] === "1"; }
  const msgs = { codesent: "Codice inviato a " + f[1], verified: "Email verificata!", passwdok: "Password cambiata" };
  if (f[0] === "passwdok" && f[1]) Store.set("token", f[1]);
  if (msgs[f[0]]) toast(msgs[f[0]]); else if (f[0] === "err") toast(f[1], true);
  if (App.tab === "settings") renderSettings();
});

/** Da dove arriva un comando: "nick" oppure "#gruppo/nick". */
function origin(from) {
  if (from.startsWith("#")) {
    const s = from.indexOf("/"); const gid = from.slice(1, s < 0 ? undefined : s);
    if (!App.groups.has(gid) && !App.chats.has("#" + gid)) return { chat: null };
    return { chat: chatOf("#" + gid, true), nick: s < 0 ? "" : from.slice(s + 1), group: true };
  }
  if (isBlocked(from)) return { chat: null };
  return { chat: chatOf(App.contacts.get(kc(from)) || from, true), nick: from, group: false };
}
const destOf = c => c.id;

// ================================================================ schermate e schede
function setScreen(id) { document.querySelectorAll(".screen").forEach(s => s.classList.toggle("active", s.id === id)); }
function showTab(t) {
  App.tab = t;
  document.querySelectorAll(".tab").forEach(b => b.classList.toggle("active", b.dataset.t === t));
  document.querySelectorAll(".pane").forEach(p => p.style.display = p.id === "pane-" + t ? "flex" : "none");
  if (t === "chat") { App.active ? renderConversation() : renderChats(); }
  if (t === "insta") Insta.show();
  if (t === "ai") AI.show();
  if (t === "settings") renderSettings();
}
function updateBadges() {
  let n = 0; for (const c of App.chats.values()) if (!prefs(c.id).mute || c.mentioned) n += c.unread;
  const b = document.querySelector('.tab[data-t="chat"] .badge'); if (b) { b.textContent = n; b.style.display = n ? "" : "none"; }
}

// ================================================================ elenco chat
function preview(m) {
  if (!m) return "";
  if (m.deleted) return "🚫 Messaggio eliminato";
  if (m.dir === "sys") return m.text;
  if (m.file) return m.file.sticker ? "🌟 Sticker" : m.file.once ? "👁 Foto a visualizzazione singola" : m.file.kind === "VOICE" ? "🎤 Messaggio vocale (" + fmtDur(m.file.dur || 0) + ")" : m.file.kind === "IMAGE" ? "📷 Foto" : m.file.kind === "GIF" ? "🎞 GIF" : m.file.kind === "VIDEO" ? "🎬 Video" : "📎 " + (m.file.name || "File");
  if (m.poll) return (m.poll.correct >= 0 ? "🧠 Quiz: " : "📊 Sondaggio: ") + m.poll.q;
  if (m.loc) return m.loc.live ? "📍 Posizione in tempo reale" : "📍 Posizione";
  if (m.game) return "🎮 " + m.game.title;
  if (m.wb) return "🖍 Lavagna condivisa";
  return (m.text || "").replace(/[*_~`]/g, "");
}
function visibleChats() {
  return [...App.chats.values()].filter(c => c.group || c.bc || isContact(c.id) || c.msgs.some(m => m.dir !== "sys"));
}
function renderChats() {
  if (App.tab !== "chat" || App.active) return;
  const pane = $("#pane-chat");
  const keepScroll = pane.querySelector(".scroll")?.scrollTop || 0;
  const focusSearch = document.activeElement && document.activeElement.id === "chat-search";
  pane.innerHTML = "";
  pane.append(h("div", { class: "topbar" }, h("h1", {}, App.showArchived ? "Archiviate" : "Chat"),
    h("div", { class: "row", style: "gap:4px;margin:0;flex:none" },
      App.showArchived ? h("button", { class: "iconbtn", title: "Indietro", onclick: () => { App.showArchived = false; renderChats(); }, html: svg("back") }) : null,
      h("button", { class: "iconbtn", title: "Contatti", onclick: contactsSheet, html: svg("personadd") + (App.incoming.size ? `<span class="badge" style="position:absolute;top:-2px;right:-2px">${App.incoming.size}</span>` : ""), style: "position:relative" }),
      h("button", { class: "iconbtn", title: "Nuovo gruppo", onclick: newGroup, html: svg("group") }),
      h("button", { class: "iconbtn", title: "Altro", onclick: listMenu, html: svg("more") }))));
  const list = h("div", { class: "scroll" });
  const search = h("input", { id: "chat-search", class: "field", placeholder: "Cerca chat e messaggi", value: App.listQuery, style: "margin-bottom:8px" });
  search.addEventListener("input", () => { App.listQuery = search.value; renderChats(); });
  list.append(search);
  if (!App.showArchived && (typeof Status !== "undefined")) list.append(Status.strip());
  const chips = h("div", { style: "display:flex;gap:4px;overflow-x:auto;margin-bottom:6px" });
  [["all", "Tutte"], ["unread", "Non lette"], ["groups", "Gruppi"], ["fav", "Fissate"]].forEach(([k, t]) => chips.append(h("span", { class: "chip" + (App.listFilter === k ? " on" : ""), onclick: () => { App.listFilter = k; renderChats(); } }, t)));
  list.append(chips);
  const q = kc(App.listQuery);
  let items = visibleChats().filter(c => !!prefs(c.id).arch === App.showArchived);
  if (App.listFilter === "unread") items = items.filter(c => c.unread || prefs(c.id).markUnread);
  if (App.listFilter === "groups") items = items.filter(c => c.group);
  if (App.listFilter === "fav") items = items.filter(c => prefs(c.id).pin);
  if (q) items = items.filter(c => kc(c.name).includes(q) || c.msgs.some(m => kc(m.text).includes(q)));
  items.sort((a, b) => ((prefs(b.id).pin ? 1 : 0) - (prefs(a.id).pin ? 1 : 0)) || (b.last - a.last) || a.name.localeCompare(b.name));
  const archived = visibleChats().filter(c => prefs(c.id).arch);
  if (!App.showArchived && archived.length && !q) list.append(h("div", { class: "item glass", style: "margin-bottom:8px;padding:8px 12px", onclick: () => { App.showArchived = true; renderChats(); } },
    h("span", { class: "mi" }, "🗄"), h("div", { class: "main" }, h("div", { class: "name" }, "Archiviate")), h("span", { class: "muted" }, archived.reduce((n, c) => n + (c.unread ? 1 : 0), 0) || "")));
  if (!items.length) list.append(h("div", { class: "empty" }, h("p", {}, q ? "Nessun risultato" : App.showArchived ? "Nessuna chat archiviata" : "Ancora nessun contatto. Cerca i tuoi amici con il loro nome utente: potrete scrivervi quando accettano."),
    q || App.showArchived ? null : h("button", { class: "btn primary", onclick: contactsSheet }, "Aggiungi un contatto")));
  const card = h("div", { class: "glass", style: "padding:6px" });
  for (const c of items) {
    const last = [...c.msgs].reverse().find(m => !m.hiddenForMe);
    const online = c.group || c.bc ? null : App.users.has(kc(c.id));
    const pr = prefs(c.id);
    const typing = Object.entries(c.typing || {}).filter(([, v]) => v.until > Date.now());
    let sub;
    if (typing.length) sub = h("span", { style: "color:var(--accent)" }, (c.group ? typing.map(([n]) => n).join(", ") + " " : "") + (typing[0][1].s === "r" ? "sta registrando…" : "sta scrivendo…"));
    else if (last) sub = (last.dir === "out" && !last.deleted ? ticks(last) + " " : "") + (c.group && last.who ? last.who + ": " : "") + preview(last);
    else sub = c.bc ? (bcList(c.id)?.members.length || 0) + " destinatari" : c.group ? (c.alive === false ? "Non fai più parte del gruppo" : "Gruppo") : !isContact(c.id) ? "Non è ancora un contatto" : online ? "Online · scrivi per primo" : "Offline";
    const it = h("div", { class: "item", onclick: () => openChat(c) }, chatAvatar(c),
      h("div", { class: "main" }, h("div", { class: "name" }, c.name, isBlocked(c.id) ? " 🚫" : ""), h("div", { class: "sub" }, sub)),
      h("div", { class: "side" }, last ? h("div", { class: "muted", style: "font-size:.72em" }, time(last.time)) : null,
        h("div", {}, pr.mute ? "🔕" : "", pr.pin ? "📌" : "", c.mentioned ? h("span", { class: "badge" }, "@") : null,
          c.unread ? h("span", { class: "badge" + (pr.mute ? " muted-badge" : "") }, c.unread) : pr.markUnread ? h("span", { class: "badge" }, "•") : null)));
    longPress(it, () => chatMenu(c));
    card.append(it);
  }
  if (items.length) list.append(card);
  pane.append(list);
  list.scrollTop = keepScroll;
  if (focusSearch) { search.focus(); search.setSelectionRange(search.value.length, search.value.length); }
}
function chatMenu(c) {
  const pr = prefs(c.id);
  menu(c.name, [
    ["📌", pr.pin ? "Togli dalle fissate" : "Fissa in alto", () => { if (!pr.pin && visibleChats().filter(x => prefs(x.id).pin).length >= 3) return toast("Puoi fissare al massimo 3 chat", true); setPref(c.id, "pin", !pr.pin); renderChats(); }],
    ["🗄", pr.arch ? "Togli dall'archivio" : "Archivia", () => { setPref(c.id, "arch", !pr.arch); renderChats(); }],
    ["🔕", pr.mute ? "Riattiva le notifiche" : "Silenzia", () => { setPref(c.id, "mute", !pr.mute); renderChats(); updateBadges(); }],
    ["✉️", c.unread || pr.markUnread ? "Segna come letta" : "Segna come non letta", () => { if (c.unread || pr.markUnread) { c.unread = 0; setPref(c.id, "markUnread", false); } else setPref(c.id, "markUnread", true); renderChats(); updateBadges(); }],
    !c.group && !c.bc ? ["🚫", isBlocked(c.id) ? "Sblocca " + c.name : "Blocca " + c.name, () => toggleBlock(c)] : null,
    c.bc ? ["✏️", "Modifica la lista", () => editBroadcast(c.id.slice(1))] : null,
    ["🧹", "Svuota la chat", async () => { if (await confirmBox("Svuota chat", "Cancellare tutti i messaggi di questa chat da questo telefono?", "Svuota", true)) { c.msgs = []; renderChats(); } }],
    c.bc ? ["🗑", "Elimina la lista", async () => { if (await confirmBox("Elimina lista", "Eliminare la lista broadcast?", "Elimina", true)) { saveBc(bcLists().filter(b => "~" + b.id !== c.id)); App.chats.delete(c.id); renderChats(); } }, true] : null,
    c.group && c.alive !== false ? ["🚪", "Esci dal gruppo", () => leaveGroup(c), true] : null
  ]);
}
async function toggleBlock(c) {
  const b = isBlocked(c.id);
  if (!b && !(await confirmBox("Blocca " + c.name, `${c.name} non potrà più scriverti né chiamarti su questo telefono. Puoi sbloccarlo quando vuoi.`, "Blocca", true))) return;
  setBlocked(c.id, !b); toast(b ? c.name + " sbloccato" : c.name + " bloccato");
  renderChats(); if (App.active === c) renderConversation();
}
function listMenu() {
  menu("Altro", [
    ["📢", "Nuova lista broadcast", () => editBroadcast(null)],
    ["🔗", "Entra in un gruppo con un codice", async () => { const code = await ask("Entra in un gruppo", "Incolla il codice d'invito (o il link) che ti hanno mandato.", "Codice d'invito", "", "Entra"); if (code) Net.send("GJOIN|" + code.trim().replace(/^.*[/=]/, "")); }],
    ["⭐", "Messaggi importanti", starredSheet],
    ["🗄", "Chat archiviate", () => { App.showArchived = true; renderChats(); }],
    ["🟢", "Stati", () => (typeof Status !== "undefined") && Status.openList()],
    ["✅", "Segna tutte come lette", () => { for (const c of App.chats.values()) { c.unread = 0; c.mentioned = false; setPref(c.id, "markUnread", false); } renderChats(); updateBadges(); }]
  ]);
}
function starredSheet() {
  const all = [];
  for (const c of App.chats.values()) for (const m of c.msgs) if (m.starred && !m.deleted) all.push([c, m]);
  const s = sheet("⭐ Messaggi importanti", ...(all.length ? all.map(([c, m]) => h("div", { class: "item", onclick: () => { s.close(); openChat(c, m.id); } },
    chatAvatar(c, 38), h("div", { class: "main" }, h("div", { class: "name" }, c.name + (m.who ? " · " + m.who : m.dir === "out" ? " · Tu" : "")), h("div", { class: "sub" }, preview(m))), h("span", { class: "muted" }, time(m.time))))
    : [h("p", { class: "muted" }, "Tieni premuto un messaggio e scegli \"Importante\" per ritrovarlo qui.")]));
}
function editBroadcast(id) {
  const cur = id ? bcLists().find(b => b.id === id) : null;
  const name = h("input", { class: "field", placeholder: "Nome della lista", value: cur ? cur.name : "", maxlength: 40 });
  const picks = [...App.contacts.values()].map(u => ({ u, el: check(u, cur ? cur.members.some(x => kc(x) === kc(u)) : false, () => {}) }));
  const s = sheet(cur ? "Modifica lista broadcast" : "Nuova lista broadcast", h("p", { class: "muted" }, "Il messaggio arriva a ognuno in privato, come se lo avessi scritto solo a lui."), name,
    ...picks.map(p => p.el), picks.length ? null : h("p", { class: "muted" }, "Non hai ancora contatti."),
    h("button", { class: "btn primary block", onclick: () => {
      const who = picks.filter(p => p.el.querySelector("input").checked).map(p => p.u);
      if (who.length < 1) return toast("Scegli almeno un contatto", true);
      const list = bcLists(); const bid = cur ? cur.id : newId().replace(/[^a-z0-9]/g, "");
      const entry = { id: bid, name: name.value.trim() || who.join(", ").slice(0, 40), members: who };
      if (cur) Object.assign(list.find(b => b.id === bid), entry); else list.push(entry);
      saveBc(list); const c = chatOf("~" + bid, true); c.name = entry.name; s.close(); openChat(c);
    } }, cur ? "Salva" : "Crea la lista"));
}
function restoreBroadcasts() { for (const b of bcLists()) { const c = chatOf("~" + b.id, true); c.name = b.name; } }

function newGroup() {
  const name = h("input", { class: "field", placeholder: "Nome del gruppo", maxlength: 40 });
  const picks = [...App.contacts.values()].sort((a, b) => a.localeCompare(b)).map(u => ({ u, el: check(u, false, () => { }) }));
  const s = sheet("Nuovo gruppo", name, h("p", { class: "muted" }, "Puoi invitare solo i tuoi contatti: riceveranno un invito e dovranno accettare."),
    ...picks.map(p => p.el), picks.length ? null : h("p", { class: "muted" }, "Non hai ancora contatti da invitare."),
    h("button", { class: "btn primary block", onclick: () => {
      const who = picks.filter(p => p.el.querySelector("input").checked).map(p => p.u);
      if (!name.value.trim() || !who.length) { toast("Scrivi il nome e scegli almeno una persona", true); return; }
      const gid = (Date.now().toString(36) + Math.random().toString(36).slice(2, 8)).toLowerCase().replace(/[^a-z0-9]/g, "").slice(0, 16);
      Net.send(`GCREATE|${gid}|${name.value.trim().replace(/\|/g, " ")}|${who.join(",")}`); s.close();
    } }, "Crea e invita"));
}
async function leaveGroup(c) {
  if (!(await confirmBox("Esci dal gruppo", `Vuoi uscire da "${c.name}"?`, "Esci", true))) return;
  Net.send("GLEAVE|" + c.id.slice(1));
}

// ================================================================ impostazioni
function renderSettings() {
  const pane = $("#pane-settings"); const keep = pane.querySelector(".scroll")?.scrollTop || 0; pane.innerHTML = "";
  pane.append(h("div", { class: "topbar" }, h("h1", {}, "Impostazioni")));
  const sc = h("div", { class: "scroll" }); pane.append(sc);
  const a11y = Store.get("a11y", {});
  const setA = (k, v) => { a11y[k] = v; Store.set("a11y", a11y); Theme.apply(); };
  const sec = (title, ...kids) => h("div", { class: "glass", style: "padding:14px 16px;margin-bottom:12px" }, h("h3", { style: "margin:0 0 6px;color:var(--accent)" }, title), ...kids);

  // profilo
  const pic = h("input", { type: "file", accept: "image/*", style: "display:none", onchange: async () => {
    const f = pic.files[0]; pic.value = ""; if (!f) return;
    const b64 = await Media.squareJpegB64(f, 256, 90 * 1024);
    if (!b64) return toast("Foto non valida", true);
    Store.set("myAvatar", b64); App.avatars[kc(App.me)] = "data:image/jpeg;base64," + b64; Net.send("AVATAR|" + b64); renderSettings(); toast("Foto profilo aggiornata");
  } });
  sc.append(sec("Profilo", h("div", { class: "item", style: "padding:4px 0", onclick: () => pic.click() }, avatar(App.me || "?"),
    h("div", { class: "main" }, h("div", { class: "name" }, App.me || ""), h("div", { class: "sub" }, "Tocca per cambiare la foto profilo")), pic),
    Store.get("myAvatar", "") ? h("button", { class: "btn small", onclick: () => { Store.set("myAvatar", ""); App.avatars[kc(App.me)] = null; Net.send("AVATAR|"); renderSettings(); } }, "Togli la foto") : null));

  // privacy
  const p = Priv();
  sc.append(sec("Privacy e sicurezza",
    check("Nascondi quando sono online", p.hidePresence, v => { setPriv("hidePresence", v); Net.send("PRESENCE|" + (v ? 1 : 0)); }),
    check("Conferme di lettura (spunte blu)", p.readReceipts, v => setPriv("readReceipts", v)),
    h("p", { class: "muted", style: "margin:0 0 6px 34px;font-size:.8em" }, "Se le disattivi non vedrai neanche quelle degli altri."),
    check("Mostra quando sto scrivendo", p.typing, v => setPriv("typing", v)),
    check("Suoni e vibrazione per i nuovi messaggi", p.sounds, v => setPriv("sounds", v)),
    h("div", { class: "row", style: "margin-top:8px;flex-wrap:wrap" },
      h("button", { class: "btn small", onclick: () => Lock.setup() }, Lock.enabled() ? "Cambia il PIN" : "Blocca l'app con un PIN"),
      Lock.enabled() ? h("button", { class: "btn small", onclick: () => { Lock.disable(); renderSettings(); toast("Blocco con PIN disattivato"); } }, "Togli il PIN") : null,
      h("button", { class: "btn small", onclick: blockedSheet }, `Utenti bloccati (${App.blocked.size})`))));

  // chat
  sc.append(sec("Chat",
    h("label", { class: "lbl" }, "Sfondo predefinito delle chat"), Media.wallpaperPicker(null, renderSettings),
    h("div", { class: "row", style: "margin-top:8px;flex-wrap:wrap" },
      h("button", { class: "btn small", onclick: manageQuick }, "Risposte rapide"),
      h("button", { class: "btn small", onclick: () => Media.stickerManager() }, "I miei sticker"),
      h("button", { class: "btn small", onclick: () => editBroadcast(null) }, "Nuova lista broadcast"))));

  // tema
  const themes = h("div", { style: "display:flex;flex-wrap:wrap;gap:8px" });
  for (const [id, name] of Theme.PALETTES) {
    themes.append(h("button", { class: "btn small" + (Theme.current() === id ? " primary" : ""), onclick: () => { Store.set("theme", id); Theme.apply(); renderSettings(); } }, name.split(" ")[0]));
  }
  const cu = Store.get("custom", { c1: "#6A1B9A", c2: "#00BCD4", dark: false });
  const c1 = h("input", { class: "field", value: cu.c1, maxlength: 7, style: "min-width:0;padding:12px 8px" }), c2 = h("input", { class: "field", value: cu.c2, maxlength: 7, style: "min-width:0;padding:12px 8px" });
  const p1 = h("input", { type: "color", value: cu.c1, style: "width:46px;height:46px;border:0;background:none" }), p2 = h("input", { type: "color", value: cu.c2, style: "width:46px;height:46px;border:0;background:none" });
  p1.oninput = () => c1.value = p1.value.toUpperCase(); p2.oninput = () => c2.value = p2.value.toUpperCase();
  const darkC = check("Versione scura", cu.dark, () => { });
  sc.append(sec("Tema", themes, h("label", { class: "lbl" }, "Tema personalizzato: due colori esadecimali"),
    h("div", { class: "row" }, c1, p1, c2, p2), darkC,
    h("button", { class: "btn primary", onclick: () => {
      if (Theme.toInt(c1.value) === null || Theme.toInt(c2.value) === null) { toast("Codici non validi (es. #6A1B9A)", true); return; }
      Store.set("custom", { c1: c1.value, c2: c2.value, dark: darkC.querySelector("input").checked }); Store.set("theme", "custom"); Theme.apply(); renderSettings();
    } }, "Usa il mio tema")));

  // font
  const fontFile = h("input", { type: "file", accept: ".ttf,.otf,.woff,.woff2", style: "display:none", onchange: async () => {
    try { const n = await Theme.importFont(fontFile.files[0]); Store.set("font", n); Theme.apply(); renderSettings(); toast("Font importato: " + n); } catch (e) { toast(e.message, true); }
  } });
  const fonts = [...Theme.FONTS, ...Store.get("importedFonts", []).map(f => f.name)];
  sc.append(sec("Font", select(fonts.map(f => [f, f || "Predefinito"]), Store.get("font", ""), v => { Store.set("font", v); Theme.apply(); }),
    h("div", { style: "margin-top:8px" }, h("button", { class: "btn small", onclick: () => fontFile.click() }, "Importa un font"), fontFile)));

  // accessibilita'
  const size = h("input", { type: "range", min: 80, max: 220, value: a11y.textScale || 100, oninput: () => setA("textScale", +size.value) });
  sc.append(sec("Accessibilità", h("label", { class: "lbl" }, "Dimensione del testo"), size,
    h("label", { class: "lbl" }, "Contrasto"), select([["normal", "Normale"], ["low", "Ridotto (più morbido)"], ["high", "Alto"]], a11y.contrast || "normal", v => setA("contrast", v)),
    h("label", { class: "lbl" }, "Daltonismo"), select([["none", "Nessuno"], ["protanopia", "Protanopia (rosso)"], ["deuteranopia", "Deuteranopia (verde)"],
      ["tritanopia", "Tritanopia (blu/giallo)"], ["achromatopsia", "Acromatopsia (nessun colore)"]], a11y.colorblind || "none", v => setA("colorblind", v)),
    check("Font ad alta leggibilità (dislessia)", a11y.dyslexia, v => setA("dyslexia", v)),
    check("Riduci le animazioni", a11y.reduceMotion, v => setA("reduceMotion", v)),
    check("Riduci la trasparenza", a11y.reduceTransparency, v => setA("reduceTransparency", v)),
    check("Contorno ben visibile sull'elemento selezionato", a11y.focusRing, v => setA("focusRing", v)),
    check("Simboli oltre ai colori", a11y.symbols, v => setA("symbols", v)),
    check("Avvisi visivi (lampeggio) per i nuovi messaggi", a11y.visualAlerts, v => setA("visualAlerts", v)),
    check("Leggi ad alta voce i messaggi della chat aperta", a11y.readAloud, v => setA("readAloud", v))));

  // account
  const mail = h("input", { class: "field", type: "email", placeholder: "nome@esempio.it", value: App.email || "" });
  const code = h("input", { class: "field", inputmode: "numeric", placeholder: "Codice", maxlength: 6 });
  const op = h("input", { class: "field", type: "password", placeholder: "Password attuale" }), np = h("input", { class: "field", type: "password", placeholder: "Nuova password" });
  sc.append(sec("Account · " + (App.me || ""), h("p", { class: "muted" }, App.email ? App.email + (App.verified ? " ✓ verificata" : " · da verificare") : "Nessuna email: associane una per entrare con un codice."),
    h("div", { class: "row" }, mail, h("button", { class: "btn small", onclick: () => Net.send("ACCOUNT|email|" + mail.value.trim()) }, "Invia codice")),
    h("div", { class: "row", style: "margin-top:8px" }, code, h("button", { class: "btn small", onclick: () => Net.send("ACCOUNT|verify|" + code.value.trim()) }, "Verifica")),
    h("label", { class: "lbl" }, "Cambia password"), op, h("div", { style: "height:6px" }), np,
    h("div", { style: "margin-top:8px" }, h("button", { class: "btn small", onclick: () => { if (np.value.length < 6) return toast("Almeno 6 caratteri", true); Net.send(`ACCOUNT|passwd|${Net.b64(op.value)}|${Net.b64(np.value)}`); } }, "Cambia")),
    h("p", { class: "muted", style: "margin-top:10px" }, `Server: ${App.server.host}:${App.server.port}`),
    h("div", { style: "margin-top:6px" }, h("button", { class: "btn", onclick: logout }, "Esci dall'account"))));
  sc.append(h("p", { class: "muted", style: "text-align:center" }, "Ghost-chat final · mobile"));
  sc.scrollTop = keep;
}
function blockedSheet() {
  const s = sheet("Utenti bloccati", ...(App.blocked.size ? [...App.blocked].map(n => h("div", { class: "item" }, avatar(n), h("div", { class: "main" }, h("div", { class: "name" }, App.contacts.get(n) || n)),
    h("button", { class: "btn small", onclick: () => { setBlocked(n, false); s.close(); blockedSheet(); renderSettings(); } }, "Sblocca"))) : [h("p", { class: "muted" }, "Nessuno. Puoi bloccare qualcuno dal menu della sua chat.")]));
}
function quickList() { return Store.get("quick", ["Arrivo tra 5 minuti", "Ti richiamo appena posso", "Ok! 👍", "Sono in riunione", "Buonanotte 👻"]); }
function manageQuick() {
  const list = quickList();
  const s = sheet("Risposte rapide", h("p", { class: "muted" }, "Si inviano con un tocco dal tasto ⚡ della chat."),
    ...list.map((r, i) => h("div", { class: "item" }, h("div", { class: "main" }, "⚡ " + r), h("button", { class: "btn small", onclick: () => { list.splice(i, 1); Store.set("quick", list); s.close(); manageQuick(); } }, "Togli"))),
    h("button", { class: "btn small", onclick: async () => { const r = await ask("Nuova risposta rapida", "", "Testo", "", "Aggiungi"); if (r && r.trim()) { list.push(r.trim()); Store.set("quick", list); s.close(); manageQuick(); } } }, "+ Aggiungi"));
}
function logout() {
  const t = Store.get("token", ""); if (t) Net.send("ACCOUNT|logout|" + t);
  if ((typeof Calls !== "undefined")) Calls.hangupAll();
  Store.set("token", ""); Net.close(); App.chats.clear(); App.groups.clear(); App.contacts.clear(); App.active = null; App.lastUser = null; showLogin("");
}

// ================================================================ blocco con PIN
const Lock = (() => {
  let hiddenAt = 0;
  const enabled = () => !!Store.get("pinHash", "");
  async function setup() {
    const a = await ask("PIN dell'app", "Scegli un PIN di 4-8 cifre: servirà per aprire Ghost-chat.", "PIN", "", "Avanti");
    if (a == null) return; if (!/^\d{4,8}$/.test(a)) return toast("Il PIN deve avere da 4 a 8 cifre", true);
    const b = await ask("Conferma il PIN", "", "PIN", "", "Salva"); if (b !== a) return toast("I PIN non coincidono", true);
    Store.set("pinHash", await sha256hex("ghost|" + a)); toast("Blocco con PIN attivato 🔒"); renderSettings();
  }
  function disable() { Store.set("pinHash", ""); }
  function show() {
    if (!enabled() || $("#lockscreen")) return;
    let typed = "";
    const dots = h("div", { class: "pin-dots" });
    const msg = h("div", { class: "muted" }, "Inserisci il PIN");
    const draw = () => { dots.innerHTML = ""; for (let i = 0; i < Math.max(4, typed.length); i++) dots.append(h("span", { class: i < typed.length ? "on" : "" })); };
    const tryIt = async () => { if (await sha256hex("ghost|" + typed) === Store.get("pinHash", "")) wrap.remove(); else if (typed.length >= 8) { typed = ""; msg.textContent = "PIN sbagliato"; vibrate(200); draw(); } };
    const pad = h("div", { class: "pin-pad" });
    for (const k of ["1", "2", "3", "4", "5", "6", "7", "8", "9", "", "0", "⌫"]) pad.append(h("button", { class: k ? "btn" : "btn ghostbtn", onclick: async () => {
      if (k === "⌫") typed = typed.slice(0, -1); else if (k) { typed += k; } draw(); if (typed.length >= 4) await tryIt();
    } }, k));
    const wrap = h("div", { id: "lockscreen", class: "lockscreen" }, h("div", { html: `<svg class="ghost-hero" viewBox="0 0 24 24">${GHOST_SVG("#fff")}</svg>` }), h("h2", {}, "Ghost-chat è bloccata"), msg, dots, pad);
    draw(); document.body.append(wrap);
  }
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "hidden") hiddenAt = Date.now();
    else if (hiddenAt && Date.now() - hiddenAt > 30000) show();
  });
  return { enabled, setup, disable, show };
})();

// ================================================================ avvio
window.addEventListener("load", async () => {
  Theme.apply();
  await Theme.loadImportedFonts();
  $(".tab[data-t=insta]").querySelector(".ic").innerHTML = COFFIN_SVG;
  $(".tab[data-t=ai]").querySelector(".ic").innerHTML = AI_SVG;
  $(".tab[data-t=chat]").querySelector(".ic").innerHTML = svg("chat");
  $(".tab[data-t=settings]").querySelector(".ic").innerHTML = svg("settings");
  document.querySelectorAll(".tab").forEach(b => b.addEventListener("click", () => showTab(b.dataset.t)));
  restoreBroadcasts();
  Lock.show();
  const s = App.server, tok = Store.get("token", ""), u = Store.get("user", "");
  if (tok && u && s.host && Store.get("autoLogin", true)) { setScreen("login"); $("#login").innerHTML = '<div class="login glass"><h2>Accesso automatico...</h2></div>'; Net.connect(s.host, s.port, s.tls, `AUTH|token|${u}|${tok}`); }
  else showLogin("");
  setInterval(tick, 2000);
});
/** Ogni 2 secondi: messaggi a tempo scaduti, "sta scrivendo" scaduto, posizioni in tempo reale. */
function tick() {
  const now = Date.now();
  for (const c of App.chats.values()) {
    const before = c.msgs.length;
    c.msgs = c.msgs.filter(m => !m.expiresAt || m.expiresAt > now);
    let typingChanged = false;
    for (const [n, v] of Object.entries(c.typing || {})) if (v.until <= now) { delete c.typing[n]; typingChanged = true; }
    if (before !== c.msgs.length && App.active === c) renderMessages();
    if (typingChanged) { if (App.active === c) renderConvHead(); else renderChats(); }
  }
  if ((typeof Media !== "undefined")) Media.tickLive();
}
