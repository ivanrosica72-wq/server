/* Ghost-chat mobile · InstaGhost (post, Ghost-tube, profili, commenti con testo, sticker e GIF) */
"use strict";
const Insta = (() => {
  const P = {
    heart: '<path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/>',
    heartO: '<path d="M16.5 3c-1.74 0-3.41.81-4.5 2.09C10.91 3.81 9.24 3 7.5 3 4.42 3 2 5.42 2 8.5c0 3.78 3.4 6.86 8.55 11.54L12 21.35l1.45-1.32C18.6 15.36 22 12.28 22 8.5 22 5.42 19.58 3 16.5 3zm-4.4 15.55l-.1.1-.1-.1C7.14 14.24 4 11.39 4 8.5 4 6.5 5.5 5 7.5 5c1.54 0 3.04.99 3.57 2.36h1.87C13.46 5.99 14.96 5 16.5 5c2 0 3.5 1.5 3.5 3.5 0 2.89-3.14 5.74-7.9 10.05z"/>',
    down: '<path d="M15 3H6c-.83 0-1.54.5-1.84 1.22l-3.02 7.05c-.09.23-.14.47-.14.73v2c0 1.1.9 2 2 2h6.31l-.95 4.57-.03.32c0 .41.17.79.44 1.06L9.83 23l6.59-6.59c.36-.36.58-.86.58-1.41V5c0-1.1-.9-2-2-2zm4 0v12h4V3h-4z"/>',
    comment: '<path d="M21.99 4c0-1.1-.89-2-1.99-2H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h14l4 4-.01-18zM20 4v13.17L18.83 16H4V4h16z"/>',
    share: '<path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/>',
    fav: '<path d="M17 3H7c-1.1 0-2 .9-2 2v16l7-3 7 3V5c0-1.1-.9-2-2-2z"/>',
    favO: '<path d="M17 3H7c-1.1 0-2 .9-2 2v16l7-3 7 3V5c0-1.1-.9-2-2-2zm0 15l-5-2.18L7 18V5h10v13z"/>',
    reel: '<path d="M18 4l2 4h-3l-2-4h-2l2 4h-3l-2-4H8l2 4H7L5 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V4h-4zm-7 12.5v-6l5 3-5 3z"/>',
    add: '<path d="M19 3H5a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2V5a2 2 0 00-2-2zm-2 10h-4v4h-2v-4H7v-2h4V7h2v4h4v2z"/>',
    close: '<path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/>'
  };
  const ic = (n, cls = "") => `<svg viewBox="0 0 24 24" fill="currentColor" class="${cls}">${P[n]}</svg>`;
  const posts = new Map(), comments = new Map(), profiles = new Map(), media = new Map(), downloads = new Map();
  const feeds = new Map(); let req = 0; const userCbs = []; let userRes = [];
  let view = "feed", profileUser = null, gridMode = "all";
  const STICKERS = ["👻", "💀", "🎃", "🦇", "🕸️", "🌙", "⭐", "💜", "🔥", "😂", "😍", "🥺", "😎", "🤯", "👍", "🎉", "🍕", "🐈‍⬛", "🧛", "🪦"];

  const unesc = s => Net.unescape(s); const escf = s => Net.escField(s);
  function feed(mode, before, limit, cb) { const r = "m" + (++req); feeds.set(r, { list: [], cb }); Net.send(`IGFEED|${r}|${mode}|${before}|${limit}`); }
  function users(q, cb) { userCbs.push(cb); Net.send("IGSEARCH|" + escf(q)); }

  // ---------------------------------------------------------------- eventi
  Net.on("IGITEM", p => {
    const f = p.split("|"); if (f.length < 17) return;
    const post = Object.assign(posts.get(f[1]) || {}, { id: f[1], author: f[2], kind: f[3], time: +f[4], size: +f[5], w: +f[6], h: +f[7], dur: +f[8],
      likes: +f[9], dislikes: +f[10], comments: +f[11], vote: +f[12], fav: f[13] === "1", shares: +f[14], caption: unesc(f[15]) });
    if (f[16]) post.preview = "data:image/jpeg;base64," + f[16];
    posts.set(post.id, post);
    if (f[0] === "new") { if (view === "feed" && App.tab === "insta") render(); }
    else if (feeds.has(f[0])) feeds.get(f[0]).list.push(post); else refreshPost(post);
  });
  Net.on("IGEND", p => { const f = p.split("|"); const r = feeds.get(f[0]); feeds.delete(f[0]); if (r) r.cb(r.list, f[2] === "1"); });
  Net.on("IGCOUNT", p => { const f = p.split("|"); const post = posts.get(f[0]); if (post) { Object.assign(post, { likes: +f[1], dislikes: +f[2], comments: +f[3], shares: +f[4] }); refreshPost(post); } });
  Net.on("IGCMT", p => {
    const f = p.split("|"); const c = { post: f[0], id: f[1], author: f[2], kind: f[3], time: +f[4], content: unesc(f.slice(5).join("|")) };
    const l = comments.get(c.post) || []; comments.set(c.post, l.filter(x => x.id !== c.id).concat(c)); if (openComments === c.post) renderComments();
  });
  Net.on("IGCMTEND", id => { if (openComments === id) renderComments(); });
  Net.on("IGCMTGONE", p => { const [pid, cid] = p.split("|"); comments.set(pid, (comments.get(pid) || []).filter(c => c.id !== cid)); if (openComments === pid) renderComments(); });
  Net.on("IGGONE", id => { posts.delete(id); if (App.tab === "insta") render(); });
  Net.on("IGPROF", p => { const f = p.split("|"); profiles.set(f[0].toLowerCase(), { user: f[0], bio: unesc(f[1]), posts: +f[2], followers: +f[3], following: +f[4], iFollow: f[5] === "1" }); if (view === "profile") renderProfileHead(); });
  Net.on("IGUSER", p => userRes.push(p.split("|")));
  Net.on("IGUSEREND", () => { const cb = userCbs.shift(); const r = userRes; userRes = []; if (cb) cb(r); });
  Net.on("IGDONE", () => { toast("Pubblicato su InstaGhost! 👻"); uploading = null; if (App.tab === "insta") render(); });
  Net.on("IGERR", p => toast(p.split("|")[1] || "Errore", true));
  Net.on("IGFOLLOWED", who => toast(who + " ha iniziato a seguirti"));
  const b64bytes = b => { const s = atob(b); const u = new Uint8Array(s.length); for (let i = 0; i < s.length; i++) u[i] = s.charCodeAt(i); return u; };
  Net.on("IGDATA", p => { const f = p.split("|"); const d = downloads.get(f[0]); if (d) d.parts.push(b64bytes(f[2])); });
  Net.on("IGDATAEND", p => {
    const id = p.split("|")[0]; const d = downloads.get(id); if (!d) return; downloads.delete(id);
    const url = URL.createObjectURL(new Blob(d.parts, { type: d.video ? "video/mp4" : "image/jpeg" })); media.set(id, url); d.cbs.forEach(cb => cb(url));
  });
  function getMedia(post, cb) {
    if (media.has(post.id)) return cb(media.get(post.id));
    const d = downloads.get(post.id); if (d) { d.cbs.push(cb); return; }
    downloads.set(post.id, { parts: [], cbs: [cb], video: post.kind === "V" });
    Net.send(`IGGET|${post.id}|0`);
  }

  // ---------------------------------------------------------------- viste
  function show() { render(); }
  function render() {
    const pane = $("#pane-insta"); pane.innerHTML = "";
    pane.append(h("div", { class: "topbar" }, h("span", { class: "ig-logo" }, "InstaGhost"),
      h("button", { class: "iconbtn", title: "Crea", onclick: create, html: ic("add") })));
    const tabs = h("div", { class: "ig-tabs" });
    [["feed", "Home"], ["explore", "Esplora"], ["tube", "Ghost-tube"], ["favs", "Preferiti"], ["search", "Cerca"], ["profile", "Profilo"]]
      .forEach(([v, t]) => tabs.append(h("span", { class: "chip" + (view === v ? " on" : ""), onclick: () => { view = v; if (v === "profile") profileUser = App.me; v === "tube" ? tube() : render(); } }, t)));
    pane.append(tabs);
    const sc = h("div", { class: "scroll", id: "ig-scroll" }); pane.append(sc);
    if (uploading) sc.append(h("div", { class: "glass", style: "padding:10px 14px;margin-bottom:10px" }, "Pubblicazione in corso... " + uploading + "%"));
    if (view === "feed") renderFeed(sc);
    else if (view === "explore" || view === "favs") { const g = h("div", { class: "grid3" }); sc.append(g); feed(view === "favs" ? "favs" : "all", 0, 30, list => fillGrid(g, list)); }
    else if (view === "search") renderSearch(sc);
    else if (view === "profile") renderProfile(sc);
  }
  function renderFeed(sc) {
    const stories = h("div", { class: "stories glass" }); sc.append(stories);
    users("", list => list.filter(([u]) => isMe(u) || isContact(u)).forEach(([u]) => stories.append(h("div", { class: "story", onclick: () => openProfile(u) }, avatar(u), u))));
    const col = h("div"); sc.append(col);
    feed("all", 0, 15, list => {
      if (!list.length) col.append(h("div", { class: "empty" }, "Ancora nessun post: pubblica il primo con +"));
      list.forEach(p => col.append(postCard(p)));
    });
  }
  function postCard(p) {
    const card = h("div", { class: "post glass", "data-id": p.id });
    fillCard(card, p); return card;
  }
  function fillCard(card, p) {
    card.innerHTML = "";
    card.append(h("div", { class: "post-head", onclick: () => openProfile(p.author) }, avatar(p.author),
      h("div", {}, h("b", {}, p.author), h("div", { class: "muted" }, ago(p.time) + (p.kind === "V" ? " · Ghost-tube" : "")))));
    const m = h("div", { class: "post-media" });
    m.append(h("img", { src: p.preview || "", alt: "" }));
    if (p.kind === "V") m.append(h("div", { class: "play", html: '<span><svg viewBox="0 0 24 24" width="30" fill="#fff"><path d="M8 5v14l11-7z"/></svg></span>' }));
    let last = 0;
    m.addEventListener("click", () => {
      const now = Date.now();
      if (now - last < 350) { if (p.vote <= 0) vote(p, 1); const b = h("div", { class: "heart-burst", html: ic("heart") }); m.append(b); setTimeout(() => b.remove(), 900); }
      else setTimeout(() => { if (Date.now() - now >= 340 && last === now) { if (p.kind === "V") tube(p); else { getMedia(p, url => { m.querySelector("img").src = url; }); } } }, 360);
      last = now;
    });
    card.append(m);
    const acts = h("div", { class: "post-actions" },
      h("button", { class: "act" + (p.vote > 0 ? " on" : ""), onclick: () => vote(p, 1), html: ic(p.vote > 0 ? "heart" : "heartO") }),
      h("button", { class: "act" + (p.vote < 0 ? " on dis" : ""), onclick: () => vote(p, -1), html: ic("down") }),
      h("button", { class: "act", onclick: () => openComm(p), html: ic("comment") }),
      h("button", { class: "act", onclick: () => share(p), html: ic("share") }), h("span", { class: "grow" }),
      h("button", { class: "act" + (p.fav ? " on" : ""), onclick: () => fav(p), html: ic(p.fav ? "fav" : "favO") }));
    card.append(acts);
    const body = h("div", { class: "post-body" }, h("b", {}, `${p.likes} Mi piace · ${p.dislikes} Non mi piace`),
      p.caption ? h("div", {}, h("b", {}, p.author + " "), p.caption) : null,
      h("div", { class: "muted", style: "margin-top:4px;cursor:pointer", onclick: () => openComm(p) }, p.comments ? `Vedi tutti i commenti (${p.comments})` : "Aggiungi un commento..."));
    if (p.author.toLowerCase() === (App.me || "").toLowerCase()) body.append(h("div", { class: "muted", style: "margin-top:6px;cursor:pointer;color:var(--error)", onclick: () => { if (confirm("Eliminare il post?")) Net.send("IGDEL|" + p.id); } }, "Elimina il post"));
    card.append(body);
  }
  function refreshPost(p) { document.querySelectorAll(`.post[data-id="${p.id}"]`).forEach(c => fillCard(c, p)); if (tubePost && tubePost.id === p.id) renderTubeSide(); }
  function vote(p, v) { const nv = p.vote === v ? 0 : v; if (p.vote > 0) p.likes--; if (p.vote < 0) p.dislikes--; if (nv > 0) p.likes++; if (nv < 0) p.dislikes++; p.vote = nv; refreshPost(p); Net.send(`IGVOTE|${p.id}|${nv}`); }
  function fav(p) { p.fav = !p.fav; refreshPost(p); Net.send(`IGFAV|${p.id}|${p.fav ? 1 : 0}`); toast(p.fav ? "Salvato nei Preferiti" : "Tolto dai Preferiti"); }
  function share(p) {
    const targets = [...App.chats.values()].filter(c => !c.group || c.alive !== false);
    const s = sheet("Condividi su Ghost-chat", ...(targets.length ? targets.map(c => h("div", { class: "item", onclick: () => {
      send(c, `📸 InstaGhost · ${p.author}${p.caption ? ": " + p.caption.split("\n")[0].slice(0, 100) : ""}\nghostchat://instaghost/${p.id}`);
      Net.send("IGSHARE|" + p.id); s.close(); toast("Condiviso con " + c.name);
    } }, c.group ? "👥 " : "💬 ", c.name)) : [h("p", { class: "muted" }, "Nessuna chat disponibile")]));
  }
  function fillGrid(g, list) {
    g.innerHTML = "";
    if (g.parentNode) g.parentNode.querySelectorAll(":scope > .empty").forEach(e => e.remove());
    if (!list.length && g.parentNode) g.parentNode.append(h("div", { class: "empty" }, "Niente da mostrare qui, per ora."));
    list.forEach(p => g.append(h("div", { class: "cell", style: `background-image:url(${p.preview || ""})`, onclick: () => p.kind === "V" ? tube(p) : openComm(p, true) },
      p.kind === "V" ? h("span", { class: "v", html: ic("reel") }) : null)));
  }
  function renderSearch(sc) {
    const q = h("input", { class: "field", placeholder: "Cerca un account" }); const res = h("div", { class: "glass", style: "padding:6px;margin-top:10px" });
    let t; q.oninput = () => { clearTimeout(t); t = setTimeout(run, 300); };
    const run = () => users(q.value, list => { res.innerHTML = ""; list.forEach(([u, on]) => res.append(h("div", { class: "item", onclick: () => openProfile(u) }, avatar(u, on === "1"), h("div", { class: "name" }, u)))); });
    sc.append(q, res); run();
  }
  function openProfile(u) { profileUser = u; view = "profile"; render(); }
  function renderProfile(sc) {
    sc.append(h("div", { id: "ig-prof", class: "profile-head glass" }));
    Net.send("IGPROFILE|" + profileUser); renderProfileHead();
    const tabs = h("div", { class: "ig-tabs" }); const g = h("div", { class: "grid3" });
    const mine = profileUser.toLowerCase() === (App.me || "").toLowerCase();
    let loadSeq = 0;
    const load = mode => {
      const my = ++loadSeq; g.innerHTML = ""; sc.querySelectorAll(":scope > .empty").forEach(e => e.remove());
      feed(mode === "S" ? "favs" : "user:" + profileUser, 0, 30, list => { if (my === loadSeq) fillGrid(g, list.filter(p => mode === "S" || (mode === "P" ? p.kind !== "V" : p.kind === "V"))); });
    };
    [["P", "Post"], ["V", "Ghost-tube"]].concat(mine ? [["S", "Salvati"]] : []).forEach(([m, t], i) => tabs.append(h("span", { class: "chip" + (i === 0 ? " on" : ""), onclick: e => { tabs.querySelectorAll(".chip").forEach(c => c.classList.remove("on")); e.target.classList.add("on"); load(m); } }, t)));
    sc.append(tabs, g); load("P");
  }
  function renderProfileHead() {
    const box = $("#ig-prof"); if (!box) return; const pr = profiles.get((profileUser || "").toLowerCase()) || { posts: 0, followers: 0, following: 0, bio: "" };
    const mine = (profileUser || "").toLowerCase() === (App.me || "").toLowerCase();
    box.innerHTML = "";
    box.append(avatar(profileUser), h("div", { style: "flex:1;min-width:0" }, h("b", { style: "font-size:1.2em" }, profileUser),
      h("div", { class: "stats" }, h("span", {}, h("b", {}, pr.posts), "post"), h("span", {}, h("b", {}, pr.followers), "follower"), h("span", {}, h("b", {}, pr.following), "seguiti")),
      h("div", { class: "muted" }, pr.bio || (mine ? "Aggiungi una biografia" : "")),
      mine ? h("button", { class: "btn small", onclick: () => { const b = prompt("La tua biografia", pr.bio || ""); if (b !== null) Net.send("IGBIO|" + escf(b)); } }, "Modifica biografia")
        : h("button", { class: "btn small" + (pr.iFollow ? "" : " primary"), onclick: () => Net.send(`IGFOLLOW|${profileUser}|${pr.iFollow ? 0 : 1}`) }, pr.iFollow ? "Segui già" : "Segui")));
  }

  // ---------------------------------------------------------------- commenti
  let openComments = null, commSheet = null;
  function openComm(p, withMedia) {
    openComments = p.id; Net.send("IGCOMMENTS|" + p.id); comments.set(p.id, comments.get(p.id) || []);
    const list = h("div", { class: "comments", id: "ig-comments" });
    const input = h("input", { class: "field", placeholder: "Aggiungi un commento..." });
    const mediaBox = withMedia ? h("div", { class: "post-media", style: "border-radius:16px;overflow:hidden;margin-bottom:10px" }, h("img", { src: p.preview || "" })) : null;
    if (mediaBox) getMedia(p, u => mediaBox.querySelector("img").src = u);
    commSheet = sheet("Commenti · " + p.author, mediaBox, list,
      h("div", { class: "row", style: "margin-top:10px;align-items:center" },
        h("button", { class: "iconbtn", title: "Sticker", onclick: () => stickers(p) }, "👻"),
        h("button", { class: "iconbtn", title: "GIF", onclick: () => gifs(p) }, "GIF"), input,
        h("button", { class: "iconbtn fill", onclick: () => { const t = input.value.trim(); if (t) { comment(p, "T", t); input.value = ""; } }, html: ic("share") })));
    renderComments();
  }
  function comment(p, kind, content) { Net.send(`IGCOMMENT|${p.id}|${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}|${kind}|${escf(content)}`); }
  function renderComments() {
    const list = $("#ig-comments"); if (!list) return; list.innerHTML = "";
    const l = comments.get(openComments) || [];
    if (!l.length) list.append(h("p", { class: "muted" }, "Ancora nessun commento. Scrivi il primo!"));
    for (const c of l) {
      const body = h("div", { style: "flex:1" }, h("b", {}, c.author + " "));
      if (c.kind === "T") body.append(c.content);
      else if (c.kind === "S") body.append(c.content.length < 40 ? h("div", { style: "font-size:48px" }, decodeSticker(c.content)) : h("img", { src: "data:image/png;base64," + c.content }));
      else body.append(h("img", { src: c.content, alt: "GIF" }));
      const mine = c.author.toLowerCase() === (App.me || "").toLowerCase();
      body.append(h("div", { class: "muted" }, ago(c.time), mine ? h("span", { style: "margin-left:10px;cursor:pointer", onclick: () => Net.send(`IGUNCOMMENT|${openComments}|${c.id}`) }, "Elimina") : null));
      list.append(h("div", { class: "c" }, avatar(c.author), body));
    }
  }
  function decodeSticker(b64) { try { return decodeURIComponent(escape(atob(b64))); } catch (e) { return "👻"; } }
  /** Sticker: emoji disegnata su una tela e inviata come immagine (come gli sticker del computer). */
  function stickers(p) {
    const s = sheet("Sticker", h("div", { class: "stickers" }, STICKERS.map(e => h("span", { onclick: () => {
      const cv = document.createElement("canvas"); cv.width = cv.height = 160; const g = cv.getContext("2d");
      g.font = "120px serif"; g.textAlign = "center"; g.textBaseline = "middle"; g.shadowColor = "rgba(0,0,0,.25)"; g.shadowBlur = 8; g.fillText(e, 80, 88);
      comment(p, "S", cv.toDataURL("image/png").split(",")[1]); s.close();
    } }, e))));
  }
  async function gifs(p) {
    const q = h("input", { class: "field", placeholder: "Cerca una GIF su KLIPY" }); const grid = h("div", { class: "gifgrid" });
    const s = sheet("GIF di KLIPY", q, h("div", { style: "height:8px" }), grid);
    const key = KLIPY_KEY;
    const run = async () => {
      grid.innerHTML = "<p class='muted'>Caricamento...</p>";
      try {
        const ep = q.value.trim() ? "search" : "trending";
        const r = await fetch(`https://api.klipy.com/api/v1/${key}/gifs/${ep}?page=1&per_page=24&customer_id=${encodeURIComponent(App.me || "ghost")}&locale=it&content_filter=medium${q.value.trim() ? "&q=" + encodeURIComponent(q.value.trim()) : ""}`);
        const j = await r.json(); const items = (j.data && (j.data.data || j.data)) || j.results || [];
        grid.innerHTML = "";
        for (const it of items) {
          const pick = (o, sizes) => { for (const s2 of sizes) { const u = o?.file?.[s2]?.gif?.url; if (u) return u; } return null; };
          const prev = pick(it, ["xs", "sm", "md"]), url = pick(it, ["md", "sm", "lg"]);
          if (prev && url) grid.append(h("img", { src: prev, loading: "lazy", onclick: () => { comment(p, "G", url); s.close(); } }));
        }
      } catch (e) { grid.innerHTML = "<p class='err'>GIF non disponibili</p>"; }
    };
    let t; q.oninput = () => { clearTimeout(t); t = setTimeout(run, 400); }; run();
  }

  // ---------------------------------------------------------------- Ghost-tube
  let tubeList = [], tubeIdx = 0, tubePost = null, tubeEl = null;
  function tube(first) {
    feed("V", 0, 30, list => {
      tubeList = first ? [first].concat(list.filter(x => x.id !== first.id)) : list;
      if (!tubeList.length) { toast("Ancora nessun Ghost-tube"); view = "feed"; render(); return; }
      tubeIdx = 0; openTube();
    });
  }
  function openTube() {
    if (tubeEl) tubeEl.remove();
    tubePost = tubeList[tubeIdx];
    const v = h("video", { playsinline: true, loop: true, autoplay: true, poster: tubePost.preview || "" });
    tubeEl = h("div", { class: "tube" }, v, h("div", { class: "side", id: "tube-side" }), h("div", { class: "info" }, h("b", {}, tubePost.author), h("div", {}, tubePost.caption)),
      h("button", { class: "iconbtn close", onclick: () => { tubeEl.remove(); tubeEl = null; tubePost = null; }, html: ic("close") }));
    document.body.append(tubeEl); renderTubeSide();
    getMedia(tubePost, url => { v.src = url; v.play().catch(() => { v.muted = true; v.play(); }); });
    let y0 = null;
    tubeEl.addEventListener("touchstart", e => y0 = e.touches[0].clientY, { passive: true });
    tubeEl.addEventListener("touchend", e => { if (y0 === null) return; const d = e.changedTouches[0].clientY - y0; y0 = null; if (Math.abs(d) > 60) move(d < 0 ? 1 : -1); });
    tubeEl.addEventListener("wheel", e => move(e.deltaY > 0 ? 1 : -1), { passive: true });
  }
  function move(d) { const n = tubeIdx + d; if (n < 0 || n >= tubeList.length) return; tubeIdx = n; openTube(); }
  function renderTubeSide() {
    const s = $("#tube-side"); if (!s || !tubePost) return; const p = tubePost; s.innerHTML = "";
    const b = (icn, label, fn, on) => h("div", {}, h("button", { class: "act" + (on ? " on" : ""), onclick: fn, html: ic(icn) }), h("small", {}, label));
    s.append(b(p.vote > 0 ? "heart" : "heartO", p.likes, () => vote(p, 1), p.vote > 0), b("down", p.dislikes, () => vote(p, -1), p.vote < 0),
      b("comment", p.comments, () => openComm(p)), b("share", p.shares, () => share(p)), b(p.fav ? "fav" : "favO", "", () => fav(p), p.fav));
  }
  function openPost(id) {
    const go = p => p.kind === "V" ? tube(p) : openComm(p, true);
    if (posts.has(id)) return go(posts.get(id));
    feeds.set("one", { list: [], cb: () => { } }); Net.send(`IGONE|one|${id}`);
    setTimeout(() => posts.has(id) ? go(posts.get(id)) : toast("Il post non è più disponibile", true), 900);
  }

  // ---------------------------------------------------------------- crea
  let uploading = null;
  function create() {
    const file = h("input", { type: "file", accept: "image/*,video/*", style: "display:none" });
    const prev = h("div", { class: "post-media", style: "border-radius:16px;overflow:hidden;min-height:180px;display:grid;place-items:center;cursor:pointer;background:var(--field)", onclick: () => file.click() }, h("span", { class: "muted" }, "Tocca per scegliere una foto o un video"));
    const cap = h("textarea", { class: "area", rows: 3, placeholder: "Scrivi una didascalia..." });
    let chosen = null, meta = null;
    file.onchange = async () => {
      chosen = file.files[0]; if (!chosen) return;
      meta = await prepare(chosen);
      prev.innerHTML = ""; prev.append(h("img", { src: meta.previewUrl, style: "width:100%" }));
    };
    const s = sheet("Nuovo post", prev, file, h("div", { style: "height:10px" }), cap, h("div", { style: "height:10px" }),
      h("button", { class: "btn primary block", onclick: async () => {
        if (!chosen || !meta) return toast("Scegli prima una foto o un video", true);
        s.close(); upload(meta, cap.value.trim());
      } }, "Pubblica"));
  }
  async function prepare(f) {
    if (f.type.startsWith("video/")) {
      const url = URL.createObjectURL(f); const v = document.createElement("video"); v.muted = true; v.playsInline = true; v.src = url;
      await new Promise(r => { v.onloadeddata = r; v.onerror = r; });
      try { v.currentTime = Math.min(1, (v.duration || 2) / 2); await new Promise(r => { v.onseeked = r; setTimeout(r, 1500); }); } catch (e) { /* niente */ }
      const k = Math.min(1, 720 / Math.max(v.videoWidth || 720, v.videoHeight || 1280)); const cv = document.createElement("canvas");
      cv.width = Math.round((v.videoWidth || 405) * k); cv.height = Math.round((v.videoHeight || 720) * k); cv.getContext("2d").drawImage(v, 0, 0, cv.width, cv.height);
      const pv = cv.toDataURL("image/jpeg", .7);
      return { kind: "V", blob: f, w: v.videoWidth, h: v.videoHeight, dur: Math.round((v.duration || 0) * 1000), previewUrl: pv, preview: pv.split(",")[1] };
    }
    const blob = await compressImage(f, 1600, .88);
    const img = await new Promise(r => { const i = new Image(); i.onload = () => r(i); i.src = URL.createObjectURL(blob); });
    const k = Math.min(1, 720 / Math.max(img.width, img.height)); const cv = document.createElement("canvas");
    cv.width = Math.round(img.width * k); cv.height = Math.round(img.height * k); cv.getContext("2d").drawImage(img, 0, 0, cv.width, cv.height);
    const pv = cv.toDataURL("image/jpeg", .72);
    return { kind: "P", blob, w: img.width, h: img.height, dur: 0, previewUrl: pv, preview: pv.split(",")[1] };
  }
  async function upload(m, caption) {
    const id = Date.now().toString(36) + Math.random().toString(36).slice(2, 10);
    const buf = new Uint8Array(await m.blob.arrayBuffer());
    if (m.kind === "V" && buf.length > 80 * 1024 * 1024) return toast("Video troppo grande (max 80 MB)", true);
    Net.send(`IGPOST|${id}|${m.kind}|${buf.length}|${m.w}|${m.h}|${m.dur}|${escf(caption)}`);
    Net.send(`IGPREV|${id}|${m.preview}`);
    let crc = Crc32.start(); uploading = 0;
    for (let i = 0; i < buf.length; i += 48 * 1024) {
      const part = buf.subarray(i, i + 48 * 1024); crc = Crc32.update(crc, part);
      Net.send(`IGCHUNK|${id}|${bytesToB64(part)}`);
      const pr = Math.round(100 * Math.min(1, (i + part.length) / buf.length));
      if (pr !== uploading) { uploading = pr; const el = document.querySelector("#ig-scroll .glass"); if (el && el.textContent.startsWith("Pubblicazione")) el.textContent = "Pubblicazione in corso... " + pr + "%"; }
      if (i % (480 * 1024) === 0) await new Promise(r => setTimeout(r, 0));
    }
    Net.send(`IGUPEND|${id}|${Crc32.hex(crc)}`);
  }

  function ago(t) {
    const s = Math.max(0, (Date.now() - t) / 1000);
    return s < 60 ? "adesso" : s < 3600 ? Math.floor(s / 60) + " min" : s < 86400 ? Math.floor(s / 3600) + " h" : new Date(t).toLocaleDateString("it-IT", { day: "numeric", month: "short" });
  }
  return { show, openPost, openProfile };
})();
