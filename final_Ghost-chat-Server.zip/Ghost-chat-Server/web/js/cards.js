/* Ghost-chat mobile · giochi di carte dei gruppi (briscola, scopa, rubamazzo, sette e mezzo) */
"use strict";
const Cards = (() => {
  const SUITS = ["Fantasmi", "Bare", "Fumetti", "Stelle"];
  const RANK = ["A", "2", "3", "4", "5", "6", "7", "F", "C", "R"];
  const NAMES = { briscola: "Briscola", scopa: "Scopa", rubamazzo: "Rubamazzo", settemezzo: "Sette e mezzo" };
  const color = s => s <= 1 ? "var(--accent)" : "#1F1A24"; // i semi "rossi" diventano viola Ghost-chat
  const suitPath = (s, x, y, k, c) => {
    const t = `transform="translate(${x},${y}) scale(${k})"`;
    if (s === 0) return `<g ${t}><path fill="${c}" d="M2 10a8 8 0 0116 0v9l-2.6-2-2.7 2-2.7-2-2.6 2-2.7-2L2 19z"/><circle cx="7.2" cy="10" r="1.6" fill="#fff"/><circle cx="12.8" cy="10" r="1.6" fill="#fff"/></g>`;
    if (s === 1) return `<g ${t}><path fill="${c}" d="M6.5 1h7l4.5 5.5L14.8 19H5.2L2 6.5z"/><path stroke="#fff" stroke-width="1.6" d="M10 4.5v8M7.2 7.3h5.6"/></g>`;
    if (s === 2) return `<g ${t}><path fill="${c}" d="M3 2h14a3 3 0 013 3v8a3 3 0 01-3 3H9l-5 4v-4H3a3 3 0 01-3-3V5a3 3 0 013-3z"/><circle cx="5.5" cy="9" r="1.4" fill="#fff"/><circle cx="10" cy="9" r="1.4" fill="#fff"/><circle cx="14.5" cy="9" r="1.4" fill="#fff"/></g>`;
    return `<g ${t}><path fill="${c}" d="M10 1l2.6 6.1 6.6.6-5 4.4 1.5 6.5L10 15.2l-5.7 3.4 1.5-6.5-5-4.4 6.6-.6z"/></g>`;
  };
  const PIPS = { 1: [[0, 0]], 2: [[0, -.3], [0, .3]], 3: [[0, -.34], [0, 0], [0, .34]], 4: [[-.22, -.28], [.22, -.28], [-.22, .28], [.22, .28]],
    5: [[-.22, -.28], [.22, -.28], [0, 0], [-.22, .28], [.22, .28]], 6: [[-.22, -.32], [.22, -.32], [-.22, 0], [.22, 0], [-.22, .32], [.22, .32]],
    7: [[-.22, -.34], [.22, -.34], [0, -.17], [-.22, 0], [.22, 0], [-.22, .34], [.22, .34]] };
  function face(code) {
    const s = Math.floor(code / 10), r = code % 10, c = color(s);
    let body = "";
    if (r < 7) {
      const big = r === 0;
      for (const [px, py] of PIPS[r + 1]) { const k = big ? 2.2 : .8; body += suitPath(s, 50 + px * 110 - 10 * k, 78 + py * 120 - 10 * k, k, c); }
    } else {
      const hat = r === 7 ? `<path fill="${c}" d="M36 52h28L54 28z"/>` : r === 8 ? `<path fill="${c}" d="M34 56l4-14 6 8 6-10 6 10 6-8 4 14z"/>` :
        `<path fill="#F2C94C" stroke="#B8862B" d="M36 56V38l8 8 6-12 6 12 8-8v18z"/>`;
      body = `<circle cx="50" cy="80" r="30" fill="${c}" opacity=".1"/>${hat}<path fill="${c}" d="M32 72a18 18 0 0136 0v26l-6-4.5-6 4.5-6-4.5-6 4.5-6-4.5-6 4.5z"/><circle cx="43" cy="72" r="3.5" fill="#fff"/><circle cx="57" cy="72" r="3.5" fill="#fff"/>` + suitPath(s, 44, 84, .6, "#fff");
    }
    const corner = `<text x="9" y="22" font-size="19" font-weight="700" fill="${c}">${RANK[r]}</text>` + suitPath(s, 8, 26, .65, c);
    return `<svg viewBox="0 0 100 156"><rect x="1" y="1" width="98" height="154" rx="12" fill="url(#cg)" stroke="rgba(0,0,0,.15)"/><defs><linearGradient id="cg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff"/><stop offset="1" stop-color="#F4EEF8"/></linearGradient></defs>
      <rect x="6" y="6" width="88" height="144" rx="9" fill="none" stroke="${c}" stroke-opacity=".25"/>${corner}<g transform="rotate(180 50 78)">${corner}</g>${body}</svg>`;
  }
  const back = () => `<svg viewBox="0 0 100 156"><defs><linearGradient id="bg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="var(--accent)"/><stop offset="1" stop-color="var(--accent2)"/></linearGradient></defs><rect x="1" y="1" width="98" height="154" rx="12" fill="url(#bg)"/><rect x="8" y="8" width="84" height="140" rx="9" fill="none" stroke="#fff" stroke-opacity=".7" stroke-width="2"/>${suitPath(0, 30, 52, 2, "rgba(255,255,255,.9)")}</svg>`;
  const card = (code, onClick) => { const d = h("div", { class: "card", html: code < 0 ? back() : face(code) }); if (onClick) d.addEventListener("click", onClick); return d; };
  const seven = cards => { const v = cards.reduce((a, c) => a + (c % 10 >= 7 ? .5 : c % 10 + 1), 0); return String(v).replace(".", ","); };

  let el = null, state = null, gid = null;
  Net.on("CARDS", p => {
    const i = p.indexOf("|"); const g = p.slice(0, i); let st; try { st = JSON.parse(p.slice(i + 1)); } catch (e) { return; }
    const c = chatOf("#" + g, true);
    if (!c.games) c.games = new Set();
    if (!c.games.has(st.id)) { c.games.add(st.id); system(c, (st.host === App.me ? "Hai proposto" : st.host + " propone") + " una partita a " + NAMES[st.type] + (st.me >= 0 && st.host !== App.me ? " · sei tra i giocatori" : "")); }
    if (st.me < 0) return;
    if (!el && st.phase === "end") return;
    gid = g; state = st; render();
  });
  const act = a => Net.send(`CARD|${gid}|${state.id}|${a}`);
  function render() {
    if (!el) { el = h("div", { class: "table" }); document.body.append(el); }
    const st = state, me = st.me, my = st.phase === "play" && st.turn === me;
    el.innerHTML = "";
    el.append(h("div", { style: "display:flex;align-items:center;gap:8px" }, h("button", { class: "iconbtn", style: "color:#fff", onclick: close, html: svg("back") }),
      h("b", { style: "flex:1" }, NAMES[st.type] + " · mazzo " + st.deck)));
    if (st.msg) el.append(h("div", { class: "msg" }, st.msg));
    const opps = h("div", { class: "opps" });
    st.players.forEach((p, i) => { if (i === me) return; opps.append(h("div", { class: "opp" + (st.turn === i ? " turn" : "") }, h("b", {}, p.n), h("div", {},
      st.type === "settemezzo" ? (p.bust ? "sballato!" : p.stood ? "sta " + (p.shown.length ? seven(p.shown) : "") : p.cards + " carte") : `${p.cards} carte · ${p.pile} prese${p.scope ? " · " + p.scope + " scope" : ""}`),
      p.shown && p.shown.length ? h("div", { style: "display:flex;gap:3px;margin-top:4px" }, p.shown.map(c => { const k = card(c); k.style.width = "34px"; k.style.height = "53px"; return k; })) : null)); });
    el.append(opps);
    const center = h("div", { class: "center" });
    if (st.type === "briscola" && st.briscola >= 0) center.append(h("div", { style: "text-align:center" }, card(st.briscola), h("small", {}, "Briscola: " + SUITS[Math.floor(st.briscola / 10)])));
    if (st.type === "settemezzo") center.append(h("div", { style: "text-align:center" }, h("small", {}, "Banco"), h("div", { style: "display:flex;gap:4px" }, st.bank.map(c => card(c)), st.phase === "play" ? card(-1) : null)));
    st.table.forEach(c => center.append(card(c)));
    st.trick.forEach(t => center.append(h("div", { style: "text-align:center" }, card(t.c), h("small", {}, t.p === me ? "Tu" : st.players[t.p].n))));
    el.append(center);
    const mine = st.players[me];
    el.append(h("div", { style: "text-align:center;font-size:.85em" }, "Tu · " + (st.type === "settemezzo" ? "valore " + seven(st.hand) : st.type === "rubamazzo" ? mine.pile + " carte prese" : (mine.pts >= 0 ? mine.pts + " punti" : "")),
      my ? h("b", { style: "color:#FFE082;margin-left:8px" }, st.type === "settemezzo" ? "Tocca a te: carta o stai?" : "Tocca a te!") : null));
    el.append(h("div", { class: "hand" + (my ? " myturn" : "") }, st.hand.map(c => card(c, () => { if (my && st.type !== "settemezzo") act("play|" + c); }))));
    const btns = h("div", { style: "display:flex;gap:8px;justify-content:center" });
    if (st.phase === "lobby" && !mine.acc) btns.append(h("button", { class: "btn", onclick: () => { act("decline"); close(); } }, "No grazie"), h("button", { class: "btn primary", onclick: () => act("accept") }, "Gioco anch'io"));
    if (my && st.type === "settemezzo") btns.append(h("button", { class: "btn", onclick: () => act("stand") }, "Sto"), h("button", { class: "btn primary", onclick: () => act("hit") }, "Carta"));
    if (st.phase === "end") btns.append(h("button", { class: "btn primary", onclick: () => { close(); start(gid, st.type, st.players.map(p => p.n)); } }, "Rivincita"));
    if (st.phase !== "end") btns.append(h("button", { class: "btn small", onclick: () => { if (confirm("Abbandonare la partita?")) { act("quit"); close(); } } }, "Abbandona"));
    el.append(btns);
    if (st.phase === "lobby" || st.phase === "end") {
      el.append(h("div", { class: "over glass" }, h("h3", { style: "color:var(--accent);margin:0 0 8px" }, st.phase === "lobby" ? "In attesa dei giocatori" : "Partita finita"),
        ...st.players.map(p => h("div", {}, "• " + p.n + " · " + (st.phase === "lobby" ? (p.acc ? "pronto" : "deve accettare...") : (st.type === "rubamazzo" ? p.pile + " carte" : st.type === "settemezzo" ? (p.pts ? "batte il banco!" : "perde") : p.pts + " punti")))),
        st.result ? h("p", { style: "font-weight:700;color:var(--accent)" }, st.result) : null));
    }
  }
  function close() { if (el) el.remove(); el = null; }
  function start(g, type, players) {
    const others = players.filter(p => p.toLowerCase() !== App.me.toLowerCase());
    Net.send(`CARD|${g}|${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}|new|${type}|${others.join(",")}`);
  }
  function newGame(g) {
    const grp = App.groups.get(g); const members = (grp ? grp.members : []).filter(m => m.toLowerCase() !== (App.me || "").toLowerCase());
    let type = "briscola";
    const seg = h("div", { class: "seg" }, Object.entries(NAMES).map(([k, n]) => h("button", { class: k === type ? "on" : "", onclick: e => { type = k; seg.querySelectorAll("button").forEach(b => b.classList.toggle("on", b === e.target)); } }, n)));
    const picks = members.map(m => ({ m, el: check(m + (App.users.has(m) ? "" : " · offline"), false, () => { }) }));
    const s = sheet("Giochi di carte del gruppo", seg, h("p", { class: "muted" }, "Briscola e scopa: 1 o 3 avversari. Rubamazzo: 1-3. Sette e mezzo: tutti contro il banco. Ognuno deve accettare."),
      ...picks.map(p => p.el), h("button", { class: "btn primary block", onclick: () => {
        const who = picks.filter(p => p.el.querySelector("input").checked).map(p => p.m); const n = who.length + 1;
        const ok = type === "briscola" || type === "scopa" ? n === 2 || n === 4 : type === "rubamazzo" ? n >= 2 && n <= 4 : n <= 8;
        if (!ok) return toast("Numero di giocatori non valido", true);
        s.close(); start(g, type, [App.me, ...who]);
      } }, "Invita a giocare"));
  }
  return { newGame, face };
})();
