/* Configurazione: chiave KLIPY (la stessa della versione per computer) */
const KLIPY_KEY = "HhFzOrwL0SbBzysr34hYTOLgab2XcZNfrTrzD2t4iMNFek71oiXqKapdAsN10f5D";

/* Server online 24/7 (Wispbyte): una sola porta per app, computer e browser. Si cambia dalla schermata di accesso. */
const DEFAULT_SERVER = { host: "78.154.103.51", port: 11112 };
