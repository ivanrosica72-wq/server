/* Ghost-chat mobile · file (foto, video, documenti, vocali, GIF, sticker, visualizzazione singola),
 * emoji, posizione (anche in tempo reale), sfondi delle chat. Stesso protocollo del computer. */
"use strict";
const Media = (() => {
  const CHUNK = 48 * 1024;
  const MAX_FILE = 100 * 1024 * 1024;

  // ============================================================ utilita'
  function bytesToB64(u8) { let s = ""; for (let i = 0; i < u8.length; i += 0x8000) s += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000)); return btoa(s); }
  function b64ToBytes(b) { const bin = atob(b); const u = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i); return u; }
  const Crc32 = (() => {
    const T = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; T[n] = c >>> 0; }
    return { start: () => 0xFFFFFFFF, update: (c, u8) => { for (let i = 0; i < u8.length; i++) c = T[(c ^ u8[i]) & 255] ^ (c >>> 8); return c >>> 0; }, hex: c => ((c ^ 0xFFFFFFFF) >>> 0).toString(16) };
  })();
  const mimeOf = (kind, name) => {
    const ext = (name || "").split(".").pop().toLowerCase();
    if (kind === "GIF") return "image/gif";
    if (kind === "IMAGE") return ext === "png" ? "image/png" : ext === "webp" ? "image/webp" : "image/jpeg";
    if (kind === "VIDEO") return ext === "webm" ? "video/webm" : ext === "mov" ? "video/quicktime" : "video/mp4";
    if (kind === "VOICE") return ext === "webm" ? "audio/webm" : ext === "m4a" ? "audio/mp4" : "audio/wav";
    return ({ pdf: "application/pdf", txt: "text/plain", mp3: "audio/mpeg", png: "image/png", jpg: "image/jpeg", zip: "application/zip" })[ext] || "application/octet-stream";
  };
  const fmtSize = n => n < 1024 ? n + " B" : n < 1048576 ? (n / 1024).toFixed(0) + " KB" : (n / 1048576).toFixed(1) + " MB";
  function loadImage(src) { return new Promise((res, rej) => { const i = new Image(); i.onload = () => res(i); i.onerror = rej; i.src = src; }); }
  async function compressImage(file, max, q) {
    try {
      const url = URL.createObjectURL(file); const img = await loadImage(url); URL.revokeObjectURL(url);
      const k = Math.min(1, max / Math.max(img.width, img.height)); const cv = document.createElement("canvas");
      cv.width = Math.round(img.width * k); cv.height = Math.round(img.height * k); cv.getContext("2d").drawImage(img, 0, 0, cv.width, cv.height);
      return await new Promise(r => cv.toBlob(b => r(b || file), "image/jpeg", q));
    } catch (e) { return file; }
  }
  async function squareJpegB64(file, size, maxChars) {
    try {
      const url = URL.createObjectURL(file); const img = await loadImage(url); URL.revokeObjectURL(url);
      const s = Math.min(img.width, img.height); const cv = document.createElement("canvas"); cv.width = cv.height = size;
      cv.getContext("2d").drawImage(img, (img.width - s) / 2, (img.height - s) / 2, s, s, 0, 0, size, size);
      for (let q = .85; q > .2; q -= .1) { const d = cv.toDataURL("image/jpeg", q).split(",")[1]; if (d.length <= maxChars) return d; }
    } catch (e) { /* niente */ }
    return null;
  }
  function download(url, name) { const a = h("a", { href: url, download: name || "file" }); document.body.append(a); a.click(); a.remove(); }

  // ============================================================ invio dei file
  function pickFiles(c, accept, once, camera) {
    const inp = h("input", { type: "file", accept, multiple: !once && !camera, style: "display:none" });
    if (camera) inp.setAttribute("capture", "environment");
    inp.onchange = async () => { const files = [...inp.files]; inp.remove(); for (const f of files) await sendFile(c, f, { once }); };
    document.body.append(inp); inp.click();
  }
  async function sendFile(c, file, opts = {}) {
    if (file.size > MAX_FILE) { toast("File troppo grande (max 100 MB)", true); return; }
    const t = file.type || "";
    let kind = t === "image/gif" ? "GIF" : t.startsWith("image/") ? "IMAGE" : t.startsWith("video/") ? "VIDEO" : "FILE";
    let blob = file, name = file.name || "file";
    if (kind === "IMAGE" && !opts.sticker) { blob = await compressImage(file, 1600, .85); name = name.replace(/\.[^.]+$/, "") + ".jpg"; }
    if (opts.once && kind !== "IMAGE" && kind !== "GIF") { toast("A visualizzazione singola si possono mandare solo foto", true); return; }
    return sendBlob(c, blob, kind, name, opts);
  }
  /** FILE|dest|id|tipo|byte|nome|extra · CHUNK|dest|id|b64 · FILEEND|dest|id|crc */
  async function sendBlob(c, blob, kind, name, opts = {}) {
    if (!(await checkSend(c))) return;
    const buf = new Uint8Array(await blob.arrayBuffer());
    if (buf.length > MAX_FILE) { toast("File troppo grande (max 100 MB)", true); return; }
    const id = newId(); const safe = String(name || "file").replace(/[|\\/\n\r]/g, "_").slice(0, 120);
    const t = timerOf(c);
    const extra = [kind === "VOICE" ? Math.round(opts.dur || 0) : null, opts.once ? "once" : null, opts.sticker ? "sticker" : null, t ? "t" + t : null].filter(x => x != null && x !== "").join(";");
    const m = { id, dir: "out", time: Date.now(), fwd: !!opts.fwd,
      file: { kind, name: safe, size: buf.length, url: opts.once ? null : URL.createObjectURL(blob), blob: opts.once ? null : blob, once: !!opts.once, sticker: !!opts.sticker, dur: opts.dur || 0, progress: 0 } };
    trackOut(c, m); m.state = "sending";
    addMsg(c, m);
    const dests = c.bc ? (bcList(c.id)?.members || []) : [destOf(c)];
    if (!dests.every(d => Net.send(`FILE|${d}|${id}|${kind}|${buf.length}|${safe}|${extra}`))) { m.state = "failed"; refreshMsg(c, m); toast("Non sei connesso", true); return; }
    let crc = Crc32.start(); let lastPaint = 0;
    for (let i = 0; i < buf.length; i += CHUNK) {
      const part = buf.subarray(i, i + CHUNK); crc = Crc32.update(crc, part);
      const b64 = bytesToB64(part);
      for (const d of dests) if (!Net.send(`CHUNK|${d}|${id}|${b64}`)) { m.state = "failed"; m.error = "Connessione persa durante l'invio"; refreshMsg(c, m); return; }
      m.file.progress = Math.min(1, (i + part.length) / buf.length);
      if (Date.now() - lastPaint > 300) { lastPaint = Date.now(); refreshMsg(c, m); }
      if ((i / CHUNK) % 8 === 7) await new Promise(r => setTimeout(r, 15));
      if (m.deleted) { for (const d of dests) Net.send(`FILECANCEL|${d}|${id}|annullato`); return; }
    }
    for (const d of dests) Net.send(`FILEEND|${d}|${id}|${Crc32.hex(crc)}`);
    m.file.progress = 1; m.state = "sent"; refreshMsg(c, m);
  }

  // ============================================================ ricezione dei file
  const incoming = new Map();
  Net.on("FILE", p => {
    const f = p.split("|"); const o = origin(f[0]); if (!o.chat) return;
    const key = f[0] + "/" + f[1]; const size = parseInt(f[3], 10) || 0;
    let kind = (f[2] || "FILE").toUpperCase(); if (!["IMAGE", "VIDEO", "FILE", "VOICE", "GIF"].includes(kind)) kind = "FILE";
    const name = (f[4] || "file").replace(/\\p/g, "|");
    if (kind === "IMAGE" && /\.gif$/i.test(name)) kind = "GIF";
    const flags = (f[5] || "").split(";").map(x => x.trim()).filter(Boolean);
    let dur = 0, timer = 0; const set = new Set();
    for (const x of flags) { if (/^\d{1,9}$/.test(x)) dur = +x; else if (/^t\d{1,8}$/.test(x)) timer = +x.slice(1); else set.add(x); }
    const old = findMsg(o.chat, f[1]);
    const m = old && old.dir === "in" ? old : { id: f[1], dir: "in", who: o.group ? o.nick : null, time: Date.now() };
    m.file = { kind, name, size, dur, once: set.has("once") && ["IMAGE", "GIF", "VOICE"].includes(kind), sticker: set.has("sticker") && (kind === "IMAGE" || kind === "GIF"), progress: 0, url: null };
    if (timer) { m.timer = timer; m.expiresAt = Date.now() + timer * 1000; }
    if (size > MAX_FILE) { m.file.error = "File troppo grande"; }
    incoming.set(key, { o, m, parts: [], got: 0, crc: Crc32.start(), lastPaint: 0 });
    if (!old) addMsg(o.chat, m); else refreshMsg(o.chat, m);
  });
  Net.on("CHUNK", p => {
    const f = p.split("|"); const t = incoming.get(f[0] + "/" + f[1]); if (!t || t.m.file.error) return;
    try { const u = b64ToBytes(f[2] || ""); t.parts.push(u); t.got += u.length; t.crc = Crc32.update(t.crc, u); } catch (e) { t.m.file.error = "Dati danneggiati"; }
    t.m.file.progress = t.m.file.size ? Math.min(1, t.got / t.m.file.size) : 0;
    if (Date.now() - t.lastPaint > 400) { t.lastPaint = Date.now(); refreshMsg(t.o.chat, t.m); }
  });
  Net.on("FILEEND", p => {
    const f = p.split("|"); const key = f[0] + "/" + f[1]; const t = incoming.get(key); if (!t) return; incoming.delete(key);
    const { o, m } = t;
    const ok = !t.m.file.error && (!f[2] || parseInt(f[2], 16) === parseInt(Crc32.hex(t.crc), 16));
    if (!ok) { m.file.error = m.file.error || "File arrivato danneggiato"; refreshMsg(o.chat, m); return; }
    const blob = new Blob(t.parts, { type: mimeOf(m.file.kind, m.file.name) });
    m.file.blob = blob; m.file.url = URL.createObjectURL(blob); m.file.progress = 1;
    if (m.file.kind === "VOICE" && !m.file.dur) { const a = new Audio(); a.src = m.file.url; a.onloadedmetadata = () => { if (isFinite(a.duration)) { m.file.dur = a.duration * 1000; refreshMsg(o.chat, m); } }; }
    refreshMsg(o.chat, m);
    Net.send(`ACK|${o.group ? o.chat.id : o.nick}|${m.id}|D|${Date.now()}`);
    if (App.active === o.chat) sendReadReceipts(o.chat);
  });
  Net.on("FILECANCEL", p => {
    const f = p.split("|"); const key = f[0] + "/" + f[1]; const t = incoming.get(key); if (!t) return; incoming.delete(key);
    t.m.file.error = "Invio annullato"; refreshMsg(t.o.chat, t.m);
  });

  // ============================================================ visualizzazione
  function renderFile(c, m) {
    const f = m.file; const box = h("div", { class: "file" });
    if (f.error) { box.append(h("div", { class: "muted-in" }, "⚠ " + (f.name || "File") + ": " + f.error)); return box; }
    const loading = m.dir === "in" ? !f.url && !f.opened : f.progress < 1 && m.state === "sending";
    if (f.once) {
      if (m.dir === "out") box.append(h("div", { class: "once" }, h("span", {}, "👁"), h("div", {}, h("b", {}, f.kind === "VOICE" ? "Vocale" : "Foto"), h("div", { class: "sub" }, f.opened ? "Aperta" : "Visualizzazione singola"))));
      else if (f.opened) box.append(h("div", { class: "once dim" }, h("span", {}, "👁"), h("div", {}, h("b", {}, "Aperta"), h("div", { class: "sub" }, "Visualizzazione singola"))));
      else box.append(h("div", { class: "once", onclick: e => { e.stopPropagation(); if (f.url) openOnce(c, m); } }, h("span", {}, "👁"),
        h("div", {}, h("b", {}, f.kind === "VOICE" ? "Vocale" : "Foto"), h("div", { class: "sub" }, f.url ? "Tocca per aprire · una volta sola" : "Arrivo… " + Math.round(f.progress * 100) + "%"))));
      return box;
    }
    if (loading) box.append(h("div", { class: "progress" }, h("div", { style: `width:${Math.round((f.progress || 0) * 100)}%` })));
    if (!f.url) { box.append(h("div", { class: "muted-in" }, (f.kind === "VOICE" ? "🎤 Vocale" : "📎 " + f.name) + " · " + fmtSize(f.size || 0))); return box; }
    if (f.kind === "IMAGE" || f.kind === "GIF") box.append(h("img", { src: f.url, alt: "", class: f.sticker ? "stk" : "", onclick: e => { e.stopPropagation(); viewer(f.url, f.name); } }));
    else if (f.kind === "VIDEO") box.append(h("video", { src: f.url, controls: true, playsinline: true, preload: "metadata" }));
    else if (f.kind === "VOICE") box.append(voicePlayer(f));
    else box.append(h("a", { class: "doc", href: f.url, download: f.name, onclick: e => e.stopPropagation() }, h("span", { class: "di" }, "📄"), h("div", {}, h("b", {}, f.name), h("div", { class: "sub" }, fmtSize(f.size || 0)))));
    return box;
  }
  function voicePlayer(f) {
    const a = new Audio(f.url); let speed = 1;
    const btn = h("button", { class: "vplay", html: "▶" });
    const bar = h("div", { class: "vbar" }, h("div", {}));
    const lbl = h("small", {}, fmtDur(f.dur || 0));
    const sp = h("button", { class: "vspeed" }, "1×");
    btn.onclick = e => { e.stopPropagation(); if (a.paused) { document.querySelectorAll("audio").forEach(x => x.pause()); a.play(); } else a.pause(); };
    sp.onclick = e => { e.stopPropagation(); speed = speed === 1 ? 1.5 : speed === 1.5 ? 2 : 1; a.playbackRate = speed; sp.textContent = speed + "×"; };
    a.onplay = () => btn.innerHTML = "⏸"; a.onpause = a.onended = () => btn.innerHTML = "▶";
    a.ontimeupdate = () => { const d = a.duration && isFinite(a.duration) ? a.duration : (f.dur || 1) / 1000; bar.firstChild.style.width = Math.min(100, a.currentTime * 100 / d) + "%"; lbl.textContent = fmtDur(a.currentTime * 1000); };
    bar.onclick = e => { e.stopPropagation(); const r = bar.getBoundingClientRect(); const d = a.duration && isFinite(a.duration) ? a.duration : (f.dur || 0) / 1000; a.currentTime = d * (e.clientX - r.left) / r.width; };
    return h("div", { class: "voice" }, btn, bar, lbl, sp);
  }
  function viewer(url, name, onClose) {
    const w = h("div", { class: "viewer", onclick: e => { if (e.target === w) close(); } },
      h("img", { src: url, alt: "" }),
      h("div", { class: "vtools" }, name ? h("button", { class: "btn small", onclick: () => download(url, name) }, "Salva") : null, h("button", { class: "btn small", onclick: () => close() }, "Chiudi")));
    function close() { w.remove(); if (onClose) onClose(); }
    document.body.append(w);
  }
  function openOnce(c, m) {
    const f = m.file;
    const done = () => {
      f.opened = true; try { URL.revokeObjectURL(f.url); } catch (e) { /* niente */ } f.url = null; f.blob = null;
      Net.send(`ACK|${c.group ? c.id : c.id}|${m.id}|O|${Date.now()}`); refreshMsg(c, m);
    };
    if (f.kind === "VOICE") { const a = new Audio(f.url); a.onended = done; a.play(); toast("👁 Vocale a riproduzione singola"); return; }
    const w = h("div", { class: "viewer once-view" }, h("img", { src: f.url, alt: "" }), h("div", { class: "vtools" }, h("span", { class: "muted", style: "color:#fff" }, "👁 Si può vedere una volta sola"), h("button", { class: "btn small", onclick: () => { w.remove(); done(); } }, "Chiudi")));
    w.addEventListener("contextmenu", e => e.preventDefault());
    document.body.append(w);
  }

  // ============================================================ vocali (WAV 16 kHz mono, come sul computer)
  async function recordVoice(c) {
    if (!(await checkSend(c))) return;
    let stream;
    try { stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true } }); }
    catch (e) { toast("Microfono non disponibile: consenti l'accesso al microfono", true); return; }
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const src = ctx.createMediaStreamSource(stream); const proc = ctx.createScriptProcessor(4096, 1, 1);
    const chunks = []; let level = 0; const start = Date.now(); let once = false;
    proc.onaudioprocess = e => { const d = e.inputBuffer.getChannelData(0); chunks.push(new Float32Array(d)); let s = 0; for (let i = 0; i < d.length; i += 16) s = Math.max(s, Math.abs(d[i])); level = s; };
    src.connect(proc); proc.connect(ctx.destination);
    sendTyping(c, "r");
    const t = h("b", { style: "font-size:1.6em" }, "0:00"); const meter = h("div", { class: "meter" }, h("div", {}));
    const timer = setInterval(() => { t.textContent = fmtDur(Date.now() - start); meter.firstChild.style.width = Math.min(100, level * 160) + "%"; if (Date.now() - start > 15 * 60000) finish(true); sendTyping(c, "r"); }, 200);
    const s = sheet("🎤 Registrazione", h("div", { style: "text-align:center;margin:10px 0" }, h("span", { class: "rec-dot" }), t), meter,
      check("Visualizzazione singola", false, v => once = v),
      h("div", { class: "row", style: "margin-top:12px" }, h("button", { class: "btn", onclick: () => finish(false) }, "Annulla"), h("button", { class: "btn primary", onclick: () => finish(true) }, "Invia")));
    s.onclose = () => finish(false);
    let ended = false;
    function finish(ok) {
      if (ended) return; ended = true; clearInterval(timer); s.close();
      try { proc.disconnect(); src.disconnect(); } catch (e) { /* niente */ } stream.getTracks().forEach(x => x.stop());
      sendTyping(c, "0");
      const rate = ctx.sampleRate; ctx.close();
      const dur = Date.now() - start;
      if (!ok) return;
      if (dur < 700) { toast("Vocale troppo corto", true); return; }
      const wav = encodeWav(chunks, rate, 16000);
      const name = "Vocale " + new Date().toTimeString().slice(0, 8).replace(/:/g, ".") + ".wav";
      sendBlob(c, wav, "VOICE", name, { dur, once });
    }
  }
  function encodeWav(chunks, inRate, outRate) {
    let n = 0; for (const c of chunks) n += c.length;
    const all = new Float32Array(n); let o = 0; for (const c of chunks) { all.set(c, o); o += c.length; }
    const ratio = inRate / outRate; const len = Math.floor(all.length / ratio);
    const buf = new ArrayBuffer(44 + len * 2); const v = new DataView(buf);
    const w = (p, s) => { for (let i = 0; i < s.length; i++) v.setUint8(p + i, s.charCodeAt(i)); };
    w(0, "RIFF"); v.setUint32(4, 36 + len * 2, true); w(8, "WAVE"); w(12, "fmt "); v.setUint32(16, 16, true); v.setUint16(20, 1, true); v.setUint16(22, 1, true);
    v.setUint32(24, outRate, true); v.setUint32(28, outRate * 2, true); v.setUint16(32, 2, true); v.setUint16(34, 16, true); w(36, "data"); v.setUint32(40, len * 2, true);
    for (let i = 0; i < len; i++) {
      const a = i * ratio, i0 = Math.floor(a), fr = a - i0; const s = (all[i0] || 0) * (1 - fr) + (all[i0 + 1] || 0) * fr;
      v.setInt16(44 + i * 2, Math.max(-1, Math.min(1, s)) * 0x7FFF, true);
    }
    return new Blob([buf], { type: "audio/wav" });
  }

  // ============================================================ emoji
  const EMOJI = {
    "😀": "😀 😃 😄 😁 😆 😅 🤣 😂 🙂 🙃 😉 😊 😇 🥰 😍 🤩 😘 😗 😚 😙 😋 😛 😜 🤪 😝 🤑 🤗 🤭 🤫 🤔 🤐 🤨 😐 😑 😶 😏 😒 🙄 😬 🤥 😌 😔 😪 🤤 😴 😷 🤒 🤕 🤢 🤮 🤧 🥵 🥶 🥴 😵 🤯 🤠 🥳 😎 🤓 🧐 😕 😟 🙁 😮 😯 😲 😳 🥺 😦 😧 😨 😰 😥 😢 😭 😱 😖 😣 😞 😓 😩 😫 🥱 😤 😡 😠 🤬 😈 👿 💀 ☠️ 💩 🤡 👹 👺 👻 👽 👾 🤖 😺 😸 😹 😻 😼 😽 🙀 😿 😾",
    "👋": "👋 🤚 🖐 ✋ 🖖 👌 🤌 🤏 ✌️ 🤞 🤟 🤘 🤙 👈 👉 👆 🖕 👇 ☝️ 👍 👎 ✊ 👊 🤛 🤜 👏 🙌 👐 🤲 🤝 🙏 ✍️ 💅 🤳 💪 🦾 🦵 🦶 👂 🦻 👃 🧠 🫀 🫁 🦷 🦴 👀 👁 👅 👄 💋 👶 🧒 👦 👧 🧑 👱 👨 🧔 👩 🧓 👴 👵 🙍 🙎 🙅 🙆 💁 🙋 🧏 🙇 🤦 🤷 💃 🕺 👯 🧘 🛀 🛌",
    "❤️": "❤️ 🧡 💛 💚 💙 💜 🖤 🤍 🤎 💔 ❣️ 💕 💞 💓 💗 💖 💘 💝 💟 ☮️ ✝️ ☪️ 🕉 ☸️ ✡️ 🔯 🕎 ☯️ ☦️ 🛐 ⛎ ♈ ♉ ♊ ♋ ♌ ♍ ♎ ♏ ♐ ♑ ♒ ♓ 🆔 ⚛️ 🉑 ☢️ ☣️ 💯 💢 ♨️ 🚫 ❌ ⭕ 🛑 ⛔ 📛 ❗ ❕ ❓ ❔ ‼️ ⁉️ ✅ ☑️ ✔️ ➕ ➖ ➗ ✖️ 💲 💱 ™️ ©️ ®️ 〰️ ➰ ➿ 🔚 🔙 🔛 🔝 🔜 ✨ ⭐ 🌟 💫 ⚡ 🔥 💥",
    "🐶": "🐶 🐱 🐭 🐹 🐰 🦊 🐻 🐼 🐨 🐯 🦁 🐮 🐷 🐽 🐸 🐵 🙈 🙉 🙊 🐒 🐔 🐧 🐦 🐤 🐣 🐥 🦆 🦅 🦉 🦇 🐺 🐗 🐴 🦄 🐝 🐛 🦋 🐌 🐞 🐜 🦟 🦗 🕷 🦂 🐢 🐍 🦎 🦖 🦕 🐙 🦑 🦐 🦞 🦀 🐡 🐠 🐟 🐬 🐳 🐋 🦈 🐊 🐅 🐆 🦓 🦍 🦧 🐘 🦛 🦏 🐪 🐫 🦒 🦘 🐃 🐂 🐄 🐎 🐖 🐏 🐑 🦙 🐐 🦌 🐕 🐩 🐈 🐓 🦃 🦚 🦜 🦢 🦩 🕊 🐇 🦝 🦨 🦡 🦦 🦥 🐁 🐀 🐿 🦔 🌵 🎄 🌲 🌳 🌴 🌱 🌿 ☘️ 🍀 🍁 🍂 🍃 🍄 🌾 💐 🌷 🌹 🥀 🌺 🌸 🌼 🌻 🌞 🌝 🌛 🌜 🌚 🌕 🌙 🌎 🪐 ⭐ ☀️ ⛅ ☁️ 🌧 ⛈ 🌩 ❄️ ☃️ ⛄ 🌬 💨 💧 💦 ☔ 🌊 🌈",
    "🍕": "🍏 🍎 🍐 🍊 🍋 🍌 🍉 🍇 🍓 🍈 🍒 🍑 🥭 🍍 🥥 🥝 🍅 🍆 🥑 🥦 🥬 🥒 🌶 🌽 🥕 🧄 🧅 🥔 🍠 🥐 🥯 🍞 🥖 🥨 🧀 🥚 🍳 🧈 🥞 🧇 🥓 🥩 🍗 🍖 🌭 🍔 🍟 🍕 🥪 🥙 🧆 🌮 🌯 🥗 🥘 🥫 🍝 🍜 🍲 🍛 🍣 🍱 🥟 🦪 🍤 🍙 🍚 🍘 🍥 🥠 🥮 🍢 🍡 🍧 🍨 🍦 🥧 🧁 🍰 🎂 🍮 🍭 🍬 🍫 🍿 🍩 🍪 🌰 🥜 🍯 🥛 🍼 ☕ 🍵 🧃 🥤 🍶 🍺 🍻 🥂 🍷 🥃 🍸 🍹 🧉 🍾 🧊",
    "⚽": "⚽ 🏀 🏈 ⚾ 🥎 🎾 🏐 🏉 🥏 🎱 🪀 🏓 🏸 🏒 🏑 🥍 🏏 🥅 ⛳ 🪁 🏹 🎣 🤿 🥊 🥋 🎽 🛹 🛼 🛷 ⛸ 🥌 🎿 ⛷ 🏂 🏋️ 🤸 ⛹️ 🤺 🤾 🏌️ 🏇 🧘 🏄 🏊 🤽 🚣 🧗 🚵 🚴 🏆 🥇 🥈 🥉 🏅 🎖 🏵 🎗 🎫 🎟 🎪 🤹 🎭 🩰 🎨 🎬 🎤 🎧 🎼 🎹 🥁 🎷 🎺 🎸 🪕 🎻 🎲 ♟ 🎯 🎳 🎮 🎰 🧩",
    "🚗": "🚗 🚕 🚙 🚌 🚎 🏎 🚓 🚑 🚒 🚐 🚚 🚛 🚜 🛴 🚲 🛵 🏍 🚨 🚔 🚍 🚘 🚖 🚡 🚠 🚟 🚃 🚋 🚞 🚝 🚄 🚅 🚈 🚂 🚆 🚇 🚊 🚉 ✈️ 🛫 🛬 🛩 💺 🛰 🚀 🛸 🚁 🛶 ⛵ 🚤 🛥 🛳 ⛴ 🚢 ⚓ ⛽ 🚧 🚦 🚥 🚏 🗺 🗿 🗽 🗼 🏰 🏯 🏟 🎡 🎢 🎠 ⛲ ⛱ 🏖 🏝 🏜 🌋 ⛰ 🏔 🗻 🏕 ⛺ 🏠 🏡 🏘 🏚 🏗 🏭 🏢 🏬 🏣 🏤 🏥 🏦 🏨 🏪 🏫 🏩 💒 🏛 ⛪ 🕌 🕍 🛕 🕋",
    "💡": "⌚ 📱 📲 💻 ⌨️ 🖥 🖨 🖱 🖲 🕹 🗜 💽 💾 💿 📀 📼 📷 📸 📹 🎥 📽 🎞 📞 ☎️ 📟 📠 📺 📻 🎙 🎚 🎛 🧭 ⏱ ⏲ ⏰ 🕰 ⌛ ⏳ 📡 🔋 🔌 💡 🔦 🕯 🪔 🧯 🛢 💸 💵 💴 💶 💷 💰 💳 💎 ⚖️ 🧰 🔧 🔨 ⚒ 🛠 ⛏ 🔩 ⚙️ 🧱 ⛓ 🧲 🔫 💣 🧨 🪓 🔪 🗡 ⚔️ 🛡 🚬 ⚰️ ⚱️ 🏺 🔮 📿 🧿 💈 ⚗️ 🔭 🔬 🕳 🩹 🩺 💊 💉 🩸 🧬 🦠 🧫 🧪 🌡 🧹 🧺 🧻 🚽 🚰 🚿 🛁 🧼 🪒 🧽 🧴 🛎 🔑 🗝 🚪 🪑 🛋 🛏 🛌 🧸 🖼 🛍 🛒 🎁 🎈 🎏 🎀 🎊 🎉 🎎 🏮 🎐 🧧 ✉️ 📩 📨 📧 💌 📥 📤 📦 🏷 📪 📫 📬 📭 📮 📯 📜 📃 📄 📑 🧾 📊 📈 📉 🗒 🗓 📆 📅 🗑 📇 🗃 🗳 🗄 📋 📁 📂 🗂 🗞 📰 📓 📔 📒 📕 📗 📘 📙 📚 📖 🔖 🧷 🔗 📎 🖇 📐 📏 🧮 📌 📍 ✂️ 🖊 🖋 ✒️ 🖌 🖍 📝 ✏️ 🔍 🔎 🔏 🔐 🔒 🔓"
  };
  function emojiPicker(onPick) {
    const recent = Store.get("recentEmoji", []);
    const tabs = h("div", { class: "emoji-tabs" }); const grid = h("div", { class: "emoji-grid" });
    const show = k => { grid.innerHTML = ""; tabs.querySelectorAll("button").forEach(b => b.classList.toggle("on", b.dataset.k === k));
      const list = k === "🕘" ? recent : EMOJI[k].split(" ");
      if (!list.length) grid.append(h("p", { class: "muted" }, "Ancora nessuna emoji recente"));
      for (const e of list) grid.append(h("button", { onclick: () => { const r = [e, ...Store.get("recentEmoji", []).filter(x => x !== e)].slice(0, 32); Store.set("recentEmoji", r); onPick(e); } }, e));
    };
    for (const k of ["🕘", ...Object.keys(EMOJI)]) tabs.append(h("button", { "data-k": k, onclick: () => show(k) }, k));
    sheet(null, tabs, grid);
    show(recent.length ? "🕘" : "😀");
  }

  // ============================================================ GIF (KLIPY) e sticker
  function gifPicker(c) {
    const q = h("input", { class: "field", placeholder: "Cerca una GIF su KLIPY" }); const grid = h("div", { class: "gifgrid" });
    const s = sheet("GIF", q, h("small", { class: "muted" }, "Powered by KLIPY"), h("div", { style: "height:8px" }), grid);
    const run = async () => {
      grid.innerHTML = "<p class='muted'>Caricamento...</p>";
      try {
        const ep = q.value.trim() ? "search" : "trending";
        const r = await fetch(`https://api.klipy.com/api/v1/${KLIPY_KEY}/gifs/${ep}?page=1&per_page=24&customer_id=${encodeURIComponent(App.me || "ghost")}&locale=it&content_filter=medium${q.value.trim() ? "&q=" + encodeURIComponent(q.value.trim().slice(0, 100)) : ""}`);
        const j = await r.json(); const items = (j.data && (j.data.data || j.data)) || j.results || [];
        grid.innerHTML = "";
        const pick = (o, sizes) => { for (const s2 of sizes) { const u = o?.file?.[s2]?.gif?.url; if (u) return u; } return null; };
        for (const it of items) {
          if (it.type === "ad") continue;
          const prev = pick(it, ["sm", "xs", "md"]), url = pick(it, ["md", "hd", "sm", "xs"]);
          if (prev && url) grid.append(h("img", { src: prev, loading: "lazy", onclick: async () => {
            s.close(); toast("Invio della GIF…");
            try { const b = await (await fetch(url)).blob(); if (b.size > 15 * 1024 * 1024) throw new Error("troppo grande"); await sendBlob(c, b, "GIF", (it.slug || "klipy").replace(/[^\w-]/g, "").slice(0, 40) + ".gif", {}); }
            catch (e) { send(c, url); }
          } }));
        }
        if (!grid.children.length) grid.innerHTML = "<p class='muted'>Nessuna GIF trovata</p>";
      } catch (e) { grid.innerHTML = "<p class='err'>GIF non disponibili (serve Internet)</p>"; }
    };
    let t; q.oninput = () => { clearTimeout(t); t = setTimeout(run, 400); }; run();
  }
  const BUILTIN = [["👻", "Boo!"], ["😂", "LOL"], ["❤️", "Ti voglio bene"], ["👍", "Ok!"], ["🎉", "Evviva!"], ["😴", "Nanna"], ["🤔", "Mmm..."], ["🔥", "Top!"], ["🙏", "Grazie"], ["😱", "Nooo!"], ["🍕", "Pizza?"], ["👋", "Ciao!"]];
  function drawSticker(emoji, caption) {
    const cv = document.createElement("canvas"); cv.width = cv.height = 320; const g = cv.getContext("2d");
    g.textAlign = "center"; g.textBaseline = "middle"; g.font = "190px serif"; g.fillText(emoji, 160, 140);
    g.font = "bold 46px Poppins, sans-serif"; g.lineWidth = 10; g.strokeStyle = "#fff"; g.lineJoin = "round"; g.strokeText(caption, 160, 278);
    g.fillStyle = getComputedStyle(document.body).getPropertyValue("--accent").trim() || "#6A1B9A"; g.fillText(caption, 160, 278);
    return cv;
  }
  const canvasBlob = (cv, type = "image/png", q) => new Promise(r => cv.toBlob(r, type, q));
  function stickerPicker(c) {
    const mine = Store.get("stickers", []);
    const grid = h("div", { class: "stk-grid" });
    for (const url of mine) grid.append(h("img", { src: url, onclick: async () => { s.close(); const b = await (await fetch(url)).blob(); sendBlob(c, b, "IMAGE", "sticker.png", { sticker: true }); } }));
    for (const [e, t] of BUILTIN) { const cv = drawSticker(e, t); grid.append(h("img", { src: cv.toDataURL(), onclick: async () => { s.close(); sendBlob(c, await canvasBlob(cv), "IMAGE", "sticker.png", { sticker: true }); } })); }
    const s = sheet("Sticker", grid, h("div", { class: "row", style: "margin-top:10px" }, h("button", { class: "btn small", onclick: () => { s.close(); stickerManager(); } }, "Crea uno sticker da una foto")));
  }
  async function makeSticker(src) {
    const img = await loadImage(src); const cv = document.createElement("canvas"); const k = Math.min(1, 384 / Math.max(img.width, img.height));
    cv.width = Math.round(img.width * k); cv.height = Math.round(img.height * k); cv.getContext("2d").drawImage(img, 0, 0, cv.width, cv.height);
    return cv.toDataURL("image/png");
  }
  async function saveSticker(src) {
    try { const d = await makeSticker(src); const list = Store.get("stickers", []); list.unshift(d); Store.set("stickers", list.slice(0, 40)); toast("Aggiunto ai tuoi sticker 🌟"); }
    catch (e) { toast("Sticker non salvato", true); }
  }
  function stickerManager() {
    const list = Store.get("stickers", []);
    const inp = h("input", { type: "file", accept: "image/*", style: "display:none", onchange: async () => { const f = inp.files[0]; if (!f) return; const u = URL.createObjectURL(f); await saveSticker(u); URL.revokeObjectURL(u); s.close(); stickerManager(); } });
    const grid = h("div", { class: "stk-grid" }, ...list.map((u, i) => h("div", { class: "stk-del" }, h("img", { src: u }), h("button", { onclick: () => { list.splice(i, 1); Store.set("stickers", list); s.close(); stickerManager(); } }, "✕"))));
    const s = sheet("I miei sticker", h("p", { class: "muted" }, "Scegli una foto (meglio se con lo sfondo trasparente): diventa uno sticker da mandare in chat. Puoi anche tenere premuto uno sticker ricevuto."),
      list.length ? grid : h("p", { class: "muted" }, "Ancora nessuno sticker personale."), inp, h("button", { class: "btn primary", onclick: () => inp.click() }, "+ Nuovo sticker"));
  }

  // ============================================================ posizione
  function getPosition() {
    return new Promise((res, rej) => {
      if (!navigator.geolocation) return rej(new Error("Posizione non disponibile su questo dispositivo"));
      navigator.geolocation.getCurrentPosition(p => res(p.coords), e => rej(new Error(e.code === 1 ? "Permesso per la posizione negato" : "Posizione non disponibile")), { enableHighAccuracy: true, timeout: 15000, maximumAge: 30000 });
    });
  }
  async function shareLocation(c, live) {
    if (!(await checkSend(c))) return;
    let minutes = 0;
    if (live) {
      const choice = await new Promise(res => { const s = sheet("📡 Posizione in tempo reale", h("p", { class: "muted" }, "Per quanto tempo vuoi condividerla?"),
        ...[[15, "15 minuti"], [60, "1 ora"], [480, "8 ore"]].map(([v, t]) => h("div", { class: "item", onclick: () => { s.close(); res(v); } }, t))); s.onclose = () => res(0); });
      if (!choice) return; minutes = choice;
    }
    toast("Ricerca della posizione…");
    try {
      const p = await getPosition();
      const label = await ask("Posizione", "Vuoi aggiungere un'etichetta? (facoltativa)", "Es. Sono qui al bar", "", "Invia");
      if (label === null) return;
      const m = sendLocation(c, p.latitude, p.longitude, Math.round(p.accuracy || 0), minutes * 60000, label.trim().slice(0, 80));
      if (live && m) startLive(c, m);
    } catch (e) { toast(e.message, true); }
  }
  /** LOC|dest|id|lat|lon|precisione|durataMs|etichetta */
  function sendLocation(c, lat, lon, acc, liveMs, label) {
    const id = newId();
    const m = { id, dir: "out", time: Date.now(), loc: { lat, lon, acc, label: label || "", live: liveMs > 0, liveUntil: liveMs ? Date.now() + liveMs : 0 } };
    trackOut(c, m);
    if (!dispatch(c, d => `LOC|${d}|${id}|${lat.toFixed(6)}|${lon.toFixed(6)}|${acc}|${liveMs}|${Net.escField(label || "")}`)) m.state = "failed";
    addMsg(c, m); return m;
  }
  const lives = new Map();
  function startLive(c, m) {
    let last = 0;
    const watch = navigator.geolocation.watchPosition(p => {
      if (Date.now() - last < 10000) return; last = Date.now();
      m.loc.lat = p.coords.latitude; m.loc.lon = p.coords.longitude; m.loc.acc = Math.round(p.coords.accuracy || 0); m.loc.updated = Date.now();
      dispatch(c, d => `LOCUPD|${d}|${m.id}|${m.loc.lat.toFixed(6)}|${m.loc.lon.toFixed(6)}|${m.loc.acc}`);
      refreshMsg(c, m);
    }, () => { }, { enableHighAccuracy: true, maximumAge: 10000 });
    m.loc.liveTimer = watch; lives.set(m.id, { c, m, watch });
  }
  function stopLive(c, m) {
    const l = lives.get(m.id); if (l) { navigator.geolocation.clearWatch(l.watch); lives.delete(m.id); }
    m.loc.liveUntil = 0; m.loc.stopped = true; m.loc.liveTimer = null;
    dispatch(c, d => `LOCSTOP|${d}|${m.id}`); refreshMsg(c, m);
  }
  function tickLive() {
    for (const { c, m } of [...lives.values()]) if (m.loc.liveUntil && Date.now() > m.loc.liveUntil) stopLive(c, m);
    for (const c of App.chats.values()) for (const m of c.msgs) if (m.loc && m.dir === "in" && m.loc.live && !m.loc.stopped && m.loc.liveUntil && Date.now() > m.loc.liveUntil) { m.loc.stopped = true; refreshMsg(c, m); }
  }
  function mapTiles(lat, lon, w, hgt, z = 15) {
    const n = 2 ** z; const x = (lon + 180) / 360 * n; const r = lat * Math.PI / 180; const y = (1 - Math.log(Math.tan(r) + 1 / Math.cos(r)) / Math.PI) / 2 * n;
    const px = x * 256, py = y * 256; const left = px - w / 2, top = py - hgt / 2;
    const box = h("div", { class: "map", style: `width:${w}px;height:${hgt}px` });
    for (let tx = Math.floor(left / 256); tx <= Math.floor((left + w) / 256); tx++) for (let ty = Math.floor(top / 256); ty <= Math.floor((top + hgt) / 256); ty++)
      box.append(h("img", { src: `https://tile.openstreetmap.org/${z}/${((tx % n) + n) % n}/${ty}.png`, alt: "", style: `left:${tx * 256 - left}px;top:${ty * 256 - top}px`, loading: "lazy", onerror: e => e.target.remove() }));
    box.append(h("div", { class: "map-pin" }, "📍"), h("small", { class: "map-credit" }, "© OpenStreetMap"));
    return box;
  }
  function renderLoc(c, m) {
    const L = m.loc; const live = L.live && !L.stopped && L.liveUntil > Date.now();
    const url = `https://www.openstreetmap.org/?mlat=${L.lat}&mlon=${L.lon}#map=17/${L.lat}/${L.lon}`;
    const box = h("div", { class: "loc" }, h("a", { href: url, target: "_blank", rel: "noopener", onclick: e => e.stopPropagation() }, mapTiles(L.lat, L.lon, 240, 140)),
      h("div", { class: "loc-info" }, h("b", {}, live ? "📡 Posizione in tempo reale" : L.live ? "📍 Posizione in tempo reale terminata" : "📍 " + (L.label || "Posizione")),
        h("div", { class: "sub" }, (L.label && L.live ? L.label + " · " : "") + `±${L.acc || 0} m` + (live ? ` · fino alle ${time(L.liveUntil)}` : "") + (L.updated ? ` · aggiornata ${time(L.updated)}` : ""))));
    if (live && m.dir === "out" && lives.has(m.id)) box.append(h("button", { class: "btn small", onclick: e => { e.stopPropagation(); stopLive(c, m); } }, "Interrompi la condivisione"));
    return box;
  }
  Net.on("LOC", p => {
    const f = p.split("|"); const o = origin(f[0]); const c = o.chat; if (!c || f.length < 6 || findMsg(c, f[1])) return;
    const lat = parseFloat(f[2]), lon = parseFloat(f[3]); if (!(Math.abs(lat) <= 90 && Math.abs(lon) <= 180)) return;
    const live = Math.max(0, Math.min(12 * 3600000, parseInt(f[5], 10) || 0));
    const m = { id: f[1], dir: "in", who: o.group ? o.nick : null, time: Date.now(), loc: { lat, lon, acc: parseInt(f[4], 10) || 0, label: Net.unescape(f.slice(6).join("|")), live: live > 0, liveUntil: live ? Date.now() + live : 0 } };
    addMsg(c, m);
    Net.send(`ACK|${o.group ? c.id : o.nick}|${m.id}|D|${Date.now()}`);
  });
  Net.on("LOCUPD", p => {
    const f = p.split("|"); const o = origin(f[0]); const m = findMsg(o.chat, f[1]); if (!m || !m.loc || m.dir !== "in") return;
    const lat = parseFloat(f[2]), lon = parseFloat(f[3]); if (!(Math.abs(lat) <= 90 && Math.abs(lon) <= 180)) return;
    m.loc.lat = lat; m.loc.lon = lon; m.loc.acc = parseInt(f[4], 10) || 0; m.loc.updated = Date.now(); refreshMsg(o.chat, m);
  });
  Net.on("LOCSTOP", p => { const f = p.split("|"); const o = origin(f[0]); const m = findMsg(o.chat, f[1]); if (m && m.loc && m.dir === "in") { m.loc.stopped = true; refreshMsg(o.chat, m); } });

  // ============================================================ sfondi delle chat
  const WALLS = [["", "Nessuno"], ["linear-gradient(160deg,#EDE3F5,#D1C4E9)", "Lavanda"], ["linear-gradient(160deg,#E0F7FA,#B2EBF2)", "Acqua"],
    ["linear-gradient(160deg,#FFF3E0,#FFCCBC)", "Pesca"], ["linear-gradient(160deg,#E8F5E9,#C8E6C9)", "Menta"], ["linear-gradient(160deg,#263238,#4A148C)", "Notte"],
    ["linear-gradient(160deg,#1A1A2E,#16213E)", "Spazio"], ["radial-gradient(circle at 20% 20%,#F8BBD0,transparent 40%),radial-gradient(circle at 80% 70%,#B3E5FC,transparent 40%),#fff", "Bolle"],
    ["repeating-linear-gradient(45deg,#F3E5F5 0 14px,#EDE7F6 14px 28px)", "Righe"], ["#000000", "Nero"]];
  function wallOf(id) { const p = id ? prefs(id).wall : null; return p != null ? p : Store.get("wall", ""); }
  function applyWallpaper(el, id) {
    const w = wallOf(id); el.style.background = ""; el.style.backgroundSize = "";
    if (!w) return;
    if (w === "img") { const d = Store.get("wallimg:" + (id && prefs(id).wall === "img" ? id : "_"), ""); if (d) { el.style.background = `center/cover no-repeat url(${d})`; } return; }
    el.style.background = w;
  }
  function wallpaperPicker(id, after) {
    const row = h("div", { class: "walls" });
    const cur = id ? (prefs(id).wall ?? null) : Store.get("wall", "");
    const set = v => { if (id) setPref(id, "wall", v); else Store.set("wall", v); if (after) after(); };
    if (id) row.append(h("button", { class: "wall" + (cur === null ? " on" : ""), onclick: () => { const all = Store.get("cp", {}); if (all[id]) delete all[id].wall; Store.set("cp", all); if (after) after(); } }, "Come le altre"));
    for (const [v, t] of WALLS) row.append(h("button", { class: "wall" + (cur === v ? " on" : ""), style: v ? `background:${v};color:${/263238|1A1A2E|000000/.test(v) ? "#fff" : "#333"}` : "", onclick: () => set(v) }, t));
    const inp = h("input", { type: "file", accept: "image/*", style: "display:none", onchange: async () => {
      const f = inp.files[0]; if (!f) return; const b = await compressImage(f, 1280, .8); const r = new FileReader();
      r.onload = () => { Store.set("wallimg:" + (id || "_"), r.result); set("img"); }; r.readAsDataURL(b);
    } });
    row.append(h("button", { class: "wall" + (cur === "img" ? " on" : ""), onclick: () => inp.click() }, "🖼 Foto…"), inp);
    return row;
  }
  function wallpaperSheet(c) {
    const s = sheet("Sfondo di " + c.name, wallpaperPicker(c.id, () => { s.close(); const box = $("#msgs"); if (box) applyWallpaper(box, c.id); }));
  }

  return { pickFiles, sendFile, sendBlob, renderFile, recordVoice, emojiPicker, gifPicker, stickerPicker, stickerManager, saveSticker, shareLocation, sendLocation, stopLive, tickLive,
    renderLoc, applyWallpaper, wallpaperPicker, wallpaperSheet, squareJpegB64, download, viewer, bytesToB64, b64ToBytes, Crc32, compressImage, mimeOf };
})();
