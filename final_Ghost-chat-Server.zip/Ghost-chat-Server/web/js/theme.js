/* Ghost-chat mobile · temi, tema personalizzato, font e accessibilita' (come sul computer) */
"use strict";
const Store = {
  get(k, d) { try { const v = localStorage.getItem("gc." + k); return v === null ? d : JSON.parse(v); } catch (e) { return d; } },
  set(k, v) { try { localStorage.setItem("gc." + k, JSON.stringify(v)); } catch (e) { /* niente */ } }
};

const Theme = (() => {
  const hex = n => "#" + (n & 0xFFFFFF).toString(16).padStart(6, "0");
  const toInt = s => { const h = String(s || "").replace("#", "").trim(); return /^[0-9a-f]{6}$/i.test(h) ? parseInt(h, 16) : (/^[0-9a-f]{3}$/i.test(h) ? parseInt(h.split("").map(c => c + c).join(""), 16) : null); };
  const rgb = n => [(n >> 16) & 255, (n >> 8) & 255, n & 255];
  const mix = (a, b, t) => { const x = rgb(a), y = rgb(b); return (Math.round(x[0] + (y[0] - x[0]) * t) << 16) | (Math.round(x[1] + (y[1] - x[1]) * t) << 8) | Math.round(x[2] + (y[2] - x[2]) * t); };
  const hue = (n, deg) => {
    let [r, g, b] = rgb(n).map(v => v / 255); const mx = Math.max(r, g, b), mn = Math.min(r, g, b); let h = 0, s = mx ? (mx - mn) / mx : 0; const v = mx;
    if (mx !== mn) { const d = mx - mn; h = mx === r ? (g - b) / d + (g < b ? 6 : 0) : mx === g ? (b - r) / d + 2 : (r - g) / d + 4; h /= 6; }
    h = (h + deg / 360) % 1; const i = Math.floor(h * 6), f = h * 6 - i, p = v * (1 - s), q = v * (1 - f * s), t = v * (1 - (1 - f) * s);
    const o = [[v, t, p], [q, v, p], [p, v, t], [p, q, v], [t, p, v], [v, p, q]][i % 6].map(x => Math.round(x * 255));
    return (o[0] << 16) | (o[1] << 8) | o[2];
  };
  const light = (accent, second) => ({
    dark: false, accent, accent2: second ?? hue(accent, 38), accentDark: mix(accent, 0, .3), accentLight: mix(accent, 0xFFFFFF, .88),
    surface: 0xFFFFFF, bg: mix(second ?? accent, 0xFFFFFF, .88), text: mix(accent, 0, .82), text2: mix(mix(accent, 0x777777, .75), 0, .05),
    faint: mix(accent, 0xAAAAAA, .7), field: mix(accent, 0xFFFFFF, .92), border: mix(accent, 0xFFFFFF, .83),
    online: 0x22C55E, offline: 0xEF4444, error: 0xC0392B, success: 0x2E9E5B
  });
  const darkP = (accent, second) => ({
    dark: true, accent, accent2: second ?? hue(accent, 38), accentDark: mix(accent, 0, .35), accentLight: mix(accent, 0x120E16, .78),
    surface: mix(accent, 0x141018, .92), bg: mix(second ?? accent, 0x0C0A10, .9), text: 0xEEE7F4, text2: 0xA597B2, faint: 0x7D6F8A,
    field: mix(accent, 0x141018, .8), border: mix(accent, 0x141018, .74),
    online: 0x22C55E, offline: 0xEF4444, error: 0xFF6B6B, success: 0x37B26C
  });
  const PALETTES = [
    ["viola", "Viola fantasma", () => Object.assign(light(0x6A1B9A), { accentLight: 0xEDE3F5, bg: 0xEDE3F5, accentDark: 0x4A126C, text: 0x22182B, text2: 0x7B6E87 })],
    ["oceano", "Oceano", () => light(0x1565C0)], ["smeraldo", "Smeraldo", () => light(0x0F7C6E)],
    ["rosa", "Rosa ciliegia", () => light(0xC2185B)], ["tramonto", "Tramonto", () => light(0xD84315)],
    ["ardesia", "Ardesia", () => light(0x455A64)], ["notte", "Notte (scuro)", () => darkP(0x7B3FB0)],
    ["custom", "Personalizzato", () => { const c = Store.get("custom", { c1: "#6A1B9A", c2: "#00BCD4", dark: false }); const a = toInt(c.c1) ?? 0x6A1B9A, b = toInt(c.c2) ?? 0x00BCD4; return c.dark ? darkP(a, b) : light(a, b); }]
  ];

  // ---- daltonismo (Fidaner) e contrasto, come ColorAccess.java
  function daltonize(n, type, k) {
    let [r, g, b] = rgb(n);
    if (type === "achromatopsia") { let y = .2126 * r + .7152 * g + .0722 * b; y = Math.max(0, Math.min(255, (y - 128) * 1.15 + 128)); const f = v => Math.round(v + (y - v) * k); return (f(r) << 16) | (f(g) << 8) | f(b); }
    const L = 17.8824 * r + 43.5161 * g + 4.11935 * b, M = 3.45565 * r + 27.1554 * g + 3.86714 * b, S = .0299566 * r + .184309 * g + 1.46709 * b;
    let l = L, m = M, s = S;
    if (type === "protanopia") l = 2.02344 * M - 2.52581 * S; else if (type === "deuteranopia") m = .494207 * L + 1.24827 * S; else s = -.395913 * L + .801109 * M;
    const sr = .0809444479 * l - .130504409 * m + .116721066 * s, sg = -.0102485335 * l + .0540193266 * m - .113614708 * s, sb = -.000365296938 * l - .00412161469 * m + .693511405 * s;
    const er = r - sr, eg = g - sg, eb = b - sb;
    let dr, dg, db; if (type === "tritanopia") { dr = .7 * eb + er; dg = .7 * eb + eg; db = 0; } else { dr = 0; dg = .7 * er + eg; db = .7 * er + eb; }
    const c = v => Math.max(0, Math.min(255, Math.round(v)));
    return (c(r + dr * k) << 16) | (c(g + dg * k) << 8) | c(b + db * k);
  }
  const SEMANTIC = {
    protanopia: { online: 0x0072B2, offline: 0xE69F00, success: 0x0072B2, error: 0xD55E00 },
    deuteranopia: { online: 0x0072B2, offline: 0xE69F00, success: 0x0072B2, error: 0xD55E00 },
    tritanopia: { online: 0x009E73, offline: 0xCC79A7, success: 0x009E73, error: 0xD55E00 },
    achromatopsia: { online: 0xF2F2F2, offline: 0x3A3A3A, success: 0x1A1A1A, error: 0x000000 }
  };

  function current() { return Store.get("theme", "viola"); }
  function apply() {
    const id = current();
    const def = PALETTES.find(p => p[0] === id) || PALETTES[0];
    const p = def[2]();
    const a11y = Store.get("a11y", {});
    const cb = a11y.colorblind || "none";
    if (cb !== "none") {
      const k = (a11y.cbStrength ?? 100) / 100;
      for (const key of Object.keys(p)) if (typeof p[key] === "number") p[key] = daltonize(p[key], cb, k);
      Object.assign(p, SEMANTIC[cb]);
    }
    if (a11y.contrast === "low") { p.text = mix(p.text, p.surface, .28); p.text2 = mix(p.text2, p.surface, .28); p.border = mix(p.border, p.surface, .4); }
    if (a11y.contrast === "high") { p.text = p.dark ? 0xFFFFFF : 0; p.text2 = p.dark ? 0xE6E6E6 : 0x1E1E1E; p.border = p.dark ? 0xBFBFBF : 0x303030; }
    const r = document.documentElement.style;
    const set = (k, v) => r.setProperty(k, hex(v));
    set("--accent", p.accent); set("--accent2", p.accent2); set("--accent-dark", p.accentDark); set("--accent-light", p.accentLight);
    set("--surface", p.surface); set("--bg", p.bg); set("--text", p.text); set("--text2", p.text2); set("--faint", p.faint);
    set("--field", p.field); set("--border", p.border); set("--online", p.online); set("--offline", p.offline);
    set("--error", p.error); set("--success", p.success);
    document.body.classList.toggle("dark", !!p.dark);
    document.body.classList.toggle("reduce-transparency", !!a11y.reduceTransparency);
    document.body.classList.toggle("reduce-motion", !!a11y.reduceMotion);
    document.body.classList.toggle("focus-ring", !!a11y.focusRing);
    document.body.classList.toggle("symbols", cb !== "none" || !!a11y.symbols);
    r.setProperty("--scale", String((a11y.textScale || 100) / 100));
    const fam = a11y.dyslexia ? "Comic Relief" : Store.get("font", "");
    r.setProperty("--font", (fam ? `"${fam}", ` : "") + `"Poppins", "Segoe UI", system-ui, -apple-system, Roboto, sans-serif`);
    const meta = document.querySelector('meta[name="theme-color"]'); if (meta) meta.content = hex(p.accent);
    return p;
  }

  // ---- font importati (salvati nel telefono)
  async function loadImportedFonts() {
    for (const f of Store.get("importedFonts", [])) {
      try { const face = new FontFace(f.name, `url(${f.data})`); await face.load(); document.fonts.add(face); } catch (e) { /* font rovinato */ }
    }
  }
  function importFont(file) {
    return new Promise((ok, ko) => {
      if (file.size > 3 * 1024 * 1024) return ko(new Error("Font troppo grande (max 3 MB)"));
      const rd = new FileReader();
      rd.onload = async () => {
        const name = file.name.replace(/\.(ttf|otf|woff2?)$/i, "").replace(/[-_]/g, " ");
        try {
          const face = new FontFace(name, `url(${rd.result})`); await face.load(); document.fonts.add(face);
          const list = Store.get("importedFonts", []).filter(f => f.name !== name); list.push({ name, data: rd.result });
          Store.set("importedFonts", list); ok(name);
        } catch (e) { ko(new Error("Il file non è un font valido")); }
      };
      rd.readAsDataURL(file);
    });
  }
  const FONTS = ["", "Poppins", "Fira Sans", "Montserrat", "Comic Relief", "Lora", "Crimson Text", "Anonymous Pro"];
  return { PALETTES, apply, current, hex, toInt, importFont, loadImportedFonts, FONTS };
})();
