# Ghost-chat – Server (versione **final**)

## Novità della versione final

- **Account con password** (`accounts.db` nella cartella `ghostchat-data`): le password sono salvate solo come hash
  PBKDF2-SHA256 con sale; l'accesso automatico usa gettoni casuali (il server ne tiene solo l'hash). Freno ai tentativi
  sbagliati. Se lo stesso account entra da un altro dispositivo, la vecchia sessione viene chiusa.
- **Accesso rapido via email**: codice di 6 cifre (valido 10 minuti) inviato con SMTP. Se `smtp.host` è vuoto il codice
  viene scritto nella console del server (comodo per le prove).
- **Consenso ai gruppi**: `GCREATE` e `GADD` ora *invitano*; si entra solo con `GCONSENT|gid|1`.
- **Giochi di carte dei gruppi** gestiti dal server (Briscola, Scopa, Rubamazzo, Sette e mezzo, mazzo "Ghost").
- **InstaGhost**: post e Ghost-tube salvati in `ghostchat-data/instaghost` (i messaggi delle chat, invece, continuano a
  non essere salvati).
- **Server online 24/7 su Wispbyte** (vedi `WISPBYTE.md`): **una sola porta** (11112) per tutto. Dai primi byte di
  ogni connessione il server capisce da solo se è il client per computer (normale o cifrato **TLS**), l'app Android/iOS
  (**WebSocket**, anche dentro TLS) o un browser (versione web, servita anche dall'interno del jar).
  Indirizzo pubblico predefinito: **78.154.103.51:11112** (si cambia in `public.host` e nei client).
- **Contatti con conferma**: niente più elenco di tutti gli utenti online. Ci si cerca per **nome utente univoco**
  (`USEARCH`), si manda una richiesta (`CREQ`) e l'altro deve **accettarla** (`CANSWER`). Finché non accetta il server
  non consegna messaggi, file, chiamate, giochi, foto profilo né stati; nei gruppi si invitano solo i propri contatti.
  Contatti e richieste restano salvati in `ghostchat-data/contacts.txt`.

### Configurazione (`ghostchat-server.properties`, creato al primo avvio)

| Chiave | Predefinito | Significato |
|---|---|---|
| `port` | 11112 | porta unica (sull'hosting vince la variabile `SERVER_PORT` assegnata dal pannello) |
| `mux.enabled` / `mux.tls` / `mux.ws` | true / true / true | sulla porta unica accetta anche TLS e WebSocket/HTTP |
| `public.host` | 78.154.103.51 | nome o IP pubblico (mostrato all'avvio e messo nel certificato) |
| `discovery.enabled` | false | ricerca automatica nella rete locale (UDP 5099): utile solo a casa |
| `tls.enabled` / `ws.enabled` / `wss.enabled` | false | porte separate di una volta (5443 / 5080 / 5444), se ti servono |
| `tls.keystore` / `tls.password` | ghostchat-tls.p12 / ghostchat | certificato (creato da solo con `keytool`; puoi mettere il tuo, es. Let's Encrypt convertito in PKCS12) |
| `data.dir` | ghostchat-data | account, contatti e InstaGhost |
| `smtp.host`, `smtp.port`, `smtp.security` (starttls/ssl/none), `smtp.user`, `smtp.password`, `smtp.from` | | posta per i codici (es. Gmail: smtp.gmail.com, 587, starttls, password per le app) |
| `accounts.allowRegistration` | true | permette nuove registrazioni |
| `instaghost.maxPhotoMB` / `instaghost.maxVideoMB` | 12 / 80 | dimensione massima dei post |

### Contatti (protocollo)

| Messaggio | Significato |
|---|---|
| `USEARCH\|id\|testo` → `USEARCHR\|id\|utente:stato:online;...` | ricerca per nome utente (stato `c` contatto, `o` richiesta inviata, `i` ricevuta, `n` nessuno) |
| `CREQ\|utente` → `CREQOUT\|utente` (a te) e `CREQIN\|tuoNome` (a lui) | richiesta di contatto |
| `CANSWER\|utente\|1/0` → `CONTACTADD\|...` a entrambi oppure `CREQNO\|...` a chi l'aveva chiesta | conferma o rifiuto |
| `CCANCEL\|utente` / `CREMOVE\|utente` → `CREQGONE` / `CONTACTDEL` | ritira la richiesta / togli il contatto |
| `CONTACTS\|a,b,c` | all'accesso: tutti i tuoi contatti (poi `CREQIN`/`CREQOUT` per le richieste in sospeso) |
| `LIST` | ora contiene solo **i tuoi contatti online** (e te) |

### Nuovi comandi del protocollo

| Messaggio | Significato |
|---|---|
| `AUTH\|login\|utente\|passB64` · `AUTH\|register\|utente\|passB64\|\|email` · `AUTH\|token\|utente\|gettone` · `AUTH\|code\|email\|codice` | accesso (sostituisce `NICK`) → `WELCOME\|utente\|ip\|gettone\|email\|verificata` o `AUTHERR\|motivo\|campo` |
| `MAILCODE\|email` → `MAILCODE\|ok\|email` | codice di accesso via email |
| `ACCOUNT\|info / email / verify / noemail / passwd / logout` | gestione dell'account |
| `GINVREQ\|gid\|nome\|daChi\|membri` · `GCONSENT\|gid\|1/0` · `GINVCANCEL\|gid\|nick` | inviti con consenso |
| `CARD\|gid\|id\|new\|tipo\|giocatori` · `accept` · `decline` · `play\|carta` · `hit` · `stand` · `quit` → `CARDS\|gid\|{json}` | giochi di carte |
| `IGPOST`, `IGPREV`, `IGCHUNK`, `IGUPEND`, `IGFEED`, `IGGET`, `IGVOTE`, `IGFAV`, `IGSHARE`, `IGCOMMENT`, `IGUNCOMMENT`, `IGCOMMENTS`, `IGDEL`, `IGBIO`, `IGFOLLOW`, `IGPROFILE`, `IGSEARCH` | InstaGhost (dettagli in `FinalFeatures.java`) |

---


Server console (nessuna interfaccia grafica) dell'app di messaggistica **Ghost-chat** (versione release_ufficiale).

La release_ufficiale cambia solo il client (nuova schermata Info e menu della chat): il server e il protocollo sono
quelli della v7.
Tiene traccia degli utenti online e inoltra messaggi, foto, video, file, GIF, vocali, sondaggi,
conferme di lettura, modifiche/eliminazioni, reazioni, messaggi fissati, posizioni (anche in tempo reale),
anteprime dei link, minigiochi e l'audio e il video di chiamate e videochiamate, **senza salvare nulla su disco**.

Novità della v7 lato server:
- nuovo comando inoltrato **`FILEPOS`**: chi riceve un file interrotto dice al mittente da quanti byte riprendere,
  così "Riprova" non rimanda i pezzi già arrivati (solo tra due persone, non nei gruppi);
- citazioni parziali (`q=`) e messaggi a tempo (`t=`) viaggiano nei metadati dei messaggi e il flag `t<secondi>`
  negli allegati: il server li inoltra senza modificarli (e continua a non salvare nulla).

Novità della v5 lato server:
- **più amministratori** per gruppo (`GADMIN`), **descrizione** (`GDESC`) e permesso
  **"solo gli amministratori possono scrivere"** (`GPERM`): il server blocca messaggi, file, sondaggi, posizioni,
  giochi, lavagna e messaggi fissati dei non amministratori; reazioni, conferme e voti restano permessi;
- **codici d'invito** (`GINVITE` crea / legge / revoca, `GJOIN` per entrare con il codice o il link `ghostchat://invito/…`);
- inoltro di **"sta scrivendo"** (`TYPING`) e della **lavagna condivisa** (`WB`);
- se esce l'ultimo amministratore, il primo membro rimasto diventa amministratore.
- La riga `GROUP` ora è `GROUP|gid|nome|admin1,admin2|membri|descrizione|flag` (flag `a` = solo amministratori).

Novità della v4 lato server:
- **gruppi** (fino a 32 membri, con amministratore): restano in memoria finché il server è acceso;
- **chiamate e videochiamate di gruppo** (fino a 8 partecipanti): il server tiene una "stanza" per gruppo e
  inoltra audio, video e reazioni solo a chi partecipa;
- **stati** stile WhatsApp (testo, foto, GIF, brevi video): tenuti in memoria per 24 ore (al massimo 10 per utente,
  400 MB in tutto) e poi cancellati da soli; l'autore sa chi li ha visti;
- **foto profilo** e **stato online nascosto** (gli altri non vedono né pallino verde/rosso né l'IP).
- **ritrovamento automatico**: il server risponde sulla porta **UDP 5099** alle domande in broadcast dei client,
  che così trovano da soli il suo indirizzo IP e la porta (stessa rete locale / stesso Wi-Fi).
  La prima volta Windows chiede il permesso nel Firewall: consenti l'accesso sulle **reti private**.
  Se la porta UDP non si può aprire il server funziona lo stesso e i client scrivono l'IP a mano.

## Aprire ed eseguire in NetBeans

1. *File → Open Project…* e seleziona la cartella `Ghost-chat-Server`
   (oppure *File → Import Project → From ZIP…* direttamente sullo zip).
2. Tasto destro sul progetto → **Run** (F6). Il server parte sulla porta **11112**.
3. Avvia il server **prima** dei client.

Per cambiare porta: *Proprietà progetto → Run → Arguments* (es. `6000`).
Fuori da NetBeans: `java -jar GhostChatServer.jar [porta]` (il jar pronto è nella cartella principale dello zip).

All'avvio la console mostra gli indirizzi IP del PC da inserire nei client degli altri computer.
Nella finestra Output si possono scrivere i comandi `utenti`, `stato` (utenti, gruppi e stati in memoria), `aiuto`, `esci`.

Requisiti: JDK 8 o superiore (il progetto compila con source/target 1.8).

## Dove si trova ogni requisito

| Requisito | Dove |
|---|---|
| RS-01 Sempre in ascolto | `GhostChatServer.main/listen`: ciclo `accept()` continuo; se la ServerSocket si rompe o la porta è occupata, si riprova invece di terminare |
| RS-02 Un thread per client | `GhostChatServer.startHandler`: `new Thread(new ClientHandler(socket)).start()` |
| RS-03 Registrazione | `ClientHandler.handleNick`: nickname associato all'IP della socket |
| RS-04 Elenco utenti online | `ClientRegistry.broadcastUserList`: inviato a tutti a ogni connessione/disconnessione |
| RS-05 Rimozione offline | `ClientHandler.disconnect` (chiusura app, `QUIT`, errore, timeout) |
| RS-06 Inoltro uno-a-uno | `ClientHandler.handleMessage`: solo al destinatario; se offline → `ERR` al mittente |
| RS-07 Nessun salvataggio | i messaggi sono solo inoltrati; nel log compare chi scrive a chi, mai il testo |
| RT-01 Java/NetBeans | progetto NetBeans "Java with Ant" |
| RT-02 Solo console | `ServerLog` stampa su console |
| RT-03 ClientHandler | `ClientHandler implements Runnable`: il suo thread legge dal client; i messaggi per il client passano da una coda (`Outbox`) svuotata da un piccolo thread di scrittura, così un destinatario lento non blocca chi scrive |
| RT-04 Classe principale | `GhostChatServer` |
| RT-05 Accesso concorrente | `ClientRegistry`: tutti i metodi sull'elenco sono `synchronized` |

## Protocollo (una riga per messaggio, UTF-8)

| Messaggio | Direzione | Significato |
|---|---|---|
| `NICK\|<nickname>` | C → S | registrazione del nickname |
| `WELCOME\|<nickname>\|<ip>` | S → C | registrazione accettata *(aggiunto)* |
| `NICKERR\|<descrizione>` | S → C | nickname già in uso o non valido: il client ne sceglie un altro *(aggiunto)* |
| `LIST\|<nick>@<ip>@<h>;…` | S → C | elenco aggiornato degli utenti online; `h` = 1 se lo stato è nascosto (in quel caso l'IP è vuoto) *(v4)* |
| `MSG\|<destinatario>\|<id>\|<meta>\|<testo>` | C → S | messaggio da inoltrare (l'id serve per spunte, modifica ed eliminazione); `meta` = `r=<idRisposta>;f=1` (risposta a un messaggio, inoltrato) *(v4)* |
| `MSG\|<mittente>\|<id>\|<meta>\|<testo>` | S → C | messaggio inoltrato |
| `EDIT\|<dest>\|<id>\|<testo>` | C → S | il mittente ha modificato il messaggio `<id>` *(v3)* |
| `DEL\|<dest>\|<id>` | C → S | "elimina per tutti" del messaggio `<id>` *(v3)* |
| `ACK\|<dest>\|<id1,id2,…>\|D\|R\|<ora>` | C → S | conferma di **consegna** (`D`, due spunte) o di **lettura** (`R`, spunte blu) *(v3)* |
| `POLL\|<dest>\|<id>\|<flag>\|<domanda>\|<opzione1>\|…` | C → S | sondaggio, da 2 a 12 opzioni; flag: `1` più risposte, `a` anonimo, `q<n>` quiz con risposta giusta `n` *(v3, flag v5)*; `\|` nel testo diventa `\p` |
| `VOTE\|<dest>\|<idSondaggio>\|<0,2,…>` | C → S | voti (indici delle opzioni scelte; vuoto = voto ritirato) *(v3)* |
| `FILE\|<dest>\|<id>\|<tipo>\|<byte>\|<nome>\|<extra>` | C → S | inizio di un file; tipo = `IMAGE`, `GIF`, `VIDEO`, `FILE`, `VOICE` (extra = durata del vocale in ms) *(aggiunto)* |
| `CHUNK\|<dest>\|<id>\|<base64>` | C → S | un pezzo del file (48 KB) *(aggiunto)* |
| `FILEEND\|<dest>\|<id>\|<crc32>` | C → S | fine del file, con codice di controllo *(aggiunto)* |
| `FILECANCEL\|<dest>\|<id>` | C → S | invio (o ricezione) annullato *(aggiunto)* |
| `CALL\|<dest>\|<idChiamata>\|<A\|V>` | C → S | chiamata vocale (`A`) o videochiamata (`V`) *(aggiunto)* |
| `CALLACCEPT\|<dest>\|<id>` / `CALLREJECT\|<dest>\|<id>\|<motivo>` / `CALLEND\|<dest>\|<id>` | C → S | risposta, rifiuto (es. `occupato`), fine *(aggiunto)* |
| `AUDIO\|<dest>\|<id>\|<base64>` | C → S | 40 ms di audio della chiamata (16 kHz, 16 bit, mono) *(aggiunto)* |
| `VIDEO\|<dest>\|<id>\|<base64>` | C → S | un fotogramma JPEG della webcam o dello schermo (max ~200 KB) *(v3)* |
| `VIDSTATE\|<dest>\|<id>\|cam\|screen\|off` | C → S | cosa sta inviando come video *(v3)* |
| `REACT\|<dest>\|<idMsg>\|<emoji>` | C → S | reazione a un messaggio (emoji vuota = tolta) *(v4)* |
| `PIN\|<dest>\|<idMsg>\|1\|0` | C → S | messaggio fissato in alto / tolto *(v4)* |
| `LINK\|<dest>\|<idMsg>\|<url>\|<titolo>\|<descrizione>\|<sito>\|<immagine base64>` | C → S | anteprima del link di un messaggio (la scarica chi invia) *(v4)* |
| `LOC\|<dest>\|<id>\|<lat>\|<lon>\|<precisione m>\|<durata ms>\|<etichetta>` | C → S | posizione; durata > 0 = in tempo reale *(v4)* |
| `LOCUPD\|<dest>\|<id>\|<lat>\|<lon>\|<precisione>` / `LOCSTOP\|<dest>\|<id>` | C → S | aggiornamento / fine della posizione in tempo reale *(v4)* |
| `GAME\|<dest>\|<idPartita>\|ttt\|c4\|rps\|hm\|dm\|bn\|qz\|ch\|<azione>\|…` | C → S | giochi (v5: impiccato, dama, battaglia navale, quiz, scacchi); minigiochi v4: `new`, `move\|<cella>\|<n>`, `commit\|<round>\|<sha256>`, `reveal\|<round>\|<scelta>\|<sale>`, `quit` *(v4)* |
| `CALLREACT\|<dest>\|<idChiamata>\|<emoji>` | C → S | reazione durante una chiamata *(v4)* |
| tutti i comandi qui sopra | S → C | inoltrati identici, con il **mittente** al posto del destinatario |
| `GHOSTCHAT?DISCOVER` → `GHOSTCHAT!SERVER\|v4\|<porta>\|<nome computer>\|<utenti>` | UDP 5099 | ritrovamento automatico del server (broadcast nella rete locale) *(v4)* |
| `<comando>\|#<idGruppo>\|…` | C → S | qualsiasi comando di chat verso un **gruppo**: va a tutti gli altri membri online, con mittente `#<idGruppo>/<nick>`; audio, video, `VIDSTATE` e `CALLREACT` solo ai partecipanti della chiamata *(v4)* |
| `PRESENCE\|1\|0` | C → S | nasconde / mostra il mio stato online *(v4)* |
| `AVATAR\|<jpeg base64>` → `AVATAR\|<nick>\|<jpeg base64>` | C → S → C | foto profilo (vuota = tolta), max 96 KB; chi arriva dopo riceve quelle già impostate *(v4)* |
| `GCREATE\|<id>\|<nome>\|<m1,m2,…>` | C → S | crea un gruppo (chi lo crea è l'amministratore) *(v4)* |
| `GADD\|<id>\|<nick,…>` / `GKICK\|<id>\|<nick>` / `GNAME\|<id>\|<nome>` / `GPHOTO\|<id>\|<base64>` | C → S | gestione del gruppo (solo l'amministratore) *(v4)* |
| `GLEAVE\|<id>` | C → S | esci dal gruppo (se esce l'amministratore lo diventa il primo membro rimasto) *(v4)* |
| `GROUP\|<id>\|<nome>\|<admin>\|<membri>` / `GPHOTO\|<id>\|<base64>` / `GROUPGONE\|<id>` | S → C | stato del gruppo / foto / non ne fai più parte *(v4)* |
| `GEVENT\|<id>\|<chi>\|create\|add\|kick\|leave\|name\|photo\|admin\|unadmin\|desc\|perm\|join\|<bersaglio>` | S → C | avviso per la chat del gruppo *(v4)* |
| `GCALL\|<id>\|<idChiamata>\|A\|V\|<partecipanti>` | S → C | chiamata di gruppo in corso (id vuoto = finita) *(v4)* |
| `SPOST\|<idStato>\|T\|I\|G\|V\|<byte>\|<meta>\|<testo>` | C → S | nuovo stato (testo con `meta` = `bg=#RRGGBB`, oppure foto, GIF, video + didascalia) *(v4)* |
| `SCHUNK\|<idStato>\|<base64>` / `SEND\|<idStato>\|<crc32>` | C → S | contenuto dello stato a pezzi e fine con controllo *(v4)* |
| `STATUS\|<autore>\|<id>\|<tipo>\|<ora>\|<byte>\|<meta>\|<testo>` / `SGONE\|<autore>\|<id>` | S → C | stato pubblicato / scaduto o eliminato *(v4)* |
| `SGET\|<autore>\|<id>` → `SDATA\|<autore>\|<id>\|<base64>` … `SDATAEND\|<autore>\|<id>\|<crc32>` | C → S → C | scaricamento del contenuto di uno stato *(v4)* |
| `SSEEN\|<autore>\|<id>` → `SSEEN\|<chi>\|<id>\|<ora>` | C → S → C | visualizzazione di uno stato, notificata all'autore *(v4)* |
| `SDEL\|<idStato>` | C → S | elimina un mio stato *(v4)* |
| `ERR\|<descrizione>[\|<destinatario>[\|<id>]]` | S → C | errore; destinatario e id (facoltativi) dicono a quale chat, file o chiamata si riferisce |
| `PING` / `PONG` | C ↔ S | controllo che la connessione sia viva *(aggiunto)* |
| `QUIT` | C → S | chiusura dell'app *(aggiunto)* |
| `BYE\|<motivo>` | S → C | arresto del server *(aggiunto)* |
| `TYPING\|<dest>\|t\|r\|0` | C ↔ S | sta scrivendo (`t`), sta registrando (`r`), ha smesso (`0`) *(v5)* |
| `WB\|<dest>\|<idLavagna>\|new` / `s\|<idTratto>\|<colore>\|<spessore>\|x,y,…` / `u\|<idTratto>` / `c` | C ↔ S | lavagna condivisa: nuova, tratto, annulla tratto, pulisci *(v5)* |
| `GADMIN\|<gid>\|<nick>\|1\|0` | C → S | nomina / toglie un amministratore *(v5)* |
| `GDESC\|<gid>\|<testo>` | C → S | descrizione del gruppo (max 400 caratteri) *(v5)* |
| `GPERM\|<gid>\|1\|0` | C → S | "solo gli amministratori possono scrivere" *(v5)* |
| `GINVITE\|<gid>\|get\|new\|revoke` → `GINVITE\|<gid>\|<codice>` | C ↔ S | codice d'invito (vuoto se revocato) *(v5)* |
| `GJOIN\|<codice o link>` | C → S | entra in un gruppo con il codice d'invito *(v5)* |
| `FILEPOS\|<dest>\|<id>\|<byte>` | C ↔ S | chi riceve dice da dove riprendere un invio interrotto (risposta al flag `rs` del `FILE`) *(v7)* |

Il testo dei messaggi viaggia con `\n` e `\\` in escape, così i messaggi su più righe restano su una sola riga del protocollo.
I nickname sono unici (senza distinzione tra maiuscole e minuscole), lunghi al massimo 20 caratteri e non possono contenere `| ; @ \ # / ,`.

Il server non interpreta modifiche, eliminazioni, conferme, sondaggi e voti: controlla solo che siano
ben formati e li consegna al destinatario (come per i messaggi, RS-07: niente viene salvato e nel log
non compare mai il contenuto).

### Priorità in uscita

Per ogni client c'è una coda a quattro livelli (`Outbox`): prima testo, elenco utenti, conferme, errori e segnali di chiamata,
poi l'audio delle chiamate (se si accumula, il più vecchio viene scartato per restare "in diretta"),
poi il video (si tengono al massimo 3 fotogrammi: quelli vecchi si scartano),
infine i pezzi dei file (se il destinatario è lento, chi invia viene rallentato invece di riempire la memoria).
Così un video da 100 MB non blocca né la chat né le chiamate, e una videochiamata non rallenta i messaggi.

## Gestione degli errori

Nessun errore di un client può fermare il server o gli altri client:
- comandi sconosciuti o malformati → `ERR`, la connessione resta aperta;
- righe enormi (oltre 256 KB) scartate senza esaurire la memoria (`LineReader`);
- file oltre 100 MB rifiutati; file, chiamate o audio verso utenti offline → `ERR` o scartati;
- messaggi oltre 8000 caratteri, sondaggi malformati, fotogrammi video troppo grandi → rifiutati o scartati;
- destinatario che non riceve più dati per 30 s → il trasferimento viene interrotto con un avviso;
- client che spariscono senza chiudere (rete staccata) → rimossi dopo 75 s di silenzio;
- porta già occupata → nuovo tentativo ogni 5 secondi;
- gruppi: comandi di chi non è membro o non è amministratore → `ERR` chiaro; gruppo pieno, nomi non validi → rifiutati;
- chiamate di gruppo: chi si disconnette esce da solo dalla stanza; quando escono tutti la chiamata finisce;
- stati: contenuto più grande del dichiarato o con CRC sbagliato, troppo grande (foto 8 MB, video 16 MB) o troppi → rifiutati;
  caricamenti interrotti da una disconnessione vengono scartati; dopo 24 ore gli stati spariscono da soli;
- errori imprevisti in qualsiasi thread → registrati in console, il server continua.
